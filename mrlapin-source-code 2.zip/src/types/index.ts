export type ProductStatus = 'online' | 'maintenance' | 'out_of_stock' | 'not_available';

export type AppLanguage = 'bn' | 'en';

export type ProductCategory = 'all' | 'non_root' | 'root' | 'iphone' | 'pc';

export interface PackageTier {
  id: string;
  name: string;
  duration: string;
  price: number;
  status: 'online' | 'out_of_stock';
  keysPool?: string[];
}

export interface Product {
  id: string;
  name: string;
  category: 'non_root' | 'root' | 'iphone' | 'pc';
  basePrice: number;
  image: string;
  status: ProductStatus;
  customBadge?: string;
  description: string;
  appLink?: string;
  videoLink?: string;
  packages: PackageTier[];
}

export interface PaymentGatewayConfig {
  id: 'bkash' | 'nagad' | 'rocket' | 'binance' | 'indiapay';
  name: string;
  subType: string;
  numberOrAddress: string;
  minAmount: number;
  maxAmount: number;
  rateInfo?: string;
  instructions: string;
  isActive: boolean;
  color: string;
}

export interface DepositRecord {
  id: string;
  serialNo: number;
  date: string;
  userId: string;
  userName: string;
  userEmail: string;
  gateway: string;
  paymentMethod: string;
  senderNumber: string;
  trxId: string;
  amount: number;
  status: 'pending' | 'completed' | 'rejected';
  adminNote?: string;
}

export interface OrderRecord {
  id: string;
  serialNo: number;
  date: string;
  userId: string;
  userName: string;
  userEmail: string;
  productId: string;
  productName: string;
  packageTitle: string;
  price: number;
  quantity: number;
  totalPrice: number;
  status: 'completed' | 'pending' | 'processing' | 'cancelled' | 'failed';
  licenseKey: string;
}

export interface UserCodeRecord {
  id: string;
  serialNo: number;
  date: string;
  packageTitle: string;
  price: number;
  status: 'completed' | 'pending';
  code: string;
}

export interface RecentOrderItem {
  id: string;
  user: string;
  product: string;
  price: string;
  avatarBg: string;
}

export interface HeroSlideItem {
  id: string;
  badge: string;
  title: string;
  subtitle: string;
  buttonText: string;
  link: string;
  logoOrImage?: string;
  tags?: string[];
  bgGradient?: string;
}

export interface SiteSettings {
  siteName: string;
  telegramPopupEnabled: boolean;
  telegramPopupTitle: string;
  telegramPopupDesc: string;
  telegramLink: string;
  telegramDmLink: string;
  telegramBenefits: string[];
  noticeMarquee: string;
  supportPhone: string;
  supportWhatsapp: string;
  bannerTitle: string;
  bannerSubtitle: string;
  bannerVideoUrl: string;
  heroSlides: HeroSlideItem[];
  maintenanceMessage: string;
  isGlobalMaintenance: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  balance: number;
  totalOrders: number;
  totalSpent: number;
  supportPin: string;
  authProvider?: 'email' | 'google' | 'telegram';
  telegramUsername?: string;
  avatarUrl?: string;
  isLoggedIn?: boolean;
  sessionToken?: string;
}

export interface RegisteredAccount {
  id: string;
  name: string;
  email: string;
  phone: string;
  passwordHash: string;
  supportPin: string;
  authProvider: 'email' | 'google' | 'telegram';
  telegramUsername?: string;
  createdAt: string;
}

