export interface PlatformGuide {
  id: string;
  name: string;
  category: 'no-code' | 'code-hosting' | 'blog-cms';
  logoText: string;
  badge: string;
  difficulty: 'খুবই সহজ (Beginner)' | 'মাঝারি (Intermediate)' | 'কোডিং প্রয়োজন (Developer)';
  difficultyEn: 'Very Easy' | 'Intermediate' | 'Coding Needed';
  timeNeeded: string;
  freeUrlFormat: string;
  freeTierFeatures: string[];
  pros: string[];
  cons: string[];
  bestFor: string;
  officialUrl: string;
  steps: {
    title: string;
    description: string;
    codeSnippet?: string;
    tip?: string;
  }[];
}

export const PLATFORMS_DATA: PlatformGuide[] = [
  {
    id: 'netlify-drop',
    name: 'Netlify Drop',
    category: 'code-hosting',
    logoText: 'Netlify',
    badge: 'সবচেয়ে দ্রুত ও সহজ (১ ক্লিকে লাইভ)',
    difficulty: 'খুবই সহজ (Beginner)',
    difficultyEn: 'Very Easy',
    timeNeeded: '৫-১০ মিনিট',
    freeUrlFormat: 'yourname.netlify.app',
    freeTierFeatures: [
      '১০০ জিবি ব্যান্ডউইথ প্রতি মাসে সম্পূর্ণ ফ্রি',
      'অটোমেটিক ফ্রি SSL (HTTPS) সার্টিফিকেট',
      'কাস্টম ডোমেন সম্পূর্ণ ফ্রিতে যুক্ত করার সুযোগ',
      'কোনো ক্রেডিট কার্ড লাগে না'
    ],
    pros: [
      'কোনো গিটহাব বা কমান্ড লাইনের দরকার নেই, ফাইল ড্র্যাগ অ্যান্ড ড্রপ করলেই লাইভ',
      'বিশ্বের দ্রুততম সিডিএন (Global CDN) সার্ভার',
      'পরবর্তীতে ফ্রিতে নিজস্ব .com ডোমেইন যুক্ত করা যায়'
    ],
    cons: [
      'শুধুমাত্র স্ট্যাটিক সাইট (HTML, CSS, JS, React build)',
      'মাসিক ব্যান্ডউইথ ১০০ জিবি শেষ হলে আপগ্রেড করতে হয় (সাধারণ সাইটের জন্য যথেষ্ট)'
    ],
    bestFor: 'যাঁরা HTML ফাইল বানিয়েছেন এবং কোনো ঝামেলা ছাড়াই ১ মিনিটে ওয়েবসাইট লাইভ দেখতে চান।',
    officialUrl: 'https://app.netlify.com/drop',
    steps: [
      {
        title: 'ধাপ ১: আপনার সাইটের ফাইল রেডি করুন',
        description: 'আপনার কম্পিউটারে একটি ফোল্ডার তৈরি করুন (যেমন "my-site")। এর ভেতর মূল ফাইলটির নাম দিন "index.html" এবং প্রয়োজনে CSS বা ইমেজ ফাইলগুলো রাখুন।'
      },
      {
        title: 'ধাপ ২: Netlify Drop পেজে যান',
        description: 'ব্রাউজারে app.netlify.com/drop খুলুন। সাইন ইন বা ফ্রি অ্যাকাউন্ট তৈরি করুন।'
      },
      {
        title: 'ধাপ ৩: ফোল্ডারটি ড্র্যাগ করে ছেড়ে দিন',
        description: 'আপনার ফোল্ডারটি টেনে এনে Netlify-এর ড্রপ বক্সে ছেড়ে দিন। মাত্র ৫ থেকে ১০ সেকেন্ডের মধ্যে ফাইল আপলোড হয়ে যাবে।'
      },
      {
        title: 'ধাপ ৪: লাইভ লিংক উপভোগ করুন!',
        description: 'Netlify আপনাকে একটি লাইভ লিঙ্ক দেবে (যেমন: serene-moon-12345.netlify.app)। Site Settings থেকে নামটি পরিবর্তন করে আপনার পছন্দের নাম (যেমন: rahims-portfolio.netlify.app) দিতে পারবেন।'
      }
    ]
  },
  {
    id: 'github-pages',
    name: 'GitHub Pages',
    category: 'code-hosting',
    logoText: 'GitHub',
    badge: 'বিশ্বজুড়ে ডেভেলপারদের ১ নম্বর পছন্দ',
    difficulty: 'মাঝারি (Intermediate)',
    difficultyEn: 'Intermediate',
    timeNeeded: '১৫-২০ মিনিট',
    freeUrlFormat: 'username.github.io/project',
    freeTierFeatures: [
      '১ জিবি সাইট স্টোরেজ ও ১০০ জিবি মাসিক ব্যান্ডউইথ',
      'আজীবন সম্পূর্ণ ১০০% ফ্রি (কোনো হিডেন ট্রিকস নেই)',
      'ফ্রি কাস্টম ডোমেন সাপোর্ট ও ফ্রি HTTPS',
      'ভার্সন কন্ট্রোল ও কোড ব্যাকআপ'
    ],
    pros: [
      'মাইক্রোসফটের গিটহাব প্ল্যাটফর্ম, কখনোই বন্ধ বা ডাউন হবে না',
      'পোর্টফোলিওতে গিটহাব লিংক দিলে ক্লায়েন্ট বা চাকরিদাতারা প্রভাবিত হন',
      'কোড আপডেট করলেই ওয়েবসাইট অটোমেটিক আপডেট হয়ে যায়'
    ],
    cons: [
      'গিটহাব অ্যাকাউন্ট ও রিপোজিটরি খোলার প্রাথমিক জ্ঞান দরকার',
      'ব্যাকএন্ড ডাটাবেস (PHP/MySQL) সরাসরি রান করে না'
    ],
    bestFor: 'শিক্ষার্থী, কোডার, ডেভেলপার এবং যাঁরা প্রফেশনাল পোর্টফোলিও বা প্রজেক্ট শোকেস করতে চান।',
    officialUrl: 'https://pages.github.com',
    steps: [
      {
        title: 'ধাপ ১: GitHub এ ফ্রি অ্যাকাউন্ট খুলুন',
        description: 'github.com এ গিয়ে একটি ফ্রি অ্যাকাউন্ট তৈরি করুন এবং ইমেইল ভেরিফাই করুন।'
      },
      {
        title: 'ধাপ ২: নতুন Repository তৈরি করুন',
        description: 'New Repository বাটনে ক্লিক করুন। নাম দিন যেমন "my-portfolio"। এটি অবশ্যই "Public" রাখবেন।'
      },
      {
        title: 'ধাপ ৩: ফাইল আপলোড করুন',
        description: '"uploading an existing file" লিংকে ক্লিক করে আপনার index.html এবং অন্যান্য ফাইল আপলোড করে "Commit changes" করুন।'
      },
      {
        title: 'ধাপ ৪: GitHub Pages অন করুন',
        description: 'রিপোজিটরির Settings মেনুতে যান > বাম পাশের মেনু থেকে "Pages" এ ক্লিক করুন > Branch অপশনে "main" সিলেক্ট করে Save দিন।'
      },
      {
        title: 'ধাপ ৫: সাইট লাইভ!',
        description: '১-২ মিনিট পর রিফ্রেশ করলে আপনার সাইট লাইভ লিংক (https://yourname.github.io/my-portfolio) দেখতে পাবেন।'
      }
    ]
  },
  {
    id: 'google-sites',
    name: 'Google Sites',
    category: 'no-code',
    logoText: 'Google',
    badge: '০ কোডিং, ৫ মিনিটে গুগল ড্রাইভের মতো সহজ',
    difficulty: 'খুবই সহজ (Beginner)',
    difficultyEn: 'Very Easy',
    timeNeeded: '৫-১৫ মিনিট',
    freeUrlFormat: 'sites.google.com/view/yoursite',
    freeTierFeatures: [
      'সম্পূর্ণ আনলিমিটেড হোস্টিং ও গুগলের নিরাপদ সার্ভার',
      'কোনো টেকনিক্যাল কোড বা ফাইল ম্যানেজমেন্ট নেই',
      'গুগল ফর্ম, গুগল ড্রাইভ, ইউটিউব ভিডিও ১ ক্লিকে যুক্ত করা যায়',
      'ফ্রি SSL সহ সম্পূর্ণ লাইভ'
    ],
    pros: [
      'যেকোনো সাধারণ মানুষ কোনো কোডিং ছাড়াই সুন্দর ওয়েবসাইট বানাতে পারেন',
      'মোবাইল এবং কম্পিউটারে স্বয়ংক্রিয়ভাবে পারফেক্ট দেখায়',
      'গুগল অ্যাকাউন্টের সাথে সরাসরি লিংক থাকে'
    ],
    cons: [
      'ডিজাইন কাস্টমাইজেশন সীমিত',
      'অ্যাডভান্সড কোডিং বা জাভাস্ক্রিপ্ট প্লাগইন ব্যবহারের সুযোগ কম'
    ],
    bestFor: 'স্কুল-কলেজের প্রজেক্ট, ছোট ব্যবসার তথ্য পেজ, ইভেন্ট বা কোনো নো-কোড প্রেজেন্টেশন সাইট।',
    officialUrl: 'https://sites.google.com',
    steps: [
      {
        title: 'ধাপ ১: sites.google.com খুলুন',
        description: 'আপনার জিমেইল আইডি দিয়ে লগইন করে sites.google.com পেজে যান।'
      },
      {
        title: 'ধাপ ২: ব্ল্যাঙ্ক অথবা রেডিমেড টেমপ্লেট বেছে নিন',
        description: 'Portfolio, Restaurant, Event ইত্যাদি সুন্দর ফ্রি টেমপ্লেট থেকে একটি বেছে নিন অথবা Blank দিয়ে শুরু করুন।'
      },
      {
        title: 'ধাপ ৩: টেক্সট এবং ছবি পরিবর্তন করুন',
        description: 'যেকোনো লেখার উপর ডাবল ক্লিক করে এডিট করুন, ডানদিকের প্যানেল থেকে লেআউট ড্র্যাগ করে ড্রপ করুন।'
      },
      {
        title: 'ধাপ ৪: "Publish" বাটনে চাপুন',
        description: 'উপরে ডানদিকের বেগুনি/নীল "Publish" বাটনে ক্লিক করুন এবং আপনার সাইটের জন্য একটি ওয়েব ঠিকানা লিখুন।'
      }
    ]
  },
  {
    id: 'vercel',
    name: 'Vercel',
    category: 'code-hosting',
    logoText: 'Vercel',
    badge: 'মডার্ন ওয়েব ফ্রেমওয়ার্কের জন্য সেরা',
    difficulty: 'মাঝারি (Intermediate)',
    difficultyEn: 'Intermediate',
    timeNeeded: '১০-১৫ মিনিট',
    freeUrlFormat: 'yourname.vercel.app',
    freeTierFeatures: [
      'Next.js, React, Vue, HTML/CSS সব ফ্রেমওয়ার্ক সাপোর্ট',
      'অটোমেটিক গিট সিঙ্ক (Git push = Live Deploy)',
      'ফ্রি প্রিভিউ লিঙ্ক ও কাস্টম ডোমেন ইন্টিগ্রেশন',
      'সুপারফাস্ট এজ নেটওয়ার্ক (Edge CDN)'
    ],
    pros: [
      'বর্তমানে সিলিকন ভ্যালির সবচেয়ে জনপ্রিয় হোস্টিং প্ল্যাটফর্ম',
      'লাইভ প্রিভিউ লিঙ্ক তৈরি করে অন্যদের দেখাতে পারেন',
      'আনলিমিটেড ফ্রি ওয়েবসাইট ডিপ্লয়মেন্ট'
    ],
    cons: [
      'প্রফেশনাল ডেভেলপার ফ্রেমওয়ার্কের জন্য বেশি অপ্টিমাইজড'
    ],
    bestFor: 'রিঅ্যাক্ট, ভিটে, নেক্সট.জেএস এবং মডার্ন ওয়েব প্রজেক্ট তৈরির জন্য।',
    officialUrl: 'https://vercel.com',
    steps: [
      {
        title: 'ধাপ ১: vercel.com এ সাইন আপ করুন',
        description: 'আপনার GitHub অ্যাকাউন্ট দিয়ে Vercel এ সাইন ইন করুন।'
      },
      {
        title: 'ধাপ ২: Add New Project এ ক্লিক করুন',
        description: 'আপনার গিটহাবের যেকোনো প্রজেক্ট রিপোজিটরি বেছে নিন।'
      },
      {
        title: 'ধাপ ৩: "Deploy" বাটনে ক্লিক করুন',
        description: 'ভার্সেল স্বয়ংক্রিয়ভাবে আপনার কোড স্ক্যান করে ১৫ সেকেন্ডের ভেতর লাইভ URL তৈরি করে দেবে।'
      }
    ]
  },
  {
    id: 'canva-websites',
    name: 'Canva Websites',
    category: 'no-code',
    logoText: 'Canva',
    badge: 'ডিজাইনারদের মতো চোখজুড়ানো সাইট',
    difficulty: 'খুবই সহজ (Beginner)',
    difficultyEn: 'Very Easy',
    timeNeeded: '১০-২০ মিনিট',
    freeUrlFormat: 'yourname.my.canva.site',
    freeTierFeatures: [
      'হাজার হাজার প্রিমিয়াম গ্রাফিক্স ও টেমপ্লেট',
      'ফ্রি canva.site ডোমেইন ও ফ্রি হোস্টিং',
      'ড্র্যাগ-অ্যান্ড-ড্রপ গ্রাফিক্স আর্টবোর্ড'
    ],
    pros: [
      'অবিশ্বাস্য ভিজ্যুয়াল ডিজাইন ও ফটো লাইব্রেরি',
      'সোশ্যাল মিডিয়া পেজের মতো সহজে ব্যানার ও টেক্সট সরানো যায়'
    ],
    cons: [
      'প্রথাগত এসইও (Search Engine Optimization) সীমিত',
      'ডাইনামিক ফিচার বা ফর্ম ফাংশন সীমিত'
    ],
    bestFor: 'রেস্তোরাঁর মেনু কার্ড, ওয়েডিং ইনভাইটেশন, ফটোগ্রাফি শোকেস ও ফ্যাশন পোর্টফোলিও।',
    officialUrl: 'https://www.canva.com/websites',
    steps: [
      {
        title: 'ধাপ ১: Canva তে "Website" লিখে সার্চ করুন',
        description: 'ক্যানভা ওপেন করে সার্চ বক্সে "Websites" লিখলে শত শত সুন্দর রেডি ডিজাইন দেখতে পাবেন।'
      },
      {
        title: 'ধাপ ২: আপনার পছন্দমতো কাস্টমাইজ করুন',
        description: 'নাম, ছবি ও সোশ্যাল মিডিয়া লিঙ্ক বসিয়ে সাজান।'
      },
      {
        title: 'ধাপ ৩: "Publish Website" বাটনে ক্লিক করুন',
        description: 'Free domain অপশন নির্বাচন করে আপনার সাইটের নাম দিয়ে লাইভ করুন।'
      }
    ]
  },
  {
    id: 'blogger',
    name: 'Blogger (Google)',
    category: 'blog-cms',
    logoText: 'Blogger',
    badge: 'আজীবন ফ্রি ব্লগিং ও অ্যাডসেন্স ইনকাম',
    difficulty: 'খুবই সহজ (Beginner)',
    difficultyEn: 'Very Easy',
    timeNeeded: '১০ মিনিট',
    freeUrlFormat: 'yourblog.blogspot.com',
    freeTierFeatures: [
      'গুগলের আনলিমিটেড স্টোরেজ ও ব্যান্ডউইথ',
      'Google AdSense দিয়ে সরাসরি টাকা ইনকাম করার সুযোগ',
      'আজীবন ১০০% ফ্রি হোস্টিং'
    ],
    pros: [
      'কোনো লিমিট নেই, যত খুশি আর্টিকেল ও ভিজিটর আসতে পারবে',
      'গুগল সার্চে খুব দ্রুত র‍্যাংক করে'
    ],
    cons: [
      'ডিজাইন কিছুটা ক্লাসিক ধরনের',
      'প্রথাগত অ্যাপ বা ইন্টারঅ্যাক্টিভ সাইটের জন্য নয়'
    ],
    bestFor: 'নিউজ সাইট, ব্লগিং, আর্টিকেল রাইটিং এবং ব্লগ দিয়ে টাকা আয় করতে আগ্রহীদের জন্য।',
    officialUrl: 'https://www.blogger.com',
    steps: [
      {
        title: 'ধাপ ১: blogger.com এ যান',
        description: 'Create Your Blog বাটনে ক্লিক করে জিমেইল দিয়ে সাইন ইন করুন।'
      },
      {
        title: 'ধাপ ২: ব্লগের নাম ও অ্যাড্রেস বেছে নিন',
        description: 'আপনার ব্লগের নাম দিন এবং ফ্রি সাবডোমেন ঠিক করুন (যেমন: techbangla.blogspot.com)।'
      },
      {
        title: 'ধাপ ৩: পোস্ট লিখুন ও থিম সেট করুন',
        description: 'Theme অপশন থেকে সুন্দর ডিজাইন বেছে নিন এবং প্রথম পোস্ট লিখে পাবলিশ করুন।'
      }
    ]
  }
];

export interface QuizQuestion {
  id: number;
  question: string;
  options: {
    label: string;
    description: string;
    points: {
      'google-sites'?: number;
      'netlify-drop'?: number;
      'github-pages'?: number;
      'canva-websites'?: number;
      'blogger'?: number;
      'vercel'?: number;
    };
  }[];
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'আপনার ওয়েবসাইট তৈরির মূল উদ্দেশ্য কী?',
    options: [
      {
        label: 'ব্যক্তিগত পোর্টফোলিও বা সিভি (CV / Portfolio)',
        description: 'আমার কাজ, অভিজ্ঞতা ও লিঙ্কগুলো সুন্দর করে মানুষকে দেখাব।',
        points: { 'netlify-drop': 3, 'github-pages': 3, 'google-sites': 2 }
      },
      {
        label: 'ছোট ব্যবসা, সার্ভিস বা দোকানের তথ্য পেজ',
        description: 'আমার দোকানের ঠিকানা, সেবাসমূহ এবং হোয়াটসঅ্যাপ কন্টাক্ট বাটন থাকবে।',
        points: { 'google-sites': 4, 'canva-websites': 3, 'netlify-drop': 2 }
      },
      {
        label: 'ব্লগ বা আর্টিকেল লিখে ভিজিটর ও ইনকাম',
        description: 'নিয়মিত লেখালেখি করব এবং গুগল সার্চ থেকে ভিজিটর আনব।',
        points: { 'blogger': 5, 'google-sites': 1 }
      },
      {
        label: 'কোডিং প্রজেক্ট / ডেভেলপার ওয়েবসাইট শোকেস',
        description: 'আমি কোডিং শিখছি বা সফটওয়্যার বানিয়ে ইন্টারনেটে লাইভ করতে চাই।',
        points: { 'github-pages': 4, 'vercel': 4, 'netlify-drop': 3 }
      }
    ]
  },
  {
    id: 2,
    question: 'কোডিং (HTML, CSS, JavaScript) সম্পর্কে আপনার অভিজ্ঞতা কেমন?',
    options: [
      {
        label: 'একদমই কোনো কোডিং জানি না (Zero Coding)',
        description: 'আমি মাউস দিয়ে টেনে এনে সহজে ছবি ও টেক্সট বসাতে চাই।',
        points: { 'google-sites': 4, 'canva-websites': 4, 'blogger': 2 }
      },
      {
        label: 'রেডিমেড কোড কপি-পেস্ট বা এডিট করতে পারি',
        description: 'আমাকে ভালো একটা টেমপ্লেট কোড দিলে আমি নাম-ছবি বদলে নিতে পারব।',
        points: { 'netlify-drop': 5, 'github-pages': 3, 'google-sites': 1 }
      },
      {
        label: 'হ্যাঁ, আমি কোডিং পারি বা শিখতে চাই',
        description: 'আমি নিজের কোড লিখে প্রফেশনালভাবে গিটহাবে আপলোড করতে প্রস্তুত।',
        points: { 'github-pages': 5, 'vercel': 4, 'netlify-drop': 3 }
      }
    ]
  },
  {
    id: 3,
    question: 'আপনি কত সময় ব্যয় করতে চান?',
    options: [
      {
        label: 'মাত্র ৫ থেকে ১০ মিনিট',
        description: 'খুব দ্রুত আজকেই একটা লাইভ সাইটের লিঙ্ক দরকার।',
        points: { 'netlify-drop': 4, 'google-sites': 4, 'canva-websites': 3 }
      },
      {
        label: 'আধা ঘণ্টা থেকে ১ ঘণ্টা',
        description: 'ভালোভাবে বুঝে-শুনে সুন্দর একটি সাইট বানাতে চাই।',
        points: { 'github-pages': 4, 'google-sites': 3, 'netlify-drop': 3 }
      },
      {
        label: 'যতক্ষণ লাগে, ভবিষ্যতে নিজের ক্যারিয়ারের জন্য শিখব',
        description: 'প্রফেশনাল ডেভেলপার স্ট্যান্ডার্ড টুলস শিখতে আগ্রহী।',
        points: { 'github-pages': 5, 'vercel': 4 }
      }
    ]
  }
];

export const PRE_LAUNCH_CHECKLIST = [
  { id: 'c1', text: 'সবগুলো বাটন এবং লিঙ্কে সঠিক ইউআরএল বা হোয়াটসঅ্যাপ নম্বর যুক্ত আছে', category: 'লিঙ্ক ও কার্যক্ষমতা' },
  { id: 'c2', text: 'মোবাইল ফোনে পেজটি পরিষ্কার ও রেসপনসিভ দেখাচ্ছে (কোনো লেখা কেটে যাচ্ছে না)', category: 'মোবাইল টেস্ট' },
  { id: 'c3', text: 'সাইটের টাইটেল (Title) এবং মেটা ডেসক্রিপশন সেট করা হয়েছে', category: 'এসইও (SEO)' },
  { id: 'c4', text: 'ফটো এবং ইমেজগুলোর সাইজ খুব ভারী নয় (দ্রুত লোড হওয়ার জন্য অপ্টিমাইজড)', category: 'স্পিড' },
  { id: 'c5', text: 'ডেমো টেক্সট (Lorem Ipsum) বদলে নিজের আসল তথ্য বসানো হয়েছে', category: 'কন্টেন্ট' },
  { id: 'c6', text: 'যোগাযোগের ফর্ম বা ইমেইল লিঙ্ক কাজ করছে কি না একবার নিজে ক্লিক করে টেস্ট করা হয়েছে', category: 'টেস্টিং' },
  { id: 'c7', text: 'ব্রাউজারে প্যাডলক আইকন (HTTPS / SSL সিকিউরিটি) সক্রিয় আছে', category: 'নিরাপত্তা' }
];

export const FAQS = [
  {
    question: 'ওয়েবসাইট কি সত্যিই সম্পূর্ণ ফ্রিতে আজীবন রাখা সম্ভব?',
    answer: 'হ্যাঁ, ১০০% সম্ভব! GitHub Pages, Netlify, Vercel, এবং Google Sites-এর মতো গ্লোবাল টেক জায়ান্টরা ব্যক্তিগত ওয়েবসাইট, পোর্টফোলিও ও শিক্ষামূলক প্রজেক্টের জন্য সম্পূর্ণ বিনামূল্যে আজীবন ফ্রি টিয়ার প্রদান করে। কোনো হিডেন চার্জ বা সাবস্ক্রিপশন ফি থাকে না।'
  },
  {
    question: 'ফ্রি ওয়েবসাইটে কি কাস্টম ডোমেইন (যেমন .com বা .org) লাগানো যায়?',
    answer: 'অবশ্যই যায়! GitHub Pages, Netlify এবং Google Sites-এ আপনি নিজের কেনা যেকোনো .com, .net বা .org ডোমেন সম্পূর্ণ ফ্রিতে যুক্ত করতে পারবেন। কোনো বাড়তি হোস্টিং ফি দিতে হবে না, শুধু ডোমেন কেনার সাধারণ বার্ষিক ফি (সাধারণত ৮-১০ ডলার) লাগবে।'
  },
  {
    question: 'মোবাইল ফোন দিয়ে কি ওয়েবসাইট বানিয়ে পাবলিশ করা সম্ভব?',
    answer: 'হ্যাঁ! Google Sites, Canva Sites এবং Blogger মোবাইল ব্রাউজার দিয়েই সম্পূর্ণ তৈরি ও পাবলিশ করা যায়। আর কোডিং সাইটের ক্ষেত্রে মোবাইলে কোড লিখে Netlify Drop বা GitHub এর ওয়েব ইন্টারফেস দিয়ে আপলোড করে লাইভ করা যায়।'
  },
  {
    question: 'ফ্রি ওয়েবসাইটে কি কোনো বিজ্ঞাপন (Ads) দেখাবে?',
    answer: 'Netlify, GitHub Pages, Vercel বা Google Sites-এ কোনো বিরক্তিকর বিজ্ঞাপন আসে না। এগুলো সম্পূর্ণ বিজ্ঞাপনমুক্ত ক্লিন প্ল্যাটফর্ম।'
  },
  {
    question: 'ওয়েবসাইট পাবলিশ করার পর কি পরে পরিবর্তন (Update) করা যায়?',
    answer: 'হ্যাঁ, যেকোনো সময়! আপনার ফাইল বা কন্টেন্ট পরিবর্তন করে পুনরায় সেভ বা আপলোড করলেই সাথে সাথে লাইভ ওয়েবসাইটে সেই পরিবর্তন চলে আসে।'
  }
];
