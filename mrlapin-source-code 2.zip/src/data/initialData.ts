import { Product, PaymentGatewayConfig, DepositRecord, OrderRecord, UserCodeRecord, SiteSettings, UserProfile, RecentOrderItem } from '../types';

export const INITIAL_SITE_SETTINGS: SiteSettings = {
  siteName: 'MR LAPIN',
  telegramPopupEnabled: true,
  telegramPopupTitle: 'Join Our Official Telegram Community',
  telegramPopupDesc: 'Stay connected with MR LAPIN! Get all the latest notices, important updates, announcements, and dedicated customer support directly through our official Telegram.',
  telegramLink: 'https://t.me/mrlapin_official',
  telegramDmLink: 'https://t.me/mrlapin_admin',
  telegramBenefits: ['Important Notices', 'Latest Updates', 'Announcements', 'Customer Support'],
  noticeMarquee: '🔥 Notice: Trusted, Fast & Reliable Service with 24/7 Support ❤️ Your Satisfaction Is Our Priority! ⚡ Instant Automated Delivery — For any issue or help, DM Telegram @mrlapin_admin or WhatsApp +8801813913894',
  supportPhone: '+8801813913894',
  supportWhatsapp: '8801813913894',
  bannerTitle: 'কীভাবে প্যানেল কিনবেন?',
  bannerSubtitle: 'নিরাপদ, দ্রুত ও বিশ্বস্ত সেবা · ইনস্ট্যান্ট অটোমেটেড ডেলিভারি ও ২৪/৭ ডেডিকেটেড সাপোর্ট',
  bannerVideoUrl: 'https://youtube.com',
  heroSlides: [
    {
      id: 'slide_1',
      badge: 'OFFICIAL VIP PANEL 2026',
      title: 'কীভাবে প্যানেল কিনবেন?',
      subtitle: 'নিরাপদ, দ্রুত ও বিশ্বস্ত সেবা · ইনস্ট্যান্ট অটোমেটেড ডেলিভারি ও ২৪/৭ ডেডিকেটেড সাপোর্ট',
      buttonText: 'টিউটোরিয়াল দেখুন',
      link: 'https://youtube.com',
      logoOrImage: '',
      tags: ['100% FAST SERVICE', 'SECURE PAYMENT', '24/7 SUPPORT'],
      bgGradient: 'from-red-950 via-slate-900 to-indigo-950'
    },
    {
      id: 'slide_2',
      badge: 'AUTO BALANCE ADD',
      title: 'bKash ও Nagad-এ অটোমেটিক এড ফান্ড',
      subtitle: 'টাকা পাঠিয়ে ট্রানজেকশন আইডি (TrxID) দিলে সাথে সাথে ওয়ালেটে টাকা এড হয়ে যাবে!',
      buttonText: 'Add Fund করুন',
      link: '#add_fund',
      logoOrImage: '',
      tags: ['INSTANT CREDIT', '0% FEE', 'BKASH & NAGAD'],
      bgGradient: 'from-indigo-950 via-slate-900 to-emerald-950'
    },
    {
      id: 'slide_3',
      badge: 'TELEGRAM VIP CHANNEL',
      title: 'টেলিগ্রাম অফিসিয়াল গ্রুপে যুক্ত হন',
      subtitle: 'সব নোটিশ, ডিসকাউন্ট অফার এবং ২৪ ঘণ্টা লাইভ এডমিন সাপোর্টের জন্য জয়েন করুন।',
      buttonText: 'টেলিগ্রামে জয়েন হন',
      link: 'https://t.me/mrlapin_official',
      logoOrImage: '',
      tags: ['DAILY UPDATES', 'GIVEAWAY', '24/7 LIVE SUPPORT'],
      bgGradient: 'from-blue-950 via-slate-900 to-purple-950'
    }
  ],
  maintenanceMessage: 'Our servers are currently undergoing routine optimization. We will be back online shortly!',
  isGlobalMaintenance: false
};

export const INITIAL_USER: UserProfile = {
  id: '',
  name: 'Guest User',
  email: '',
  phone: '',
  balance: 0,
  totalOrders: 0,
  totalSpent: 0,
  supportPin: '',
  isLoggedIn: false
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod_phantom',
    name: 'PHANTOM ANDROID + IOS',
    category: 'non_root',
    basePrice: 20,
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'Phantom External Non-Root VIP Menu. Safe anti-ban bypass, high FPS aim-assist, ESP skeleton & bullet tracking for Android and iOS.',
    appLink: 'https://t.me/mrlapin_official/phantom-download',
    videoLink: 'https://youtube.com',
    packages: [
      {
        id: 'p1',
        name: 'PHANTOM - 1 HOUR',
        duration: '1 Hour',
        price: 20,
        status: 'online',
        keysPool: ['PHANTOM-1H-8921-XKQ', 'PHANTOM-1H-4412-ZPM', 'PHANTOM-1H-9012-LKA', 'PHANTOM-1H-2311-BCR']
      },
      {
        id: 'p2',
        name: 'PHANTOM - 3 HOUR',
        duration: '3 Hours',
        price: 50,
        status: 'online',
        keysPool: ['PHANTOM-3H-7721-OPQ', 'PHANTOM-3H-1190-VBN']
      },
      {
        id: 'p3',
        name: 'PHANTOM - 6 HOUR',
        duration: '6 Hours',
        price: 80,
        status: 'out_of_stock',
        keysPool: []
      },
      {
        id: 'p4',
        name: 'PHANTOM - 12 HOUR',
        duration: '12 Hours',
        price: 120,
        status: 'online',
        keysPool: ['PHANTOM-12H-5501-TYU', 'PHANTOM-12H-8832-KLM']
      },
      {
        id: 'p5',
        name: 'PHANTOM - 24 HOUR',
        duration: '24 Hours',
        price: 200,
        status: 'online',
        keysPool: ['PHANTOM-24H-9921-ZQA', 'PHANTOM-24H-3341-WEP']
      },
      {
        id: 'p6',
        name: 'PHANTOM - 72 HOUR / 3DAYS',
        duration: '3 Days',
        price: 299,
        status: 'out_of_stock',
        keysPool: []
      },
      {
        id: 'p7',
        name: 'PHANTOM - 168 HOUR / 7DAYS',
        duration: '7 Days',
        price: 550,
        status: 'online',
        keysPool: ['PHANTOM-7D-8821-MKO']
      },
      {
        id: 'p8',
        name: 'PHANTOM - 720 HOUR / 30DAYS',
        duration: '30 Days',
        price: 1199,
        status: 'out_of_stock',
        keysPool: []
      }
    ]
  },
  {
    id: 'prod_drip_wire',
    name: 'DRIP WIRE EXTERNAL - SAFE',
    category: 'non_root',
    basePrice: 30,
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'Drip Wire v4.2 External Non-Root injector. Maximum security with zero risk bypass for tournaments and rank push.',
    packages: [
      {
        id: 'dw1',
        name: 'DRIP WIRE - 2 HOURS',
        duration: '2 Hours',
        price: 30,
        status: 'online',
        keysPool: ['DRIP-2H-4491-BBN', 'DRIP-2H-8832-VCZ']
      },
      {
        id: 'dw2',
        name: 'DRIP WIRE - 24 HOURS',
        duration: '1 Day',
        price: 150,
        status: 'online',
        keysPool: ['DRIP-24H-1102-LLK']
      },
      {
        id: 'dw3',
        name: 'DRIP WIRE - 7 DAYS',
        duration: '7 Days',
        price: 450,
        status: 'online',
        keysPool: ['DRIP-7D-9002-QWE']
      }
    ]
  },
  {
    id: 'prod_balamod',
    name: 'BalaMod Non Root',
    category: 'non_root',
    basePrice: 20,
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'BalaMod Pro Menu for non-rooted devices. 100% headshot accuracy, fast fire rate, smooth menu UI.',
    packages: [
      {
        id: 'bm1',
        name: '1 HOURS BALA',
        duration: '1 Hour',
        price: 20,
        status: 'online',
        keysPool: ['BALA-1H-9921-ASX', 'BALA-1H-3312-PLM']
      },
      {
        id: 'bm2',
        name: '2 HOURS BALA',
        duration: '2 Hours',
        price: 35,
        status: 'online',
        keysPool: ['BALA-2H-7712-QWE']
      },
      {
        id: 'bm3',
        name: '24 HOURS BALA',
        duration: '24 Hours',
        price: 180,
        status: 'online',
        keysPool: ['BALA-24H-5511-POI']
      }
    ]
  },
  {
    id: 'prod_aimhack',
    name: 'AIM HACK - NON ROOT + IOS',
    category: 'non_root',
    basePrice: 15,
    image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=600&q=80',
    status: 'maintenance',
    customBadge: 'UNDER MAINTENANCE - BACK SOON',
    description: 'Currently undergoing server update for the new OB44 patch. Will be back online with enhanced security.',
    packages: [
      { id: 'ah1', name: 'AIM HACK - 1 HOUR', duration: '1 Hour', price: 15, status: 'out_of_stock', keysPool: [] },
      { id: 'ah2', name: 'AIM HACK - 3 HOURS', duration: '3 Hours', price: 40, status: 'out_of_stock', keysPool: [] }
    ]
  },
  {
    id: 'prod_trollmodz',
    name: 'TROLL MODZ NON ROOT + IOS',
    category: 'non_root',
    basePrice: 20,
    image: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=600&q=80',
    status: 'out_of_stock',
    customBadge: 'OUT OF STOCK',
    description: 'All license keys for Troll Modz are currently exhausted. Next batch will be released via Telegram announcement.',
    packages: [
      { id: 'tm1', name: 'TROLL MODZ - 1 HOUR', duration: '1 Hour', price: 20, status: 'out_of_stock', keysPool: [] }
    ]
  },
  {
    id: 'prod_xreg',
    name: 'X-REG NON ROOT',
    category: 'non_root',
    basePrice: 20,
    image: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'X-Reg sensitivity enhancer and drag-headshot optimizer. Works on all 60Hz and 120Hz displays.',
    packages: [
      { id: 'xr1', name: 'X-REG - 24 HOURS', duration: '24 Hours', price: 20, status: 'online', keysPool: ['XREG-24H-8821-AAA'] },
      { id: 'xr2', name: 'X-REG - 7 DAYS', duration: '7 Days', price: 90, status: 'online', keysPool: ['XREG-7D-4412-BBB'] }
    ]
  },
  {
    id: 'prod_xyz_cheats',
    name: 'XYZ CHEATS APKMOD',
    category: 'non_root',
    basePrice: 20,
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80',
    status: 'not_available',
    customBadge: 'THIS PRODUCT NOT AVAILABLE',
    description: 'This version is deprecated due to game security patch. Please choose Phantom or Drip Wire instead.',
    packages: [
      { id: 'xyz1', name: 'XYZ - 1 HOUR', duration: '1 Hour', price: 20, status: 'out_of_stock' }
    ]
  },
  {
    id: 'prod_haxxcker',
    name: 'HAXXCKER PRO - ROOT',
    category: 'root',
    basePrice: 490,
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'Rooted Kernel Module (KernelSU / Magisk / APatch). Zero memory touch, 100% undetected by server anti-cheat.',
    packages: [
      { id: 'hx1', name: 'HAXXCKER PRO - 7 DAYS', duration: '7 Days', price: 490, status: 'online' },
      { id: 'hx2', name: 'HAXXCKER PRO - 30 DAYS', duration: '30 Days', price: 1250, status: 'online' }
    ]
  },
  {
    id: 'prod_angry_mod',
    name: 'ANGRY MODD ROOT ONLY',
    category: 'root',
    basePrice: 70,
    image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'Magisk Module for rooted gamers. Direct hardware memory injection with smooth recoil stabilization.',
    packages: [
      { id: 'am1', name: 'ANGRY MODD - 24 HOURS', duration: '24 Hours', price: 70, status: 'online' },
      { id: 'am2', name: 'ANGRY MODD - 7 DAYS', duration: '7 Days', price: 280, status: 'online' }
    ]
  },
  {
    id: 'prod_ios_esign',
    name: 'IOS ESIGN / GBOX CERTIFICATE 1 YEARS',
    category: 'iphone',
    basePrice: 499,
    image: 'https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'Apple Developer Enterprise Certificate for iOS. Install any IPA without revoke for 365 days with instant UDID activation.',
    packages: [
      { id: 'ios1', name: 'ESIGN / GBOX - 1 YEAR VALIDITY', duration: '1 Year', price: 499, status: 'online' }
    ]
  },
  {
    id: 'prod_migul_pro',
    name: 'MIGUL PRO - IPHONE PANEL',
    category: 'iphone',
    basePrice: 799,
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'Direct Dylib tweak for jailed/jailbroken iPhones. Aimkill, Show FOV Circle, Ignore Knocked, 120 FPS unlock.',
    packages: [
      { id: 'mp1', name: 'MIGUL PRO - 30 DAYS', duration: '30 Days', price: 799, status: 'online' }
    ]
  },
  {
    id: 'prod_aimbot_pc',
    name: 'AIMBOT EXE PC - Safe',
    category: 'pc',
    basePrice: 99,
    image: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'Bluestacks / MSI App Player external emulator injector. Memory-free aim bot with high precision.',
    packages: [
      { id: 'pc1', name: 'AIMBOT EXE - 24 HOURS', duration: '24 Hours', price: 99, status: 'online' },
      { id: 'pc2', name: 'AIMBOT EXE - 7 DAYS', duration: '7 Days', price: 350, status: 'online' }
    ]
  },
  {
    id: 'prod_rextron_pc',
    name: 'RexTron Basic - PC',
    category: 'pc',
    basePrice: 850,
    image: 'https://images.unsplash.com/photo-1547394765-185e1e68f34e?auto=format&fit=crop&w=600&q=80',
    status: 'online',
    description: 'Professional PC tournament bypass. Auto DPI switch, instant bullet registration, clean OBS streaming proof.',
    packages: [
      { id: 'rt1', name: 'REXTRON BASIC - 30 DAYS', duration: '30 Days', price: 850, status: 'online' }
    ]
  }
];

export const INITIAL_GATEWAYS: PaymentGatewayConfig[] = [
  {
    id: 'bkash',
    name: 'bKash Payment',
    subType: 'Personal / Send Money',
    numberOrAddress: '018813913894',
    minAmount: 10,
    maxAmount: 50000,
    instructions: 'bKash অ্যাপ বা *247# ডায়াল করে "Send Money" করুন। টাকা পাঠানোর পর ট্রানজেকশন আইডি (TrxID) ও আপনার নম্বরটি নিচে সাবমিট করুন।',
    isActive: true,
    color: '#e2136e'
  },
  {
    id: 'nagad',
    name: 'Nagad Payment',
    subType: 'Personal / Send Money',
    numberOrAddress: '018813913894',
    minAmount: 10,
    maxAmount: 50000,
    instructions: 'নগদ অ্যাপ বা *167# ডায়াল করে "Send Money" করুন। টাকা পাঠানো সম্পন্ন হলে SMS থেকে পাওয়া TrxID ও নম্বর নিচে লিখুন।',
    isActive: true,
    color: '#f7941d'
  },
  {
    id: 'rocket',
    name: 'Rocket Payment',
    subType: 'Personal / Send Money',
    numberOrAddress: '018813913894',
    minAmount: 10,
    maxAmount: 50000,
    instructions: 'রকেট একাউন্ট থেকে "Send Money" করুন। ট্রানজেকশন আইডি সাবমিট করার ১-৫ মিনিটের মধ্যে ব্যালেন্স যুক্ত হবে।',
    isActive: true,
    color: '#8c3494'
  },
  {
    id: 'binance',
    name: 'Binance Pay (USDT)',
    subType: 'Crypto / Global',
    numberOrAddress: 'UID: 489201948',
    minAmount: 10,
    maxAmount: 100000,
    rateInfo: '1 USDT = 125 BDT',
    instructions: 'Binance Pay দিয়ে উল্লেখিত UID তে USDT পাঠান। Order ID বা Pay ID সাবমিট করুন।',
    isActive: true,
    color: '#f0b90b'
  },
  {
    id: 'indiapay',
    name: 'IndiaPay UPI',
    subType: 'Paytm / PhonePe / GPay',
    numberOrAddress: 'mrlapin@ybl',
    minAmount: 10,
    maxAmount: 100000,
    rateInfo: '1 INR = 1.4 BDT',
    instructions: 'Pay via PhonePe, Paytm, or GooglePay using UPI ID. Enter the UTR / Reference ID below.',
    isActive: true,
    color: '#00b9f5'
  }
];

export const INITIAL_DEPOSITS: DepositRecord[] = [];

export const INITIAL_ORDERS: OrderRecord[] = [];

export const INITIAL_CODES: UserCodeRecord[] = [];

export const INITIAL_RECENT_ORDERS: RecentOrderItem[] = [
  { id: 'ro_1', user: 'Melissa aan', product: 'PHANTOM - 12 HOUR', price: '৳ 120', avatarBg: 'bg-indigo-600' },
  { id: 'ro_2', user: 'GamingWithTanvir', product: 'ESIGN/GBOX - 1 Years Validity', price: '৳ 499', avatarBg: 'bg-purple-600' },
  { id: 'ro_3', user: 'Sanzim', product: 'PHANTOM - 1 HOUR', price: '৳ 20', avatarBg: 'bg-blue-600' },
  { id: 'ro_4', user: 'runa islam', product: 'PHANTOM - 1 HOUR', price: '৳ 20', avatarBg: 'bg-pink-600' },
  { id: 'ro_5', user: 'DEEPAK "Sangar naik" BHAI', product: 'PHANTOM - 3 HOUR', price: '৳ 50', avatarBg: 'bg-emerald-600' },
  { id: 'ro_6', user: 'Hamim Hasan', product: '1 HOURS BALA', price: '৳ 20', avatarBg: 'bg-amber-600' },
  { id: 'ro_7', user: 'Shohel Rana', product: 'PHANTOM - 720 HOUR / 30DAYS', price: '৳ 1,199', avatarBg: 'bg-red-600' },
  { id: 'ro_8', user: 'Rofikul Islam', product: 'PHANTOM - 1 HOUR', price: '৳ 20', avatarBg: 'bg-cyan-600' }
];

export const COMMUNITY_RECENT_ORDERS = INITIAL_RECENT_ORDERS;
