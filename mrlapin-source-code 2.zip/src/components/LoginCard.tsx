import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { GoogleAuthModal } from './GoogleAuthModal';
import { TelegramAuthModal } from './TelegramAuthModal';
import { 
  Lock, 
  Mail, 
  User, 
  Phone, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Send, 
  KeyRound,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { evaluatePasswordStrength } from '../utils/security';

interface LoginCardProps {
  initialMode?: 'login' | 'register';
  onSuccess?: () => void;
  showCardHeader?: boolean;
}

export const LoginCard: React.FC<LoginCardProps> = ({ 
  initialMode = 'login', 
  onSuccess,
  showCardHeader = true 
}) => {
  const { 
    loginWithCredentials, 
    loginWithGoogle, 
    loginWithTelegram, 
    registerAccount, 
    resetPasswordWithPin,
    isDarkMode 
  } = useStore();

  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [showTelegramModal, setShowTelegramModal] = useState(false);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Register specific states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Forgot password specific states
  const [supportPin, setSupportPin] = useState('');
  const [newPassword, setNewPassword] = useState('');

  // Status & feedback
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [lockoutSeconds, setLockoutSeconds] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Password strength
  const passStrength = evaluatePasswordStrength(mode === 'register' ? password : newPassword);

  // Lockout countdown timer
  useEffect(() => {
    if (lockoutSeconds <= 0) return;
    const interval = setInterval(() => {
      setLockoutSeconds((prev) => {
        if (prev <= 1) {
          setErrorMsg(null);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [lockoutSeconds]);

  // Handle Login Submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (lockoutSeconds > 0) {
      setErrorMsg(`অতিরিক্ত ভুল চেষ্টার কারণে সিস্টেম সাময়িক লক রয়েছে। দয়া করে ${lockoutSeconds} সেকেন্ড অপেক্ষা করুন।`);
      return;
    }

    if (!email.trim() || !password) {
      setErrorMsg('ইমেইল এবং পাসওয়ার্ড উভয়ই প্রদান করুন।');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = loginWithCredentials(email.trim(), password);
      setIsSubmitting(false);

      if (res.success) {
        setSuccessMsg(res.message);
        setTimeout(() => {
          if (onSuccess) onSuccess();
        }, 1000);
      } else {
        setErrorMsg(res.message);
        if (res.remainingSeconds) {
          setLockoutSeconds(res.remainingSeconds);
        }
      }
    }, 400);
  };

  // Handle Register Submit
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!name.trim() || !email.trim() || !password) {
      setErrorMsg('দয়া করে নাম, ইমেইল এবং পাসওয়ার্ড পূরণ করুন।');
      return;
    }

    if (password.length < 6) {
      setErrorMsg('পাসওয়ার্ড ন্যূনতম ৬ অক্ষরের হতে হবে।');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg('পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড মিলছে না।');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = registerAccount({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim() || '01800000000',
        password
      });
      setIsSubmitting(false);

      if (res.success) {
        setSuccessMsg(res.message);
        setTimeout(() => {
          if (onSuccess) onSuccess();
        }, 1200);
      } else {
        setErrorMsg(res.message);
      }
    }, 400);
  };

  // Handle Forgot Password Submit
  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!email.trim() || !supportPin.trim() || !newPassword) {
      setErrorMsg('ইমেইল, ৪-ডিজিটের সাপোর্ট পিন ও নতুন পাসওয়ার্ড দিন।');
      return;
    }

    if (newPassword.length < 6) {
      setErrorMsg('নতুন পাসওয়ার্ড ন্যূনতম ৬ অক্ষরের হতে হবে।');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = resetPasswordWithPin(email.trim(), supportPin.trim(), newPassword);
      setIsSubmitting(false);

      if (res.success) {
        setSuccessMsg(res.message);
        setTimeout(() => {
          setMode('login');
          setPassword('');
          setSuccessMsg(null);
        }, 1800);
      } else {
        setErrorMsg(res.message);
      }
    }, 400);
  };

  return (
    <>
      <div
        className={`w-full max-w-md mx-auto rounded-3xl p-6 sm:p-8 transition-all border shadow-xl ${
          isDarkMode
            ? 'bg-slate-900/95 border-slate-800 text-white shadow-black/40'
            : 'bg-white border-slate-200 text-slate-900 shadow-slate-200/60'
        }`}
      >
        {/* Anti-Hack Shield Pill (Security Enhancer) */}
        <div className="flex items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-100 dark:border-slate-800 text-3xs">
          <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-500 animate-pulse shrink-0" />
            <span>Anti-Hack & Brute-Force Shield Active</span>
          </div>
          <span className="px-2 py-0.5 rounded-full font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">
            SSL 256-BIT
          </span>
        </div>

        {/* Title Zone matching IMG_1243 */}
        {showCardHeader && (
          <div className="mb-6">
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {mode === 'login' && 'Login'}
              {mode === 'register' && 'Register'}
              {mode === 'forgot' && 'Reset Password'}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {mode === 'login' && 'Sign in to access your dashboard, keys & balance'}
              {mode === 'register' && 'Create a safe account to purchase Free Fire VIP panels'}
              {mode === 'forgot' && 'Enter your registered email and support PIN to recover'}
            </p>
          </div>
        )}

        {/* 1. Login with Google / Mobile Gmail (Primary Action) */}
        <div className="space-y-2.5">
          <button
            type="button"
            onClick={() => setShowGoogleModal(true)}
            className="w-full py-3 px-4 rounded-xl border border-slate-300 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500 bg-white dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 shadow-xs hover:shadow-md transition transform active:scale-98 cursor-pointer group"
          >
            {/* Multi-color Google G Icon */}
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>মোবাইলের Gmail দিয়ে লগইন করুন (Google Sign In)</span>
          </button>
        </div>

        {/* Divider matching IMG_1243: "Or sign in with credentials" */}
        <div className="relative flex items-center justify-center my-6">
          <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
          <span className="bg-white dark:bg-slate-900 px-3 text-2xs font-semibold text-slate-400 select-none whitespace-nowrap absolute">
            {mode === 'login' && 'Or sign in with credentials'}
            {mode === 'register' && 'Or register with credentials'}
            {mode === 'forgot' && 'Or recover your account'}
          </span>
        </div>

        {/* Error / Lockout Banner */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-500 text-xs flex items-start gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="flex-1 font-semibold leading-relaxed">
              {errorMsg}
            </div>
          </div>
        )}

        {/* Lockout Countdown Alert */}
        {lockoutSeconds > 0 && (
          <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-500 text-xs flex items-center gap-2 font-bold animate-pulse">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>সিকিউরিটি প্রতিরোধ: আনলক হতে আর {lockoutSeconds} সেকেন্ড অপেক্ষা করুন</span>
          </div>
        )}

        {/* Success Alert */}
        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 text-xs flex items-center gap-2 font-bold animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* MODE: LOGIN (Exact Form Matching IMG_1243) */}
        {mode === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            {/* Email Field */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Email
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="w-full pl-3.5 pr-10 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Red / Coral Login Button (Matching IMG_1243) */}
            <button
              type="submit"
              disabled={isSubmitting || lockoutSeconds > 0}
              className={`w-full py-3 px-4 rounded-xl font-bold text-sm text-white shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                lockoutSeconds > 0
                  ? 'bg-slate-400 cursor-not-allowed opacity-60'
                  : 'bg-[#ef4444] hover:bg-[#dc2626] active:scale-98 shadow-red-500/20'
              }`}
            >
              {isSubmitting ? (
                <span>লগইন যাচাই হচ্ছে...</span>
              ) : (
                <span>Login</span>
              )}
            </button>

            {/* Links below matching IMG_1243 */}
            <div className="text-center pt-2 space-y-2">
              <div>
                <button
                  type="button"
                  onClick={() => {
                    setMode('forgot');
                    setErrorMsg(null);
                    setSuccessMsg(null);
                  }}
                  className="text-xs font-semibold text-red-500 hover:text-red-600 hover:underline transition cursor-pointer"
                >
                  Forget Password?
                </button>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400">
                New user to Buy Free Fire All Panel?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setErrorMsg(null);
                    setSuccessMsg(null);
                  }}
                  className="font-bold text-red-500 hover:text-red-600 hover:underline cursor-pointer"
                >
                  Register Now
                </button>
              </p>
            </div>
          </form>
        )}

        {/* MODE: REGISTER */}
        {mode === 'register' && (
          <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="আপনার পূর্ণ নাম"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Email
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email Address"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="01XXXXXXXXX"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="ন্যূনতম ৬ অক্ষর"
                  className="w-full pl-3.5 pr-10 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-red-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Password strength meter */}
              {password && (
                <div className="mt-1 flex items-center gap-1.5">
                  <div className="h-1 flex-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${passStrength.color} transition-all`}
                      style={{ width: `${(passStrength.score / 4) * 100}%` }}
                    />
                  </div>
                  <span className="text-3xs font-bold text-slate-400">
                    {passStrength.label}
                  </span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Confirm Password
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="পুনরায় পাসওয়ার্ড দিন"
                  className="w-full pl-3.5 pr-10 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-red-500"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-2 text-slate-400 hover:text-slate-600"
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-xl font-bold text-sm text-white bg-[#ef4444] hover:bg-[#dc2626] shadow-md shadow-red-500/20 transition-all cursor-pointer"
            >
              {isSubmitting ? 'অ্যাকাউন্ট তৈরি হচ্ছে...' : 'Register Account'}
            </button>

            <div className="text-center pt-2">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setErrorMsg(null);
                    setSuccessMsg(null);
                  }}
                  className="font-bold text-red-500 hover:underline cursor-pointer"
                >
                  Login Now
                </button>
              </p>
            </div>
          </form>
        )}

        {/* MODE: FORGOT PASSWORD */}
        {mode === 'forgot' && (
          <form onSubmit={handleForgotSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Registered Email
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. yourname@gmail.com"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                4-Digit Support PIN
              </label>
              <input
                type="text"
                required
                maxLength={6}
                value={supportPin}
                onChange={(e) => setSupportPin(e.target.value)}
                placeholder="e.g. 5433"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
              />
              <span className="text-3xs text-slate-400 mt-0.5 block">
                (অ্যাকাউন্ট তৈরি করার সময় দেওয়া ৪-সংখ্যার গোপন সিকিউরিটি পিন)
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                New Password
              </label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="নতুন পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-xl font-bold text-sm text-white bg-[#ef4444] hover:bg-[#dc2626] shadow-md shadow-red-500/20 transition-all cursor-pointer"
            >
              {isSubmitting ? 'আপডেট হচ্ছে...' : 'পাসওয়ার্ড পরিবর্তন করুন'}
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }}
                className="text-xs font-semibold text-slate-500 hover:text-red-500 transition cursor-pointer"
              >
                ← Back to Login
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Google Auth Modal */}
      <GoogleAuthModal
        isOpen={showGoogleModal}
        onClose={() => setShowGoogleModal(false)}
        onSelectAccount={(acc) => {
          loginWithGoogle(acc);
          if (onSuccess) onSuccess();
        }}
      />

      {/* Telegram Auth Modal */}
      <TelegramAuthModal
        isOpen={showTelegramModal}
        onClose={() => setShowTelegramModal(false)}
        onConfirmTelegram={(tgData) => {
          loginWithTelegram(tgData);
          if (onSuccess) onSuccess();
        }}
      />
    </>
  );
};
