import React from 'react';
import { useStore } from '../context/StoreContext';
import { Send, X, Check, MessageSquare } from 'lucide-react';

export const TelegramModal: React.FC = () => {
  const { showTelegramPopup, setShowTelegramPopup, settings, isDarkMode, language } = useStore();

  if (!showTelegramPopup || !settings.telegramPopupEnabled) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-md rounded-2xl p-6 sm:p-7 shadow-2xl border text-center transition-all ${
          isDarkMode
            ? 'bg-slate-900 border-slate-700 text-white shadow-indigo-950/40'
            : 'bg-white border-slate-200 text-slate-900 shadow-xl'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={() => setShowTelegramPopup(false)}
          className={`absolute top-4 right-4 p-1.5 rounded-full transition cursor-pointer ${
            isDarkMode
              ? 'text-slate-400 hover:text-white hover:bg-slate-800'
              : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
          }`}
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Telegram Circular Icon */}
        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-tr from-sky-600 to-blue-500 flex items-center justify-center shadow-lg shadow-sky-500/30 text-white">
          <Send className="w-8 h-8 -translate-x-0.5 translate-y-0.5" />
        </div>

        {/* Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-2xs font-bold tracking-wider uppercase mb-3 bg-sky-500/10 text-sky-400 border border-sky-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" />
          OFFICIAL TELEGRAM COMMUNITY
        </div>

        {/* Title */}
        <h3 className="text-xl sm:text-2xl font-black tracking-tight mb-2">
          {settings.telegramPopupTitle}
        </h3>

        {/* Description */}
        <p className={`text-xs sm:text-sm leading-relaxed mb-6 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
          {settings.telegramPopupDesc}
        </p>

        {/* Benefits Grid */}
        <div className="grid grid-cols-2 gap-2.5 mb-6 text-left">
          <div
            className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold ${
              isDarkMode ? 'bg-slate-800/80 border-slate-700/60 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <Check className="w-4 h-4 text-sky-400 shrink-0" />
            <span>Important Notices</span>
          </div>

          <div
            className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold ${
              isDarkMode ? 'bg-slate-800/80 border-slate-700/60 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <Check className="w-4 h-4 text-sky-400 shrink-0" />
            <span>Latest Updates</span>
          </div>

          <div
            className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold ${
              isDarkMode ? 'bg-slate-800/80 border-slate-700/60 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <Check className="w-4 h-4 text-sky-400 shrink-0" />
            <span>Announcements</span>
          </div>

          <div
            className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold ${
              isDarkMode ? 'bg-slate-800/80 border-slate-700/60 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <Check className="w-4 h-4 text-sky-400 shrink-0" />
            <span>Customer Support</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5">
          <a
            href={settings.telegramLink}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3 px-4 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-sky-500/25 transition cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>{language === 'bn' ? 'টেলিগ্রাম অফিসিয়াল গ্রুপে জয়েন করুন' : 'Join Official Telegram Group'}</span>
          </a>

          {settings.telegramDmLink && (
            <a
              href={settings.telegramDmLink}
              target="_blank"
              rel="noopener noreferrer"
              className={`w-full py-2.5 px-4 font-semibold text-xs rounded-xl flex items-center justify-center gap-2 border transition cursor-pointer ${
                isDarkMode
                  ? 'border-sky-500/40 text-sky-400 hover:bg-sky-500/10'
                  : 'border-sky-400 text-sky-600 hover:bg-sky-50'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'টেলিগ্রামে এডমিনকে মেসেজ (DM) করুন' : 'Direct Message (DM) Admin on Telegram'}</span>
            </a>
          )}
        </div>

        <p className={`text-2xs mt-4 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}>
          Stay informed. Stay connected with {settings.siteName}.
        </p>
      </div>
    </div>
  );
};
