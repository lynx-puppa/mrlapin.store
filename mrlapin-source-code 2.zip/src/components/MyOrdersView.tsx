import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import {
  ShoppingBag,
  ArrowRight,
  CheckCircle2,
  Clock,
  XCircle,
  AlertCircle,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { OrderRecord } from '../types';

type FilterStatus = 'all' | 'completed' | 'processing' | 'failed';

interface StatusConfig {
  key: string;
  label: string;
  badgeStyle: string;
  icon: React.ReactNode;
  hint: string;
  accentBorder: string;
}

export const MyOrdersView: React.FC = () => {
  const { orders, setActiveTab, isDarkMode } = useStore();
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<FilterStatus>('all');
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);

  // Normalize order status to our 3 primary states: completed, processing, failed
  const getStatusConfig = (status: OrderRecord['status']): StatusConfig => {
    switch (status) {
      case 'completed':
        return {
          key: 'completed',
          label: 'Completed',
          badgeStyle: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
          accentBorder: 'hover:border-emerald-500/40',
          icon: <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />,
          hint: 'লাইসেন্স কী অ্যাক্টিভ হয়েছে এবং ওয়ালেটে ডেলিভার করা হয়েছে।'
        };
      case 'processing':
      case 'pending':
        return {
          key: 'processing',
          label: 'Processing',
          badgeStyle: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
          accentBorder: 'hover:border-amber-500/40',
          icon: <Clock className="w-3.5 h-3.5 shrink-0 animate-pulse" />,
          hint: 'কী জেনারেট হচ্ছে ও সার্ভারে অর্ডার ভেরিফিকেশন চলমান।'
        };
      case 'failed':
      case 'cancelled':
      default:
        return {
          key: 'failed',
          label: 'Failed',
          badgeStyle: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30',
          accentBorder: 'hover:border-rose-500/40',
          icon: <XCircle className="w-3.5 h-3.5 shrink-0" />,
          hint: 'অর্ডার ব্যর্থ বা বাতিল হয়েছে। ওয়ালেট ব্যালেন্স সুরক্ষিত আছে।'
        };
    }
  };

  const handleCopyKey = (orderId: string, keyText: string) => {
    navigator.clipboard.writeText(keyText);
    setCopiedOrderId(orderId);
    setTimeout(() => setCopiedOrderId(null), 2000);
  };

  // Filter calculations
  const completedCount = orders.filter((o) => o.status === 'completed').length;
  const processingCount = orders.filter((o) => o.status === 'processing' || o.status === 'pending').length;
  const failedCount = orders.filter((o) => o.status === 'failed' || o.status === 'cancelled').length;

  const filteredOrders = orders.filter((ord) => {
    if (selectedStatusFilter === 'all') return true;
    if (selectedStatusFilter === 'completed') return ord.status === 'completed';
    if (selectedStatusFilter === 'processing') return ord.status === 'processing' || ord.status === 'pending';
    if (selectedStatusFilter === 'failed') return ord.status === 'failed' || ord.status === 'cancelled';
    return true;
  });

  return (
    <div className="space-y-6 pb-36 max-w-4xl mx-auto w-full max-w-full overflow-hidden">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-blue-500" />
            <span>My Orders</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Track and manage your order history and activated gaming keys.
          </p>
        </div>

        {/* Total Orders Summary */}
        <div className="flex items-center gap-2 self-start sm:self-auto text-2xs font-mono font-bold px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
          <span>Total Orders:</span>
          <span className="text-blue-500 font-black">{orders.length}</span>
        </div>
      </div>

      {/* Dynamic Status Filter Tabs (Segmented control) */}
      {orders.length > 0 && (
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl overflow-x-auto border border-slate-200/80 dark:border-slate-700/60 scrollbar-none">
          
          {/* All Tab */}
          <button
            type="button"
            onClick={() => setSelectedStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              selectedStatusFilter === 'all'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span>All</span>
            <span className="px-1.5 py-0.2 rounded-full text-3xs font-mono bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
              {orders.length}
            </span>
          </button>

          {/* Completed Tab */}
          <button
            type="button"
            onClick={() => setSelectedStatusFilter('completed')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              selectedStatusFilter === 'completed'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-emerald-500'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Completed</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-3xs font-mono ${
                selectedStatusFilter === 'completed'
                  ? 'bg-emerald-700 text-white'
                  : 'bg-emerald-500/10 text-emerald-500'
              }`}
            >
              {completedCount}
            </span>
          </button>

          {/* Processing Tab */}
          <button
            type="button"
            onClick={() => setSelectedStatusFilter('processing')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              selectedStatusFilter === 'processing'
                ? 'bg-amber-500 text-slate-950 shadow-xs font-black'
                : 'text-slate-600 dark:text-slate-400 hover:text-amber-500'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Processing</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-3xs font-mono ${
                selectedStatusFilter === 'processing'
                  ? 'bg-amber-600 text-slate-950 font-black'
                  : 'bg-amber-500/10 text-amber-500'
              }`}
            >
              {processingCount}
            </span>
          </button>

          {/* Failed Tab */}
          <button
            type="button"
            onClick={() => setSelectedStatusFilter('failed')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              selectedStatusFilter === 'failed'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-rose-500'
            }`}
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>Failed</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-3xs font-mono ${
                selectedStatusFilter === 'failed'
                  ? 'bg-rose-700 text-white'
                  : 'bg-rose-500/10 text-rose-500'
              }`}
            >
              {failedCount}
            </span>
          </button>
        </div>
      )}

      {/* Orders List */}
      {orders.length === 0 ? (
        <div
          className={`p-12 text-center rounded-2xl border space-y-4 ${
            isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-white border-slate-200 text-slate-500'
          }`}
        >
          <div className="w-16 h-16 mx-auto rounded-full bg-slate-800/40 flex items-center justify-center text-slate-500">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <p className="text-base font-bold text-slate-800 dark:text-slate-200">
              No order found !
            </p>
            <p className="text-xs text-slate-400">
              You haven't placed any order yet. Browse our VIP panels to get started.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('home')}
            className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
          >
            ORDER NOW
          </button>
        </div>
      ) : filteredOrders.length === 0 ? (
        <div
          className={`p-8 text-center rounded-2xl border space-y-3 ${
            isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-white border-slate-200 text-slate-500'
          }`}
        >
          <AlertCircle className="w-10 h-10 mx-auto text-slate-500" />
          <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
            No {selectedStatusFilter} orders found.
          </p>
          <button
            onClick={() => setSelectedStatusFilter('all')}
            className="px-4 py-1.5 rounded-lg bg-blue-600 text-white font-bold text-2xs cursor-pointer inline-flex items-center gap-1.5"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Show All Orders</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((ord) => {
            const statusConfig = getStatusConfig(ord.status);
            const isCompleted = statusConfig.key === 'completed';
            const isProcessing = statusConfig.key === 'processing';
            const isFailed = statusConfig.key === 'failed';
            const isKeyCopied = copiedOrderId === ord.id;

            return (
              <div
                key={ord.id}
                className={`p-5 rounded-2xl border shadow-2xs space-y-3.5 transition-all ${
                  isDarkMode
                    ? 'bg-slate-900 border-slate-800 text-white'
                    : 'bg-white border-slate-200 text-slate-900'
                } ${statusConfig.accentBorder}`}
              >
                {/* Top Row: Serial Number & Dynamic Status Indicator */}
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-2xs font-extrabold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                      Serial NO: #{ord.serialNo}
                    </span>
                    <span className="text-2xs font-mono text-slate-400">
                      {ord.date}
                    </span>
                  </div>

                  {/* Status Indicator Badge with Dynamic Color Coding */}
                  <div
                    className={`inline-flex items-center gap-1.5 text-xs font-black uppercase px-2.5 py-1 rounded-lg border transition-all ${statusConfig.badgeStyle}`}
                    role="status"
                    aria-label={`Order status: ${statusConfig.label}`}
                  >
                    {statusConfig.icon}
                    <span className="tracking-wide text-2xs">{statusConfig.label}</span>
                  </div>
                </div>

                {/* Product Name & Package Details */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                  <div>
                    <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>{ord.productName}</span>
                    </h4>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {ord.packageTitle}
                      </span>
                      <span>·</span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-2xs text-slate-600 dark:text-slate-400">
                        Qty: {ord.quantity}
                      </span>
                    </div>
                  </div>

                  {/* Price Block */}
                  <div className="text-left sm:text-right shrink-0">
                    <div className="font-mono font-black text-amber-500 text-lg tabular-nums">
                      ৳ {ord.totalPrice}
                    </div>
                    <span className="text-3xs text-slate-400 uppercase font-bold">
                      Wallet Paid
                    </span>
                  </div>
                </div>

                {/* Dynamic State Banner & Actions */}
                <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-2xs">
                  
                  {/* Status Note / Description */}
                  <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                    <span
                      className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                        isCompleted
                          ? 'bg-emerald-500'
                          : isProcessing
                          ? 'bg-amber-500 animate-ping'
                          : 'bg-rose-500'
                      }`}
                      aria-hidden="true"
                    />
                    <span>{statusConfig.hint}</span>
                  </div>

                  {/* Action Affordance based on state */}
                  <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                    {isCompleted && (
                      <div className="flex items-center gap-2">
                        {ord.licenseKey && ord.licenseKey !== 'TRANSACTION_REJECTED' && (
                          <button
                            type="button"
                            onClick={() => handleCopyKey(ord.id, ord.licenseKey)}
                            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-2xs inline-flex items-center gap-1 cursor-pointer transition"
                            title="Copy License Key"
                          >
                            {isKeyCopied ? (
                              <Check className="w-3 h-3 text-emerald-500" />
                            ) : (
                              <Copy className="w-3 h-3 text-slate-400" />
                            )}
                            <span>{isKeyCopied ? 'কপি হয়েছে' : 'Copy Key'}</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setActiveTab('my_codes')}
                          className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-2xs inline-flex items-center gap-1 cursor-pointer transition shadow-xs"
                        >
                          <span>View License Key</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    )}

                    {isProcessing && (
                      <div className="flex items-center gap-1.5 font-bold text-amber-500 dark:text-amber-400">
                        <Clock className="w-3.5 h-3.5 animate-spin" />
                        <span>অটো ডেলিভারি প্রসেসিং...</span>
                      </div>
                    )}

                    {isFailed && (
                      <button
                        type="button"
                        onClick={() => setActiveTab('account')}
                        className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 font-bold text-2xs inline-flex items-center gap-1 cursor-pointer transition border border-rose-500/20"
                      >
                        <HelpCircle className="w-3 h-3" />
                        <span>সাপোর্ট যোগাযোগ</span>
                      </button>
                    )}
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
