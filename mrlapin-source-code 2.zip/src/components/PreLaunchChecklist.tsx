import React, { useState } from 'react';
import { PRE_LAUNCH_CHECKLIST, FAQS } from '../data/guideData';
import { CheckSquare, Square, ChevronDown, ChevronUp, Rocket, HelpCircle } from 'lucide-react';

interface PreLaunchChecklistProps {
  lang: 'bn' | 'en';
}

export const PreLaunchChecklist: React.FC<PreLaunchChecklistProps> = ({ lang }) => {
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({
    c1: true,
    c2: true,
    c7: true
  });
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const toggleCheck = (id: string) => {
    setCheckedItems((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const total = PRE_LAUNCH_CHECKLIST.length;
  const completedCount = Object.values(checkedItems).filter(Boolean).length;
  const isAllReady = completedCount === total;

  return (
    <section id="checklist" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: Interactive Checklist (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              <div className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">
                {lang === 'bn' ? 'লঞ্চ পূর্ববর্তী চেকলিস্ট' : 'Pre-Launch Checklist'}
              </div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight mt-1">
                {lang === 'bn' ? 'পাবলিশ করার আগে যা যা চেক করবেন' : 'What to Verify Before Going Live'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                {lang === 'bn'
                  ? 'আপনার ওয়েবসাইটটি যাতে ভিজিটরদের কাছে পেশাদার দেখায়, সেজন্য নিচের চেকলিস্টটি মিলিয়ে নিন।'
                  : 'Ensure your website looks polished and works reliably on all devices.'}
              </p>
            </div>

            {/* Progress Meter */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800">
                  {lang === 'bn' ? 'প্রস্তুতির অগ্রগতি:' : 'Readiness Progress:'}
                </span>
                <span className="font-mono font-bold text-indigo-600">
                  {completedCount} / {total} {lang === 'bn' ? 'সম্পন্ন' : 'Completed'}
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-emerald-500 h-2 transition-all duration-300"
                  style={{ width: `${(completedCount / total) * 100}%` }}
                />
              </div>
              {isAllReady && (
                <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1.5 pt-1">
                  <Rocket className="w-4 h-4 text-emerald-600" />
                  <span>{lang === 'bn' ? 'দারুণ! আপনার সাইট এখন সম্পূর্ণ প্রস্তুত।' : 'Awesome! Your site is 100% launch-ready.'}</span>
                </div>
              )}
            </div>

            {/* Checklist Items */}
            <div className="space-y-2.5">
              {PRE_LAUNCH_CHECKLIST.map((item) => {
                const isChecked = !!checkedItems[item.id];
                return (
                  <div
                    key={item.id}
                    onClick={() => toggleCheck(item.id)}
                    className={`p-3 rounded-lg border transition-all cursor-pointer flex items-start gap-3 ${
                      isChecked
                        ? 'bg-emerald-50/40 border-emerald-200 text-slate-800'
                        : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <button className="mt-0.5 text-indigo-600 shrink-0">
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-400" />
                      )}
                    </button>
                    <div className="text-xs flex-1">
                      <span className={isChecked ? 'line-through text-slate-500' : 'font-medium'}>
                        {item.text}
                      </span>
                      <span className="block text-2xs text-slate-400 mt-0.5">
                        বিভাগ: {item.category}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: FAQs Accordion (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              <div className="text-xs font-semibold text-indigo-600 uppercase tracking-wider flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'সচরাচর জিজ্ঞাসিত প্রশ্নাবলী (FAQ)' : 'Frequently Asked Questions'}</span>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight mt-1">
                {lang === 'bn' ? 'ফ্রি ওয়েবসাইট নিয়ে মনের সব প্রশ্নের উত্তর' : 'Answers to Beginner Questions'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                {lang === 'bn'
                  ? 'টাকা কাটা, হিডেন চার্জ বা টেকনিক্যাল জটিলতা নিয়ে কোনো দ্বিধা থাকলে এখানে উত্তর পেয়ে যাবেন।'
                  : 'Honest answers on hosting limits, hidden traps, and future upgrades.'}
              </p>
            </div>

            {/* Accordion */}
            <div className="space-y-3">
              {FAQS.map((faq, idx) => {
                const isOpen = openFaq === idx;
                return (
                  <div
                    key={idx}
                    className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-2xs"
                  >
                    <button
                      onClick={() => setOpenFaq(isOpen ? null : idx)}
                      className="w-full p-4 text-left font-bold text-xs sm:text-sm text-slate-900 hover:bg-slate-50 flex items-center justify-between gap-4 cursor-pointer"
                    >
                      <span>{faq.question}</span>
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4 text-slate-500 shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                      )}
                    </button>

                    {isOpen && (
                      <div className="px-4 pb-4 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
