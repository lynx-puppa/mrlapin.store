import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { X, ExternalLink, Check, Copy, AlertTriangle, ShieldCheck, Plus, Minus, ArrowRight, Wallet } from 'lucide-react';

export const ProductDetailModal: React.FC = () => {
  const {
    selectedProduct,
    setSelectedProduct,
    user,
    purchasePackage,
    setActiveTab,
    isDarkMode,
    language,
    isLoggedIn,
    setShowAuthModal
  } = useStore();

  const [selectedTierId, setSelectedTierId] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [purchaseResult, setPurchaseResult] = useState<{ success: boolean; message: string; key?: string; keys?: string[] } | null>(null);
  const [copiedKeyIndex, setCopiedKeyIndex] = useState<number | null>(null);
  const [copiedAllKeys, setCopiedAllKeys] = useState<boolean>(false);

  // Set default tier when modal opens
  React.useEffect(() => {
    if (selectedProduct && selectedProduct.packages.length > 0) {
      // Find first available tier that has stock
      const firstAvailable = selectedProduct.packages.find((p) => p.status === 'online' && (!p.keysPool || p.keysPool.length > 0)) || selectedProduct.packages[0];
      setSelectedTierId(firstAvailable.id);
      setQuantity(1);
      setPurchaseResult(null);
    }
  }, [selectedProduct]);

  if (!selectedProduct) return null;

  const currentTier = selectedProduct.packages.find((p) => p.id === selectedTierId) || selectedProduct.packages[0];
  const totalPrice = (currentTier?.price || selectedProduct.basePrice) * quantity;
  const hasEnoughBalance = user.balance >= totalPrice;

  const handleOrder = () => {
    if (!isLoggedIn) {
      setShowAuthModal(true);
      return;
    }
    if (!currentTier) return;
    const res = purchasePackage(selectedProduct, currentTier.id, quantity);
    setPurchaseResult(res);
  };

  const isProductDisabled = selectedProduct.status !== 'online';
  const isTierDisabled = !currentTier || currentTier.status === 'out_of_stock' || (currentTier.keysPool !== undefined && currentTier.keysPool.length === 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div
        className={`relative w-full max-w-lg rounded-2xl border shadow-2xl overflow-hidden my-auto transition-all ${
          isDarkMode
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Modal Top Bar */}
        <div
          className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 z-10 ${
            isDarkMode ? 'bg-slate-900/95 border-slate-800' : 'bg-white/95 border-slate-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-500 uppercase tracking-wider">
              Product Details & Recharge
            </span>
          </div>
          <button
            onClick={() => {
              setSelectedProduct(null);
              setPurchaseResult(null);
            }}
            className={`p-1.5 rounded-full transition cursor-pointer ${
              isDarkMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-800 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {/* Product Header (matching image IMG_1189) */}
          <div className="flex items-start gap-4 pb-4 border-b border-slate-200/40">
            <img
              src={selectedProduct.image && selectedProduct.image.trim() !== '' ? selectedProduct.image : 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'}
              alt={selectedProduct.name}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover border border-indigo-500/30 shadow-md shrink-0"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80';
              }}
            />
            <div className="space-y-1 flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white truncate">
                  {selectedProduct.name}
                </h3>
              </div>
              <p className="text-xs text-slate-400 font-medium">Game / Voucher</p>
              
              {/* Dynamic status pill */}
              <div className="pt-1">
                {selectedProduct.status === 'online' && (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-2xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    ONLINE
                  </span>
                )}
                {selectedProduct.status === 'maintenance' && (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-2xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                    ⚠️ {selectedProduct.customBadge || 'UNDER MAINTENANCE'}
                  </span>
                )}
                {selectedProduct.status === 'out_of_stock' && (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-2xs font-bold bg-red-500/10 text-red-400 border border-red-500/30">
                    🚫 {selectedProduct.customBadge || 'AUTOMATIC SHOT OUT (OUT OF STOCK)'}
                  </span>
                )}
                {selectedProduct.status === 'not_available' && (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-2xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30">
                    ❌ {selectedProduct.customBadge || 'THIS PRODUCT NOT AVAILABLE'}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Success State if Purchased */}
          {purchaseResult && purchaseResult.success && (
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 space-y-3 animate-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2 font-bold text-sm">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span>
                    {purchaseResult.keys && purchaseResult.keys.length > 1
                      ? `অর্ডার সম্পন্ন হয়েছে! ${purchaseResult.keys.length} টি লাইসেন্স কী:`
                      : 'অর্ডার সম্পন্ন হয়েছে! আপনার লাইসেন্স কোড:'}
                  </span>
                </div>

                {purchaseResult.keys && purchaseResult.keys.length > 1 && (
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(purchaseResult.keys!.join('\n'));
                      setCopiedAllKeys(true);
                      setTimeout(() => setCopiedAllKeys(false), 2000);
                    }}
                    className="px-2.5 py-1 bg-emerald-600/30 hover:bg-emerald-600/50 text-white font-bold text-2xs rounded-lg flex items-center gap-1 cursor-pointer transition border border-emerald-500/40"
                  >
                    {copiedAllKeys ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedAllKeys ? 'সব কী কপি হয়েছে!' : 'Copy All Keys'}</span>
                  </button>
                )}
              </div>

              {/* Display Keys List */}
              <div className="space-y-1.5 max-h-48 overflow-y-auto">
                {(purchaseResult.keys || (purchaseResult.key ? [purchaseResult.key] : [])).map((k, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-700 flex items-center justify-between gap-2"
                  >
                    <span className="font-mono text-xs sm:text-sm font-bold text-amber-400 select-all truncate">
                      {k}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(k);
                        setCopiedKeyIndex(idx);
                        setTimeout(() => setCopiedKeyIndex(null), 2000);
                      }}
                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-2xs rounded-md flex items-center gap-1 cursor-pointer transition shrink-0"
                    >
                      {copiedKeyIndex === idx ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedKeyIndex === idx ? 'কপি হয়েছে' : 'Copy'}</span>
                    </button>
                  </div>
                ))}
              </div>

              <p className="text-2xs text-slate-300">
                এই কোডটি আপনার <strong className="text-white">"My Codes"</strong> ট্যাবেও সংরক্ষিত হয়েছে। ওয়ালেট ব্যালেন্স থেকে মোট মূল্য কেটে নেওয়া হয়েছে।
              </p>
            </div>
          )}

          {/* Error Message if Failed */}
          {purchaseResult && !purchaseResult.success && (
            <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{purchaseResult.message}</span>
            </div>
          )}

          {/* Step 1: Select Recharge (matching IMG_1189) */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
                1
              </span>
              <h4 className="font-bold text-sm">Select Recharge</h4>
            </div>

            {/* Packages Grid - Stock count HIDDEN, only shows ONLINE or STOCK OUT */}
            <div className="grid grid-cols-2 gap-2.5">
              {selectedProduct.packages.map((pkg) => {
                const isSelected = selectedTierId === pkg.id;
                const isOutOfStock = pkg.status === 'out_of_stock' || (pkg.keysPool !== undefined && pkg.keysPool.length === 0);

                return (
                  <button
                    key={pkg.id}
                    disabled={isProductDisabled || isOutOfStock}
                    onClick={() => {
                      setSelectedTierId(pkg.id);
                      setQuantity(1);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer relative ${
                      isSelected
                        ? isDarkMode
                          ? 'border-blue-500 bg-blue-950/40 shadow-sm shadow-blue-500/20'
                          : 'border-blue-600 bg-blue-50/60 shadow-xs'
                        : isDarkMode
                        ? 'border-slate-800 bg-slate-800/40 hover:border-slate-700'
                        : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                    } ${isOutOfStock ? 'opacity-60 cursor-not-allowed' : ''}`}
                  >
                    <div className="flex items-center justify-between gap-1 mb-1.5">
                      <span className="w-2.5 h-2.5 rounded-full border border-slate-400 flex items-center justify-center">
                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />}
                      </span>
                      <span className="font-mono font-bold text-xs text-blue-500 dark:text-blue-400">
                        ৳ {pkg.price}
                      </span>
                    </div>

                    <div className="font-bold text-xs truncate mb-2">
                      {pkg.name}
                    </div>

                    <div className="flex items-center justify-between gap-1 text-2xs">
                      <div className="flex items-center gap-1.5">
                        <span className="text-2xs font-mono px-1 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                          {pkg.duration}
                        </span>
                        {!isOutOfStock ? (
                          <span className="text-2xs font-semibold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            ONLINE
                          </span>
                        ) : (
                          <span className="text-2xs font-bold px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                            STOCK OUT
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* App Link + Setup Video button & links */}
            <div className="pt-1 flex items-center justify-between flex-wrap gap-2 text-xs">
              <a
                href={selectedProduct.videoLink || selectedProduct.appLink || 'https://youtube.com'}
                target="_blank"
                rel="noopener noreferrer"
                className="text-pink-500 hover:text-pink-400 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
              >
                <span>App Link + Setup Video</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <div className="flex items-center gap-2">
                {selectedProduct.videoLink && (
                  <a
                    href={selectedProduct.videoLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2 py-0.5 rounded-md bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 text-2xs font-bold flex items-center gap-1 cursor-pointer transition"
                  >
                    <span>🎥 Setup Video</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                {selectedProduct.appLink && (
                  <a
                    href={selectedProduct.appLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-400 border border-blue-500/20 hover:bg-blue-500/20 text-2xs font-bold flex items-center gap-1 cursor-pointer transition"
                  >
                    <span>📱 App Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Quantity Selector - Enforces stock limit */}
          <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
            <div>
              <span className="font-bold text-xs block">Quantity</span>
              {currentTier?.keysPool && currentTier.keysPool.length > 0 && quantity >= currentTier.keysPool.length && (
                <span className="text-3xs text-amber-500 font-semibold">
                  সর্বোচ্চ স্টক লিমিট পৌঁছেছে
                </span>
              )}
            </div>
            <div className="flex items-center gap-3">
              <button
                disabled={quantity <= 1}
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-sm hover:opacity-80 disabled:opacity-40 cursor-pointer"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="font-mono font-bold text-sm w-6 text-center">{quantity}</span>
              <button
                disabled={
                  currentTier?.keysPool && currentTier.keysPool.length > 0
                    ? quantity >= currentTier.keysPool.length
                    : false
                }
                onClick={() => {
                  const maxAllowed = currentTier?.keysPool ? currentTier.keysPool.length : 99;
                  if (quantity < maxAllowed) {
                    setQuantity(quantity + 1);
                  }
                }}
                className="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-sm hover:opacity-80 disabled:opacity-40 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Step 3: Payment & Order Button */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
                  3
                </span>
                <h4 className="font-bold text-sm">Payment Methods</h4>
              </div>
              <div className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                <Wallet className="w-3.5 h-3.5 text-blue-500" />
                <span>ব্যালেন্স: ৳ {user.balance}</span>
              </div>
            </div>

            {/* Total Calculation Strip */}
            <div className="p-3.5 rounded-xl border border-indigo-500/20 bg-indigo-50/40 dark:bg-indigo-950/30 flex items-center justify-between">
              <div>
                <span className="text-2xs text-slate-400 block">মোট প্রদেয় মূল্য</span>
                <span className="font-mono text-lg font-black text-blue-500 dark:text-blue-400">
                  ৳ {totalPrice}
                </span>
              </div>

              {!hasEnoughBalance && (
                <button
                  onClick={() => {
                    setSelectedProduct(null);
                    setActiveTab('add_fund');
                  }}
                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition shadow-xs"
                >
                  <span>টাকা রিচার্জ করুন</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Primary Order Action Button */}
            <button
              disabled={isProductDisabled || isTierDisabled || (isLoggedIn && !hasEnoughBalance)}
              onClick={handleOrder}
              className={`w-full py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                !isLoggedIn
                  ? 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white shadow-red-500/25 active:scale-98'
                  : isProductDisabled || isTierDisabled
                  ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                  : !hasEnoughBalance
                  ? 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-500/25 active:scale-98'
              }`}
            >
              {!isLoggedIn
                ? (language === 'bn' ? 'Gmail দিয়ে লগইন করে কিনুন (Sign In to Buy)' : 'Sign In with Gmail to Buy')
                : isProductDisabled
                ? selectedProduct.customBadge || (language === 'bn' ? 'ক্রয় বন্ধ আছে' : 'Purchase Disabled')
                : isTierDisabled
                ? (language === 'bn' ? 'স্টক শেষ (STOCK OUT)' : 'STOCK OUT')
                : !hasEnoughBalance
                ? (language === 'bn' ? `অপর্যাপ্ত ব্যালেন্স (৳ ${user.balance}) - Add Fund করুন` : `Insufficient Balance (৳ ${user.balance}) - Add Fund`)
                : (language === 'bn' ? 'অর্ডার নিশ্চিত করুন (Confirm Order)' : 'Order Now')}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
