import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { LoginCard } from './LoginCard';
import { 
  User, 
  Wallet, 
  ShoppingCart, 
  DollarSign, 
  Key, 
  Phone, 
  Mail, 
  Lock, 
  CheckCircle2, 
  Shield, 
  MessageCircle, 
  LogOut, 
  ShieldCheck, 
  Send, 
  UserCheck, 
  RefreshCw 
} from 'lucide-react';

export const AccountView: React.FC = () => {
  const { 
    user, 
    updateUserProfile, 
    isDarkMode, 
    settings, 
    setActiveTab, 
    isAdmin, 
    adminEmail, 
    loginWithEmail,
    isLoggedIn,
    logout,
    setShowAuthModal,
    setAuthModalInitialTab
  } = useStore();

  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);

  // Switch account state
  const [showSwitchLogin, setShowSwitchLogin] = useState(false);

  // Password state
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passMsg, setPassMsg] = useState<string | null>(null);

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({ name, phone });
    setProfileMsg('ব্যক্তিগত তথ্য সফলভাবে আপডেট হয়েছে!');
    setTimeout(() => setProfileMsg(null), 2500);
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPass || newPass !== confirmPass) {
      setPassMsg('Error: নতুন পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড মিলছে না।');
      return;
    }
    if (newPass.length < 6) {
      setPassMsg('Error: পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      return;
    }
    setPassMsg('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!');
    setCurrentPass('');
    setNewPass('');
    setConfirmPass('');
    setTimeout(() => setPassMsg(null), 2500);
  };

  // If user is not logged in, show the LoginCard directly matching IMG_1243!
  if (!isLoggedIn) {
    return (
      <div className="py-6 sm:py-10 max-w-md mx-auto w-full px-2">
        <LoginCard initialMode="login" />
      </div>
    );
  }

  return (
    <div className="space-y-6 sm:space-y-8 pb-36 max-w-4xl mx-auto w-full max-w-full overflow-hidden">
      
      {/* Profile Header matching video 01:08 */}
      <div
        className={`p-5 sm:p-8 rounded-3xl border text-center relative overflow-hidden shadow-sm ${
          isDarkMode
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Top Status Header Row - Clean flex layout, ZERO overlapping on mobile */}
        <div className="flex items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100 dark:border-slate-800/80 flex-wrap">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-3xs sm:text-2xs font-bold">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
            <span>Protected by Anti-Hack</span>
          </div>

          <div>
            {isAdmin ? (
              <span className="px-2.5 py-0.5 rounded-full bg-red-600/10 text-red-500 border border-red-500/30 text-3xs font-black tracking-wider uppercase flex items-center gap-1">
                <Shield className="w-3 h-3 text-red-500" />
                <span>ADMIN</span>
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-500 border border-blue-500/20 text-3xs font-bold">
                VERIFIED USER
              </span>
            )}
          </div>
        </div>

        {/* Avatar Circle - Cleanly centered with ample margin */}
        <div className="relative w-20 h-20 mx-auto mb-3.5">
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 text-white font-black text-3xl flex items-center justify-center shadow-lg shadow-indigo-600/30">
            {user.authProvider === 'telegram' ? (
              <span className="text-2xl">✈️</span>
            ) : (
              user.name.charAt(0).toUpperCase()
            )}
          </div>
          {user.authProvider && (
            <span
              className={`absolute bottom-0 right-0 w-6 h-6 rounded-full text-white text-3xs font-black flex items-center justify-center border-2 border-white dark:border-slate-900 shadow-xs ${
                user.authProvider === 'google'
                  ? 'bg-red-500'
                  : user.authProvider === 'telegram'
                  ? 'bg-sky-500'
                  : 'bg-emerald-500'
              }`}
              title={`Logged in with ${user.authProvider}`}
            >
              {user.authProvider === 'google' ? 'G' : user.authProvider === 'telegram' ? '✈' : '✓'}
            </span>
          )}
        </div>

        <div className="flex items-center justify-center gap-2">
          <h3 className="text-xl sm:text-2xl font-black">
            Hi, {user.name}
          </h3>
          {isAdmin && (
            <span className="px-2 py-0.5 rounded-md bg-red-600/10 text-red-500 border border-red-500/30 text-2xs font-black">
              ADMIN
            </span>
          )}
        </div>

        <p className="text-xs text-slate-400 mt-1 font-mono">
          {user.email || user.telegramUsername || 'Customer Account'}
        </p>

        <p className="text-xs text-slate-400 mt-1">
          Available Balance : <span className="font-mono font-bold text-amber-500 text-sm">৳ {user.balance}</span>
        </p>

        {/* 4 Stat Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 mt-6">
          <div className="p-3.5 rounded-2xl border border-blue-500/20 bg-blue-500/5 text-center">
            <span className="font-mono text-base sm:text-lg font-black text-blue-500 block">
              ৳ {user.balance}
            </span>
            <span className="text-2xs font-bold text-slate-400 uppercase mt-0.5 block">
              Balance
            </span>
          </div>

          <div className="p-3.5 rounded-2xl border border-indigo-500/20 bg-indigo-500/5 text-center">
            <span className="font-mono text-base sm:text-lg font-black text-indigo-400 block">
              {user.totalOrders}
            </span>
            <span className="text-2xs font-bold text-slate-400 uppercase mt-0.5 block">
              Total Order
            </span>
          </div>

          <div className="p-3.5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5 text-center">
            <span className="font-mono text-base sm:text-lg font-black text-emerald-400 block">
              ৳ {user.totalSpent}
            </span>
            <span className="text-2xs font-bold text-slate-400 uppercase mt-0.5 block">
              Total Spent
            </span>
          </div>

          <div className="p-3.5 rounded-2xl border border-amber-500/20 bg-amber-500/5 text-center">
            <span className="font-mono text-base sm:text-lg font-black text-amber-500 block">
              {user.supportPin}
            </span>
            <span className="text-2xs font-bold text-slate-400 uppercase mt-0.5 block">
              Support PIN
            </span>
          </div>
        </div>

        {/* Action Buttons: Centered full-width stack with zero overlap from floating widgets */}
        <div className="max-w-md mx-auto grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-6">
          <button
            onClick={() => setShowSwitchLogin(!showSwitchLogin)}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-blue-500 shrink-0" />
            <span className="truncate">{showSwitchLogin ? 'লগইন কার্ড লুকান' : 'অন্য একাউন্টে লগইন করুন'}</span>
          </button>

          <button
            onClick={logout}
            className="w-full py-2.5 px-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/30 text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 shrink-0" />
            <span>লগআউট (Logout)</span>
          </button>
        </div>
      </div>

      {/* Expandable Switch Account Card (Google / Telegram / Credentials) */}
      {showSwitchLogin && (
        <div className="animate-in fade-in slide-in-from-top-4 duration-300">
          <LoginCard onSuccess={() => setShowSwitchLogin(false)} />
        </div>
      )}

      {/* Security & Anti-Hack Shield Card (User requested safety) */}
      <div
        className={`p-6 rounded-3xl border shadow-xs space-y-4 ${
          isDarkMode
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-500" />
            <h4 className="font-black text-sm uppercase tracking-wider">
              ওয়েবসাইট সিকিউরিটি ও হ্যাক প্রতিরোধ শিল্ড (Active)
            </h4>
          </div>
          <span className="px-2.5 py-0.5 rounded-full text-2xs font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
            ১০/১০ সিকিউরিটি প্রোটেকশন
          </span>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          আপনার প্যানেল ও ওয়ালেটের সুরক্ষায় স্বয়ংক্রিয় অ্যান্টি-হ্যাক সিস্টেম সক্রিয় রয়েছে। কেউ অননুমোদিত চেষ্টা বা পাসওয়ার্ড অনুমান করতে পারবে না।
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-xs">
            <div className="font-bold text-emerald-500 mb-1 flex items-center gap-1">
              <span>✓</span> Brute-Force Shield
            </div>
            <p className="text-2xs text-slate-400">
              টানা ৫ বার ভুল পাসওয়ার্ড দিলে অ্যাকাউন্ট স্বয়ংক্রিয়ভাবে ৬০ সেকেন্ড লক হয়ে যায়।
            </p>
          </div>

          <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-xs">
            <div className="font-bold text-blue-500 mb-1 flex items-center gap-1">
              <span>✓</span> XSS & Script Filter
            </div>
            <p className="text-2xs text-slate-400">
              সকল ইনপুটে ক্ষতিকর কোড ও স্ক্রিপ্ট ফিল্টারিং সচল রাখা হয়েছে।
            </p>
          </div>

          <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-xs">
            <div className="font-bold text-purple-500 mb-1 flex items-center gap-1">
              <span>✓</span> Strict Admin Guard
            </div>
            <p className="text-2xs text-slate-400">
              শুধুমাত্র অনুমোদিত প্রধান অ্যাডমিন একাউন্ট ছাড়া কেউ অ্যাডমিন প্যানেল এক্সেস করতে পারবে না।
            </p>
          </div>
        </div>
      </div>

      {/* Personal Information Form */}
      <div
        className={`p-6 rounded-3xl border shadow-xs ${
          isDarkMode
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <h4 className="font-black text-sm uppercase tracking-wider mb-4 flex items-center gap-2">
          <User className="w-4 h-4 text-blue-500" />
          <span>Personal Information (ব্যক্তিগত তথ্য)</span>
        </h4>

        <form onSubmit={handleUpdateProfile} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1">
              Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1">
              Email Address
            </label>
            <input
              type="email"
              value={user.email}
              disabled
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300/60 dark:border-slate-800 bg-slate-100 dark:bg-slate-800/50 text-xs text-slate-500 cursor-not-allowed font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1">
              Phone Number
            </label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>

          {profileMsg && (
            <div className="text-2xs font-bold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{profileMsg}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition cursor-pointer shadow-md shadow-blue-600/20"
          >
            Update Information
          </button>
        </form>
      </div>

      {/* Change Password Form */}
      <div
        className={`p-6 rounded-3xl border shadow-xs ${
          isDarkMode
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <h4 className="font-black text-sm uppercase tracking-wider mb-4 flex items-center gap-2">
          <Lock className="w-4 h-4 text-amber-500" />
          <span>Change Password (পাসওয়ার্ড পরিবর্তন)</span>
        </h4>

        <form onSubmit={handleChangePassword} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1">
              Current Password
            </label>
            <input
              type="password"
              value={currentPass}
              onChange={(e) => setCurrentPass(e.target.value)}
              placeholder="বর্তমান পাসওয়ার্ড"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1">
              New Password
            </label>
            <input
              type="password"
              value={newPass}
              onChange={(e) => setNewPass(e.target.value)}
              placeholder="নতুন পাসওয়ার্ড (ন্যূনতম ৬ অক্ষর)"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1">
              Confirm New Password
            </label>
            <input
              type="password"
              value={confirmPass}
              onChange={(e) => setConfirmPass(e.target.value)}
              placeholder="নতুন পাসওয়ার্ড পুনরায় লিখুন"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          {passMsg && (
            <div className={`text-2xs font-bold flex items-center gap-1 ${passMsg.startsWith('Error') ? 'text-red-400' : 'text-emerald-400'}`}>
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{passMsg}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition cursor-pointer shadow-md shadow-blue-600/20"
          >
            Submit New Password
          </button>
        </form>
      </div>

      {/* Support Center & Admin Link */}
      <div
        className={`p-6 rounded-3xl border text-center space-y-3 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-100/60 border-slate-200'
        }`}
      >
        <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
          SUPPORT CENTER
        </span>
        <div className="flex items-center justify-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
          <MessageCircle className="w-4 h-4 text-emerald-500" />
          <span>Help line [9AM - 10PM] · {settings.supportPhone}</span>
        </div>

        {isAdmin ? (
          <div className="pt-2">
            <button
              onClick={() => setActiveTab('admin')}
              className="px-4 py-2 rounded-xl bg-red-600/10 hover:bg-red-600/20 text-red-500 border border-red-500/30 text-xs font-bold inline-flex items-center gap-1.5 transition cursor-pointer shadow-xs"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Open Admin Panel (ম্যানেজমেন্ট প্যানেল)</span>
            </button>
          </div>
        ) : (
          <div className="pt-2 text-2xs text-slate-400">
            <span>লগইন অ্যাকাউন্ট: <strong className="font-mono text-slate-300">{user.email || user.telegramUsername}</strong></span>
          </div>
        )}
      </div>

    </div>
  );
};
