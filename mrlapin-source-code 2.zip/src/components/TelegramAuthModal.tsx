import React, { useState } from 'react';
import { X, Send, Shield, Check, UserCheck, MessageSquare } from 'lucide-react';

interface TelegramAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmTelegram: (data: { username: string; firstName: string; id?: string }) => void;
}

export const TelegramAuthModal: React.FC<TelegramAuthModalProps> = ({ isOpen, onClose, onConfirmTelegram }) => {
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = username.replace('@', '').trim();
    if (!cleanUser) {
      setErrorMsg('দয়া করে আপনার Telegram Username দিন');
      return;
    }
    const finalName = fullName.trim() || cleanUser;
    onConfirmTelegram({
      username: `@${cleanUser}`,
      firstName: finalName
    });
    onClose();
  };

  const handleQuickTelegramLogin = (defaultUser: string, defaultName: string) => {
    onConfirmTelegram({
      username: defaultUser,
      firstName: defaultName
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-500/20 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Telegram Top Banner */}
        <div className="p-5 bg-gradient-to-r from-sky-500 to-blue-600 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-full bg-white/10 hover:bg-white/20 transition text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white text-sky-500 flex items-center justify-center shadow-lg shadow-sky-600/30 shrink-0">
              <Send className="w-6 h-6 -translate-x-0.5 translate-y-0.5" />
            </div>
            <div>
              <h3 className="text-base font-black tracking-wide">
                Login with Telegram
              </h3>
              <p className="text-2xs text-sky-100 opacity-90">
                টেলিগ্রাম অ্যাকাউন্ট দিয়ে সরাসরি লগইন করুন
              </p>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-500 text-2xs font-semibold">
              {errorMsg}
            </div>
          )}

          {/* Quick 1-Click Telegram Profiles */}
          <div className="space-y-2">
            <p className="text-2xs font-bold text-slate-400 uppercase tracking-wider">
              দ্রুত ১-ক্লিক টেলিগ্রাম লগইন:
            </p>

            <button
              onClick={() => handleQuickTelegramLogin('@gamer_tanvir', 'Tanvir VIP')}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-sky-500 hover:bg-sky-500/5 flex items-center justify-between text-left transition cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-sky-500 text-white font-bold text-xs flex items-center justify-center">
                  ✈️
                </div>
                <div>
                  <span className="font-bold text-xs text-slate-900 dark:text-white block">
                    Tanvir VIP
                  </span>
                  <span className="text-2xs font-mono text-sky-500">
                    @gamer_tanvir
                  </span>
                </div>
              </div>
              <span className="text-3xs font-bold px-2 py-0.5 rounded bg-sky-500/10 text-sky-500">
                কানেক্ট
              </span>
            </button>
          </div>

          {/* Divider */}
          <div className="relative flex items-center justify-center">
            <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
            <span className="bg-white dark:bg-slate-900 px-3 text-3xs font-semibold text-slate-400 uppercase tracking-wider absolute">
              অথবা আপনার ইউজারনেম দিন
            </span>
          </div>

          {/* Custom Telegram Input Form */}
          <form onSubmit={handleManualSubmit} className="space-y-3">
            <div>
              <label className="block text-2xs font-bold text-slate-400 mb-1">
                Telegram Username (@username):
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-mono">
                  @
                </span>
                <input
                  type="text"
                  required
                  value={username.replace('@', '')}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="your_telegram_id"
                  className="w-full pl-7 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-2xs font-bold text-slate-400 mb-1">
                আপনার নাম (Display Name):
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. FreeFire Boss"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white font-bold text-xs shadow-md shadow-sky-500/20 transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Telegram দিয়ে লগইন নিশ্চিত করুন</span>
            </button>
          </form>
        </div>

        {/* Security Trust Footnote */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-center gap-1.5 text-3xs text-slate-400">
          <Shield className="w-3 h-3 text-sky-500" />
          <span>Telegram Bot API Security · End-to-End Session Verified</span>
        </div>
      </div>
    </div>
  );
};
