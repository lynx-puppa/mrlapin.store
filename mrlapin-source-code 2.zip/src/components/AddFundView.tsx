import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Copy, Check, CheckCircle2, Clock, XCircle, AlertCircle, HelpCircle } from 'lucide-react';

export const AddFundView: React.FC = () => {
  const {
    gateways,
    deposits,
    submitDeposit,
    isDarkMode
  } = useStore();

  const [selectedGatewayId, setSelectedGatewayId] = useState<string>('bkash');
  const [amount, setAmount] = useState<string>('50');
  const [senderNumber, setSenderNumber] = useState<string>('');
  const [trxId, setTrxId] = useState<string>('');
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const selectedGateway = gateways.find((g) => g.id === selectedGatewayId) || gateways[0];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const numericAmount = parseFloat(amount);
    if (!numericAmount || numericAmount <= 0) {
      setErrorMessage('সঠিক টাকার পরিমাণ লিখুন (Minimum ৳ 10)');
      return;
    }

    if (numericAmount < selectedGateway.minAmount) {
      setErrorMessage(`এই গেটওয়েতে সর্বনিম্ন ৳ ${selectedGateway.minAmount} পাঠাতে হবে।`);
      return;
    }

    if (!senderNumber.trim()) {
      setErrorMessage('যে নম্বর থেকে টাকা পাঠিয়েছেন সেই নম্বরটি লিখুন।');
      return;
    }

    if (!trxId.trim()) {
      setErrorMessage('টাকা পাঠানোর পর প্রাপ্ত ট্রানজেকশন আইডি (TrxID) লিখুন।');
      return;
    }

    const success = submitDeposit(selectedGateway.id, numericAmount, senderNumber, trxId);
    if (success) {
      setSuccessMessage(`অভিনন্দন! ৳ ${numericAmount} সফলভাবে আপনার ওয়ালেটে ইনস্ট্যান্ট যুক্ত হয়েছে! (TrxID: ${trxId.trim().toUpperCase()})`);
      setTrxId('');
      setSenderNumber('');
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-36 max-w-4xl mx-auto w-full max-w-full overflow-hidden">
      
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Add Money
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          Select payment method, send money to the admin number, and submit TrxID to add funds.
        </p>
      </div>

      {/* Main Payment Form Card */}
      <div
        className={`rounded-2xl border p-5 sm:p-7 shadow-xs ${
          isDarkMode
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <span className="font-bold text-xs uppercase tracking-wider text-slate-400 block mb-3">
          Select Payment Method
        </span>

        {/* Gateways Grid matching video */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
          {gateways.map((gw) => {
            const isSelected = selectedGatewayId === gw.id;

            return (
              <button
                key={gw.id}
                type="button"
                onClick={() => setSelectedGatewayId(gw.id)}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer relative ${
                  isSelected
                    ? 'border-red-500 bg-red-500/10 shadow-sm ring-1 ring-red-500'
                    : isDarkMode
                    ? 'border-slate-800 bg-slate-800/40 hover:border-slate-700'
                    : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: gw.color }}
                  />
                  <span className="text-2xs font-mono font-bold text-slate-400">
                    Min: {gw.minAmount}
                  </span>
                </div>

                <div className="font-black text-xs sm:text-sm text-slate-900 dark:text-white">
                  {gw.name}
                </div>
                <div className="text-2xs text-slate-400 mt-0.5 truncate">
                  {gw.subType}
                </div>

                {gw.rateInfo && (
                  <div className="text-2xs font-bold text-amber-500 mt-1 font-mono">
                    {gw.rateInfo}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Payment Details Box with Admin Number */}
        <div className="p-4 rounded-xl border border-indigo-500/30 bg-indigo-500/5 mb-6 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
                টাকা পাঠানোর নম্বর / এড্রেস:
              </span>
              <div className="font-mono text-base sm:text-lg font-black text-red-500 mt-0.5 flex items-center gap-2">
                <span>{selectedGateway.numberOrAddress}</span>
                <span className="text-2xs font-bold px-2 py-0.5 rounded bg-red-500/10 text-red-500">
                  {selectedGateway.subType}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => handleCopy(selectedGateway.numberOrAddress)}
              className="px-3.5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto shrink-0 shadow-xs"
            >
              {copiedNumber ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedNumber ? 'কপি হয়েছে' : 'নম্বর কপি করুন'}</span>
            </button>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed border-t border-slate-200/40 dark:border-slate-800 pt-2.5">
            <strong>নির্দেশনা:</strong> {selectedGateway.instructions}
          </p>
        </div>

        {/* Amount & Inputs Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          
          {/* Quick Amount Pills matching video */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
              Enter the amount (টাকার পরিমাণ নির্বাচন করুন)
            </label>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              {['10', '50', '100', '200', '500', '1000'].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAmount(amt)}
                  className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition-all cursor-pointer ${
                    amount === amt
                      ? 'bg-blue-600 text-white shadow-xs ring-1 ring-blue-400'
                      : isDarkMode
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                  }`}
                >
                  ৳ {amt}
                </button>
              ))}
            </div>

            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Amount (৳)"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 font-mono text-sm text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
            />
          </div>

          {/* Sender Phone Number */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              যে নম্বর বা একাউন্ট থেকে টাকা পাঠিয়েছেন:
            </label>
            <input
              type="text"
              value={senderNumber}
              onChange={(e) => setSenderNumber(e.target.value)}
              placeholder="e.g. 018813913894"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
            />
          </div>

          {/* Transaction ID */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Transaction ID (TrxID):
            </label>
            <input
              type="text"
              value={trxId}
              onChange={(e) => setTrxId(e.target.value)}
              placeholder="e.g. 764TQHRK"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 font-mono uppercase text-sm text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
            />
          </div>

          {/* Feedback Messages */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-500 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Big Red Button matching video */}
          <button
            type="submit"
            className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-700 active:scale-98 text-white font-black text-sm tracking-wide shadow-lg shadow-red-600/30 transition-all cursor-pointer"
          >
            Click Here To Add Money
          </button>
        </form>
      </div>

      {/* How to add money helper banner */}
      <div
        className={`p-4 rounded-xl border flex items-center gap-3 text-xs ${
          isDarkMode
            ? 'bg-slate-900/60 border-slate-800 text-slate-300'
            : 'bg-white border-slate-200 text-slate-600'
        }`}
      >
        <HelpCircle className="w-4 h-4 text-emerald-500 shrink-0" />
        <span>
          <strong>How to add money:</strong> নম্বরে Send Money করার পর ট্রানজেকশন আইডি (TrxID) ও টাকার পরিমাণ সাবমিট করলেই সাথে সাথে আপনার ওয়ালেটে টাকা যুক্ত হয়ে যাবে।
        </span>
      </div>

      {/* My Deposits Section (matching video 00:48 - 00:53) */}
      <div
        className={`rounded-2xl border p-5 sm:p-6 transition-all ${
          isDarkMode
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200 dark:border-slate-800">
          <h3 className="font-black text-base tracking-tight">
            My Deposits
          </h3>
          <span className="text-2xs font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-400">
            {deposits.length} deposits
          </span>
        </div>

        {deposits.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400">
            No deposits found.
          </div>
        ) : (
          <div className="space-y-4">
            {deposits.map((dep) => (
              <div
                key={dep.id}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/30 space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 dark:text-white">
                    Serial NO: {dep.serialNo}
                  </span>
                  <span
                    className={`font-bold uppercase text-2xs px-2 py-0.5 rounded ${
                      dep.status === 'completed'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : dep.status === 'pending'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'bg-red-500/10 text-red-400 border border-red-500/30'
                    }`}
                  >
                    Status: {dep.status}
                  </span>
                </div>

                <div className="text-slate-400 text-2xs font-mono">
                  Date: {dep.date}
                </div>

                <div className="text-slate-600 dark:text-slate-300">
                  <strong>Gateway:</strong> {dep.gateway}
                </div>

                <div className="text-slate-600 dark:text-slate-300">
                  <strong>Payment Method:</strong> {dep.paymentMethod}
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-200/40 dark:border-slate-800">
                  <span className="font-mono text-2xs text-slate-400 truncate">
                    Transaction ID: <span className="font-bold text-slate-700 dark:text-slate-200">{dep.trxId}</span>
                  </span>
                  <span className="font-mono font-black text-amber-500 text-sm">
                    Amount: ৳{dep.amount}
                  </span>
                </div>

                {dep.adminNote && (
                  <div className="text-2xs text-slate-400 italic">
                    Note: {dep.adminNote}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
