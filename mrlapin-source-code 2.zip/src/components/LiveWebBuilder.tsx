import React, { useState } from 'react';
import { Download, Copy, Check, Eye, Monitor, Smartphone, Tablet, RefreshCw, Send, ArrowUpRight, Palette } from 'lucide-react';

interface TemplateConfig {
  template: 'portfolio' | 'business' | 'agency' | 'bio';
  name: string;
  tagline: string;
  bio: string;
  primaryColor: string;
  contactEmail: string;
  contactPhone: string;
  whatsapp: string;
  ctaText: string;
  items: {
    title: string;
    description: string;
    badge: string;
  }[];
}

const DEFAULT_CONFIGS: Record<string, TemplateConfig> = {
  portfolio: {
    template: 'portfolio',
    name: 'তানভীর আহমেদ',
    tagline: 'ওয়েব ডিজাইনার ও ডিজিটাল ক্রিয়েটর',
    bio: 'আমি গত ৩ বছর ধরে আধুনিক, রেসপনসিভ ও দৃষ্টিনন্দন ওয়েবসাইট তৈরি করছি। আপনার স্বপ্নকে ডিজিটাল রূপ দিতে আমি প্রতিজ্ঞাবদ্ধ।',
    primaryColor: '#4f46e5', // indigo
    contactEmail: 'tanvir@example.com',
    contactPhone: '+880 1700 000000',
    whatsapp: '8801700000000',
    ctaText: 'কাজের প্রস্তাব পাঠান',
    items: [
      {
        title: 'ই-কমার্স ফ্যাশন স্টোর',
        description: 'অনলাইন শপিংয়ের জন্য অপ্টিমাইজড আধুনিক ওয়েবসাইট ও কার্ট সিস্টেম।',
        badge: 'ওয়েব ডিজাইন'
      },
      {
        title: 'রেস্তোরাঁ মেনু ও অর্ডারিং অ্যাপ',
        description: 'সহজেই খাবার অর্ডার এবং টেবিল বুকিং করার ডিজিটাল প্ল্যাটফর্ম।',
        badge: 'UI/UX ডিজাইন'
      },
      {
        title: 'ব্যক্তিগত ব্লগ ও পোর্টফোলিও',
        description: 'সুপার ফাস্ট লোডিং স্পিড ও গুগল সার্চ অপ্টিমাইজড ব্যক্তিগত সাইট।',
        badge: 'এসইও ও ডেভেলপমেন্ট'
      }
    ]
  },
  business: {
    template: 'business',
    name: 'ধানসিঁড়ি ক্যাফে অ্যান্ড রেস্তোরাঁ',
    tagline: 'সেরা স্বাদের কফি ও স্বাস্থ্যকর দেশীয় খাবার',
    bio: 'ধানমন্ডির কেন্দ্রস্থলে পরিবার ও বন্ধুদের সাথে আরামদায়ক পরিবেশে সময় কাটানোর প্রিমিয়াম স্থান। সম্পূর্ণ ঘরোয়া স্বাদে প্রস্তুতকৃত সেরা মেনু।',
    primaryColor: '#059669', // emerald
    contactEmail: 'contact@dhansiri.com',
    contactPhone: '+880 1800 112233',
    whatsapp: '8801800112233',
    ctaText: 'টেবিল বুকিং বা অর্ডার করুন',
    items: [
      {
        title: 'সিগনেচার ক্যাপুচিনো ও পেস্ট্রি',
        description: 'তাজা রোস্টেড প্রিমিয়াম কফি বিন্স ও মুখরোচক ফ্রেঞ্চ বেকারি।',
        badge: 'স্পেশাল কফি'
      },
      {
        title: 'ঐতিহ্যবাহী কাচ্চি বিরিয়ানি',
        description: 'খাঁটি ঘি ও জাফরানের সুগন্ধে তৈরি ঐতিহ্যবাহী মুখরোচক কাচ্চি।',
        badge: 'লাঞ্চ ও ডিনার'
      },
      {
        title: 'হোম ডেলিভারি সার্ভিস',
        description: 'মাত্র ৩০ মিনিটে গরম খাবার আপনার দোরগোড়ায় ফ্রি ডেলিভারি।',
        badge: 'ফাস্ট ডেলিভারি'
      }
    ]
  },
  agency: {
    template: 'agency',
    name: 'নেক্সট ডিজিটাল সল্যুশনস',
    tagline: 'আপনার ব্যবসাকে অনলাইনে এগিয়ে নেওয়ার বিশ্বস্ত সঙ্গী',
    bio: 'সোশ্যাল মিডিয়া মার্কেটিং, গুগল অ্যাডস ও ওয়েবসাইট ডেভেলপমেন্টের মাধ্যমে আপনার বিক্রয় বৃদ্ধি করতে সাহায্য করি।',
    primaryColor: '#0284c7', // sky
    contactEmail: 'growth@nextdigital.com',
    contactPhone: '+880 1900 445566',
    whatsapp: '8801900445566',
    ctaText: 'ফ্রি কনসালটেশন নিন',
    items: [
      {
        title: 'ফেসবুক ও ইনস্টাগ্রাম গ্রোথ',
        description: 'টার্গেটেড বিজ্ঞাপন ও আকর্ষণীয় কন্টেন্ট বানিয়ে অডিয়েন্স বাড়ানো।',
        badge: 'মার্কেটিং'
      },
      {
        title: 'বিজনেস ওয়েবসাইট মেকিং',
        description: 'মোবাইল ফ্রেন্ডলি ও দ্রুত লোড হওয়া কর্পোরেট ওয়েবসাইট।',
        badge: 'ডেভেলপমেন্ট'
      },
      {
        title: 'ব্র্যান্ডিং ও গ্রাফিক্স ডিজাইন',
        description: 'লোগো, ব্যানার ও সোশ্যাল পোস্টের নজরকাড়া প্রিমিয়াম ডিজাইন।',
        badge: 'ব্র্যান্ডিং'
      }
    ]
  },
  bio: {
    template: 'bio',
    name: 'ফারহানা ইসলাম',
    tagline: 'ইউটিউবার · ট্রাভেলার · টেক এনথুজিয়াস্ট',
    bio: 'আমার সব সোশ্যাল মিডিয়া প্রোফাইল, ইউটিউব ভিডিও এবং বিশেষ রিসোর্সগুলো একসাথে নিচে পেয়ে যাবেন। সাথে থাকার জন্য ধন্যবাদ!',
    primaryColor: '#e11d48', // rose
    contactEmail: 'farhana@creators.me',
    contactPhone: '+880 1600 778899',
    whatsapp: '8801600778899',
    ctaText: 'ইউটিউব সাবস্ক্রাইব করুন',
    items: [
      {
        title: 'সর্বশেষ ইউটিউব ভ্লগ',
        description: 'সাজেক ভ্যালি ভ্রমণের সম্পূর্ণ বাজেট গাইড ও অভিজ্ঞতা।',
        badge: 'ইউটিউব'
      },
      {
        title: 'ফেসবুক কমিউনিটি পেজ',
        description: 'প্রতিদিনের লাইফস্টাইল ও টেক টিপস জানতে যুক্ত হোন।',
        badge: 'ফেসবুক'
      },
      {
        title: 'ফ্রি রিসোর্স ও গাইডলাইন PDF',
        description: 'নতুনদের জন্য ভিডিও এডিটিংয়ের প্রয়োজনীয় সফটওয়্যার ও প্রিসেট।',
        badge: 'ফ্রি ডাউনলোড'
      }
    ]
  }
};

const COLOR_PRESETS = [
  { name: 'Indigo', value: '#4f46e5' },
  { name: 'Emerald', value: '#059669' },
  { name: 'Sky Blue', value: '#0284c7' },
  { name: 'Rose Red', value: '#e11d48' },
  { name: 'Amber Gold', value: '#d97706' },
  { name: 'Dark Slate', value: '#0f172a' }
];

export const LiveWebBuilder: React.FC<{ lang: 'bn' | 'en'; onGoToPublish: () => void }> = ({
  lang,
  onGoToPublish
}) => {
  const [selectedTemplate, setSelectedTemplate] = useState<'portfolio' | 'business' | 'agency' | 'bio'>('portfolio');
  const [config, setConfig] = useState<TemplateConfig>(DEFAULT_CONFIGS.portfolio);
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [copied, setCopied] = useState(false);

  const handleTemplateSwitch = (t: 'portfolio' | 'business' | 'agency' | 'bio') => {
    setSelectedTemplate(t);
    setConfig(DEFAULT_CONFIGS[t]);
  };

  const handleItemChange = (index: number, field: 'title' | 'description' | 'badge', val: string) => {
    const updated = [...config.items];
    updated[index][field] = val;
    setConfig({ ...config, items: updated });
  };

  // Generate self-contained, pristine HTML string
  const generateCleanHtml = () => {
    return `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${config.name} - ${config.tagline}</title>
  <meta name="description" content="${config.bio.slice(0, 150)}">
  <!-- Tailwind CSS CDN for instant styling -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Hind Siliguri', sans-serif; }
  </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased min-h-screen flex flex-col justify-between">

  <!-- Header -->
  <header class="bg-white border-b border-slate-200 sticky top-0 z-30">
    <div class="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
      <div class="text-xl font-bold tracking-tight" style="color: ${config.primaryColor}">
        ${config.name}
      </div>
      <a href="https://wa.me/${config.whatsapp}" target="_blank" class="px-4 py-2 text-xs font-semibold text-white rounded-lg shadow-sm hover:opacity-90 transition" style="background-color: ${config.primaryColor}">
        ${config.ctaText}
      </a>
    </div>
  </header>

  <!-- Hero Section -->
  <main class="max-w-5xl mx-auto px-4 py-12 md:py-20 w-full space-y-12">
    <div class="text-center max-w-2xl mx-auto space-y-4">
      <div class="inline-block px-3 py-1 rounded-full text-xs font-semibold" style="background-color: ${config.primaryColor}15; color: ${config.primaryColor}">
        ${config.tagline}
      </div>
      <h1 class="text-3xl sm:text-5xl font-bold text-slate-900 tracking-tight leading-tight">
        স্বাগতম, আমি <span style="color: ${config.primaryColor}">${config.name}</span>
      </h1>
      <p class="text-base sm:text-lg text-slate-600 leading-relaxed">
        ${config.bio}
      </p>
      <div class="flex flex-wrap items-center justify-center gap-3 pt-2">
        <a href="https://wa.me/${config.whatsapp}" target="_blank" class="px-6 py-3 text-sm font-semibold text-white rounded-lg shadow hover:opacity-95 transition" style="background-color: ${config.primaryColor}">
          💬 হোয়াটসঅ্যাপে মেসেজ করুন
        </a>
        <a href="mailto:${config.contactEmail}" class="px-5 py-3 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition">
          ✉️ ইমেইল পাঠান
        </a>
      </div>
    </div>

    <!-- Features / Showcase Grid -->
    <div class="pt-6">
      <h2 class="text-xl sm:text-2xl font-bold text-center text-slate-900 mb-8">
        বিশেষ আকর্ষণ ও সেবাসমূহ
      </h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        ${config.items
          .map(
            (it) => `
        <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow transition">
          <span class="text-xs font-semibold px-2.5 py-1 rounded-md" style="background-color: ${config.primaryColor}15; color: ${config.primaryColor}">
            ${it.badge}
          </span>
          <h3 class="text-lg font-bold text-slate-900 mt-3 mb-2">
            ${it.title}
          </h3>
          <p class="text-sm text-slate-600 leading-relaxed">
            ${it.description}
          </p>
        </div>`
          )
          .join('')}
      </div>
    </div>

    <!-- Contact Banner -->
    <div class="bg-white rounded-2xl border border-slate-200 p-8 text-center max-w-xl mx-auto space-y-3 shadow-xs">
      <h3 class="text-xl font-bold text-slate-900">সরাসরি যোগাযোগ করুন</h3>
      <p class="text-sm text-slate-600">যেকোনো প্রশ্ন বা বিস্তারিত জানতে সরাসরি কল বা হোয়াটসঅ্যাপ করুন।</p>
      <div class="text-sm font-medium text-slate-700 space-y-1">
        <div>📞 ফোন: <a href="tel:${config.contactPhone}" class="hover:underline font-semibold">${config.contactPhone}</a></div>
        <div>📧 ইমেইল: <a href="mailto:${config.contactEmail}" class="hover:underline font-semibold">${config.contactEmail}</a></div>
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
    <div class="max-w-5xl mx-auto px-4">
      <p>© ${new Date().getFullYear()} ${config.name} · সর্বস্বত্ব সংরক্ষিত</p>
      <p class="mt-1 text-slate-400">তৈরি হয়েছে ১০০% ফ্রিতে WebShilpi দিয়ে</p>
    </div>
  </footer>

</body>
</html>`;
  };

  const handleDownload = () => {
    const html = generateCleanHtml();
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    const html = generateCleanHtml();
    navigator.clipboard.writeText(html);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="builder" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">
              {lang === 'bn' ? 'ইন্টারেক্টিভ বিল্ডার ও কোড এক্সপোর্টার' : 'Interactive Builder & Exporter'}
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mt-1">
              {lang === 'bn' ? 'নিজের ওয়েবসাইট এখনই কাস্টমাইজ করুন' : 'Customize Your Free Website Now'}
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              {lang === 'bn'
                ? 'টেমপ্লেট বেছে নিন, নিজের তথ্য দিয়ে সাজান এবং ১ ক্লিকে index.html ফাইল ডাউনলোড করে সাথে সাথে পাবলিশ করুন!'
                : 'Select a template, customize content, and download index.html ready for Netlify or GitHub!'}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? (lang === 'bn' ? 'কপি হয়েছে!' : 'Copied!') : (lang === 'bn' ? 'কোড কপি করুন' : 'Copy HTML')}</span>
            </button>

            <button
              onClick={handleDownload}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'ডাউনলোড index.html' : 'Download index.html'}</span>
            </button>
          </div>
        </div>

        {/* Template Selector Bar */}
        <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-100 rounded-xl mb-6">
          <span className="text-xs font-semibold text-slate-500 px-3">
            {lang === 'bn' ? 'টেমপ্লেট:' : 'Template:'}
          </span>
          <button
            onClick={() => handleTemplateSwitch('portfolio')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              selectedTemplate === 'portfolio'
                ? 'bg-white text-slate-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'bn' ? '👨‍💻 পোর্টফোলিও ও সিভি' : 'Portfolio & CV'}
          </button>
          <button
            onClick={() => handleTemplateSwitch('business')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              selectedTemplate === 'business'
                ? 'bg-white text-slate-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'bn' ? '☕ রেস্তোরাঁ / ক্যাফে / দোকান' : 'Restaurant & Store'}
          </button>
          <button
            onClick={() => handleTemplateSwitch('agency')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              selectedTemplate === 'agency'
                ? 'bg-white text-slate-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'bn' ? '🚀 সার্ভিস ও এজেন্সি' : 'Agency & Service'}
          </button>
          <button
            onClick={() => handleTemplateSwitch('bio')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              selectedTemplate === 'bio'
                ? 'bg-white text-slate-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'bn' ? '🔗 সোশ্যাল লিংক-ইন-বায়ো' : 'Link in Bio Hub'}
          </button>
        </div>

        {/* Main 2-Column Split: Left Controls, Right Live Preview */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Form Editor (4 cols) */}
          <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-5 h-[680px] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="text-xs font-bold text-slate-900 uppercase">
                {lang === 'bn' ? 'সাইটের তথ্য এডিট করুন' : 'Edit Website Content'}
              </span>
              <button
                onClick={() => setConfig(DEFAULT_CONFIGS[selectedTemplate])}
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
                title="Reset to default"
              >
                <RefreshCw className="w-3 h-3" />
                <span>{lang === 'bn' ? 'রিসেট' : 'Reset'}</span>
              </button>
            </div>

            {/* Brand Name & Tagline */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {lang === 'bn' ? 'নাম / প্রতিষ্ঠানের নাম:' : 'Name / Brand:'}
                </label>
                <input
                  type="text"
                  value={config.name}
                  onChange={(e) => setConfig({ ...config, name: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {lang === 'bn' ? 'ট্যাগলাইন / পদবী:' : 'Tagline:'}
                </label>
                <input
                  type="text"
                  value={config.tagline}
                  onChange={(e) => setConfig({ ...config, tagline: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {lang === 'bn' ? 'সংক্ষিপ্ত বিবরণ (Bio):' : 'Bio / Description:'}
                </label>
                <textarea
                  rows={3}
                  value={config.bio}
                  onChange={(e) => setConfig({ ...config, bio: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
                />
              </div>
            </div>

            {/* Color Palette Selector */}
            <div className="pt-2">
              <label className="block text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-slate-500" />
                <span>{lang === 'bn' ? 'থিম কালার নির্বাচন করুন:' : 'Theme Color:'}</span>
              </label>
              <div className="flex items-center gap-2">
                {COLOR_PRESETS.map((c) => (
                  <button
                    key={c.value}
                    onClick={() => setConfig({ ...config, primaryColor: c.value })}
                    className={`w-7 h-7 rounded-full border-2 transition-transform cursor-pointer ${
                      config.primaryColor === c.value ? 'scale-115 border-slate-900' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: c.value }}
                    title={c.name}
                  />
                ))}
              </div>
            </div>

            {/* Items / Showcase Cards */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-semibold text-slate-700">
                {lang === 'bn' ? '৩টি প্রজেক্ট বা সার্ভিসের বিবরণ:' : 'Showcase Items (3):'}
              </label>
              {config.items.map((item, idx) => (
                <div key={idx} className="p-3 bg-white border border-slate-200 rounded-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-medium text-slate-500">
                    <span>আইটেম #{idx + 1}</span>
                    <input
                      type="text"
                      value={item.badge}
                      placeholder="ক্যাটাগরি"
                      onChange={(e) => handleItemChange(idx, 'badge', e.target.value)}
                      className="px-2 py-0.5 bg-slate-50 border border-slate-200 rounded text-2xs text-slate-700 text-right"
                    />
                  </div>
                  <input
                    type="text"
                    value={item.title}
                    placeholder="শিরোনাম"
                    onChange={(e) => handleItemChange(idx, 'title', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 font-medium"
                  />
                  <textarea
                    rows={2}
                    value={item.description}
                    placeholder="বিবরণ"
                    onChange={(e) => handleItemChange(idx, 'description', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs text-slate-600"
                  />
                </div>
              ))}
            </div>

            {/* Contact Details */}
            <div className="space-y-3 pt-2 border-t border-slate-200">
              <span className="text-xs font-bold text-slate-900 block">
                {lang === 'bn' ? 'যোগাযোগের তথ্য:' : 'Contact Info:'}
              </span>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-2xs font-medium text-slate-600 mb-0.5">WhatsApp (Country Code):</label>
                  <input
                    type="text"
                    value={config.whatsapp}
                    onChange={(e) => setConfig({ ...config, whatsapp: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-2xs font-medium text-slate-600 mb-0.5">ইমেইল:</label>
                  <input
                    type="text"
                    value={config.contactEmail}
                    onChange={(e) => setConfig({ ...config, contactEmail: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs text-slate-800"
                  />
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Live Viewport Preview (7 cols) */}
          <div className="lg:col-span-7 space-y-3">
            {/* Viewport bar */}
            <div className="flex items-center justify-between p-2.5 bg-slate-100 rounded-xl border border-slate-200 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-800">{lang === 'bn' ? 'লাইভ প্রিভিউ:' : 'Live Preview:'}</span>
                <span className="text-2xs text-slate-500 font-mono">
                  {viewport === 'desktop' ? 'Desktop 100%' : viewport === 'tablet' ? 'Tablet 768px' : 'Mobile 375px'}
                </span>
              </div>

              <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-200 shadow-xs">
                <button
                  onClick={() => setViewport('desktop')}
                  className={`p-1.5 rounded transition cursor-pointer ${
                    viewport === 'desktop' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-500 hover:text-slate-800'
                  }`}
                  title="Desktop View"
                >
                  <Monitor className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setViewport('tablet')}
                  className={`p-1.5 rounded transition cursor-pointer ${
                    viewport === 'tablet' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-500 hover:text-slate-800'
                  }`}
                  title="Tablet View"
                >
                  <Tablet className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setViewport('mobile')}
                  className={`p-1.5 rounded transition cursor-pointer ${
                    viewport === 'mobile' ? 'bg-indigo-50 text-indigo-600' : 'text-slate-500 hover:text-slate-800'
                  }`}
                  title="Mobile View"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Sandbox Container */}
            <div className="bg-slate-200 p-3 sm:p-6 rounded-2xl flex justify-center items-center min-h-[620px] overflow-hidden">
              <div
                className={`transition-all duration-300 bg-white rounded-xl shadow-lg border border-slate-300 overflow-y-auto h-[580px] w-full ${
                  viewport === 'mobile'
                    ? 'max-w-[375px]'
                    : viewport === 'tablet'
                    ? 'max-w-[768px]'
                    : 'max-w-full'
                }`}
              >
                {/* Simulated Header */}
                <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-xs z-10">
                  <div className="font-bold text-sm" style={{ color: config.primaryColor }}>
                    {config.name}
                  </div>
                  <span
                    className="text-2xs font-semibold px-2.5 py-1 text-white rounded-md"
                    style={{ backgroundColor: config.primaryColor }}
                  >
                    {config.ctaText}
                  </span>
                </div>

                {/* Simulated Hero */}
                <div className="px-5 py-8 text-center space-y-3">
                  <span
                    className="inline-block px-2.5 py-0.5 rounded-full text-2xs font-semibold"
                    style={{
                      backgroundColor: `${config.primaryColor}15`,
                      color: config.primaryColor
                    }}
                  >
                    {config.tagline}
                  </span>
                  <h1 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
                    স্বাগতম, আমি <span style={{ color: config.primaryColor }}>{config.name}</span>
                  </h1>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-md mx-auto">
                    {config.bio}
                  </p>
                  <div className="flex items-center justify-center gap-2 pt-2">
                    <span
                      className="px-3 py-1.5 text-2xs font-semibold text-white rounded-md shadow-xs"
                      style={{ backgroundColor: config.primaryColor }}
                    >
                      💬 হোয়াটসঅ্যাপ
                    </span>
                    <span className="px-3 py-1.5 text-2xs font-medium text-slate-700 bg-slate-100 rounded-md">
                      ✉️ ইমেইল
                    </span>
                  </div>
                </div>

                {/* Simulated Items */}
                <div className="px-5 pb-8 space-y-4">
                  <div className="text-center font-bold text-xs text-slate-800">
                    সেবাসমূহ ও কাজ
                  </div>
                  <div className={`grid gap-3 ${viewport === 'mobile' ? 'grid-cols-1' : 'grid-cols-3'}`}>
                    {config.items.map((it, idx) => (
                      <div key={idx} className="bg-slate-50 p-3.5 rounded-lg border border-slate-200/80 space-y-1.5">
                        <span
                          className="text-2xs font-semibold px-2 py-0.5 rounded"
                          style={{
                            backgroundColor: `${config.primaryColor}15`,
                            color: config.primaryColor
                          }}
                        >
                          {it.badge}
                        </span>
                        <div className="font-bold text-xs text-slate-900">{it.title}</div>
                        <p className="text-2xs text-slate-600 leading-relaxed">{it.description}</p>
                      </div>
                    ))}
                  </div>

                  {/* Simulated Contact box */}
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs space-y-1">
                    <div className="font-bold text-slate-800">যোগাযোগ করুন</div>
                    <div className="text-slate-600 text-2xs">{config.contactPhone} · {config.contactEmail}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Next Step Banner */}
            <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-indigo-900">
                <span className="font-bold">পরবর্তী ধাপ: </span>
                {lang === 'bn'
                  ? 'উপরে "ডাউনলোড index.html" বাটনে ক্লিক করে ফাইলটি নিন, তারপর নিচের পাবলিশিং গাইড দেখে ১ মিনিটে ইন্টারনেটে লাইভ করুন!'
                  : 'Download the index.html file, then follow the publishing walkthrough below to launch in 1 minute!'}
              </div>
              <button
                onClick={onGoToPublish}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
              >
                <span>{lang === 'bn' ? 'পাবলিশিং গাইড খুলুন' : 'Open Publish Guide'}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
