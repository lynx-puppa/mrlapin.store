import React, { useState } from 'react';
import { PLATFORMS_DATA, PlatformGuide } from '../data/guideData';
import { CheckCircle2, XCircle, ExternalLink, ChevronDown, ChevronUp, Sparkles, Clock, Globe } from 'lucide-react';

interface MethodComparisonProps {
  lang: 'bn' | 'en';
  onSelectForPublish: (platformId: string) => void;
}

export const MethodComparison: React.FC<MethodComparisonProps> = ({ lang, onSelectForPublish }) => {
  const [filter, setFilter] = useState<'all' | 'no-code' | 'code-hosting' | 'blog-cms'>('all');
  const [expandedId, setExpandedId] = useState<string | null>('netlify-drop');

  const filtered = PLATFORMS_DATA.filter((p) => {
    if (filter === 'all') return true;
    return p.category === filter;
  });

  return (
    <section id="methods" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">
            {lang === 'bn' ? 'তুলনামূলক বিশ্লেষণ ও বাছাই' : 'Comparative Analysis'}
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            {lang === 'bn'
              ? 'ফ্রিতে ওয়েবসাইট তৈরির জনপ্রিয় প্ল্যাটফর্মসমূহ'
              : 'Popular Free Website Platforms & Hosts'}
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            {lang === 'bn'
              ? 'আপনার প্রয়োজন অনুযায়ী সেরা মাধ্যমটি বেছে নিন। প্রতিটি প্ল্যাটফর্মেই রয়েছে ১০০% আজীবন ফ্রি সুবিধা।'
              : 'Choose the best method according to your workflow. All platforms offer 100% lifetime free tiers.'}
          </p>

          {/* Interactive Filter Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 p-1.5 bg-slate-200/80 rounded-xl w-fit mx-auto mt-6">
            <button
              onClick={() => setFilter('all')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filter === 'all'
                  ? 'bg-white text-slate-900 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'সবগুলো প্ল্যাটফর্ম' : 'All Platforms'}
            </button>
            <button
              onClick={() => setFilter('code-hosting')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filter === 'code-hosting'
                  ? 'bg-white text-slate-900 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'কোড ও ক্লাউড হোস্টিং (Netlify, GitHub)' : 'Code & Cloud Hosting'}
            </button>
            <button
              onClick={() => setFilter('no-code')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filter === 'no-code'
                  ? 'bg-white text-slate-900 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'নো-কোড বিল্ডার (Google Sites, Canva)' : 'No-Code Builders'}
            </button>
            <button
              onClick={() => setFilter('blog-cms')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filter === 'blog-cms'
                  ? 'bg-white text-slate-900 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'ব্লগ ও কনটেন্ট (Blogger)' : 'Blog / CMS'}
            </button>
          </div>
        </div>

        {/* Grid of Platform Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((platform) => {
            const isExpanded = expandedId === platform.id;

            return (
              <div
                key={platform.id}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div className="p-6">
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <div className="text-xs font-bold text-indigo-600 uppercase tracking-wide">
                        {platform.badge}
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mt-1">
                        {platform.name}
                      </h3>
                    </div>
                    <span className="text-xs font-medium text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md">
                      $0 ফ্রি
                    </span>
                  </div>

                  {/* Metadata Row */}
                  <div className="flex items-center gap-3 text-xs text-slate-500 mb-4 pb-3 border-b border-slate-100">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{platform.timeNeeded}</span>
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{lang === 'bn' ? platform.difficulty : platform.difficultyEn}</span>
                  </div>

                  {/* Free URL preview */}
                  <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/60 text-xs text-slate-700 font-mono mb-4 flex items-center justify-between">
                    <span className="truncate">https://{platform.freeUrlFormat}</span>
                    <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  </div>

                  {/* Best For */}
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    <strong className="text-slate-800">{lang === 'bn' ? 'যাঁদের জন্য সেরা: ' : 'Best for: '}</strong>
                    {platform.bestFor}
                  </p>

                  {/* Free tier highlights */}
                  <div className="space-y-1.5 mb-4">
                    {platform.freeTierFeatures.slice(0, 3).map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-600">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>

                  {/* Expandable Step-by-Step Guide */}
                  {isExpanded && (
                    <div className="pt-4 mt-4 border-t border-slate-100 space-y-4 animate-in fade-in duration-200">
                      <div className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                        {lang === 'bn' ? 'কীভাবে করবেন (ধাপসমূহ):' : 'Step-by-Step Instructions:'}
                      </div>

                      <div className="space-y-3">
                        {platform.steps.map((step, sIdx) => (
                          <div key={sIdx} className="bg-slate-50 p-3 rounded-lg border border-slate-200/70 text-xs">
                            <div className="font-semibold text-slate-900 mb-1">
                              {step.title}
                            </div>
                            <p className="text-slate-600 leading-relaxed">
                              {step.description}
                            </p>
                          </div>
                        ))}
                      </div>

                      {/* Pros & Cons */}
                      <div className="grid grid-cols-1 gap-2 pt-2">
                        <div className="bg-emerald-50/70 p-2.5 rounded-lg border border-emerald-100 text-xs">
                          <span className="font-semibold text-emerald-800 block mb-1">
                            {lang === 'bn' ? 'প্রধান সুবিধা:' : 'Key Advantages:'}
                          </span>
                          <ul className="list-disc list-inside space-y-0.5 text-emerald-700">
                            {platform.pros.slice(0, 2).map((pro, pIdx) => (
                              <li key={pIdx}>{pro}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Card Action Footer */}
                <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : platform.id)}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                  >
                    <span>{isExpanded ? (lang === 'bn' ? 'গাইড বন্ধ করুন' : 'Hide Guide') : (lang === 'bn' ? 'বিস্তারিত গাইড দেখুন' : 'View Guide')}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  <a
                    href={platform.officialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1 font-medium"
                  >
                    <span>{lang === 'bn' ? 'অফিসিয়াল সাইট' : 'Visit Official'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
