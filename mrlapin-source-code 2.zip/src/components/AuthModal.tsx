import React from 'react';
import { useStore } from '../context/StoreContext';
import { LoginCard } from './LoginCard';
import { X } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { showAuthModal, setShowAuthModal, authModalInitialTab } = useStore();

  if (!showAuthModal) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto"
      onClick={() => setShowAuthModal(false)}
    >
      <div 
        className="relative w-full max-w-md my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Floating Close Button */}
        <button
          onClick={() => setShowAuthModal(false)}
          className="absolute -top-3 -right-3 z-10 w-8 h-8 rounded-full bg-slate-900 border border-slate-700 text-slate-300 hover:text-white flex items-center justify-center shadow-lg transition cursor-pointer"
          title="Close Modal"
        >
          <X className="w-4 h-4" />
        </button>

        <LoginCard 
          initialMode={authModalInitialTab} 
          onSuccess={() => setShowAuthModal(false)}
        />
      </div>
    </div>
  );
};
