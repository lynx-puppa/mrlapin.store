import React from 'react';
import { Heart, Globe } from 'lucide-react';

export const Footer: React.FC<{ lang: 'bn' | 'en' }> = ({ lang }) => {
  return (
    <footer className="bg-white border-t border-slate-200 py-10 text-xs text-slate-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="font-bold text-slate-800 text-sm">WebShilpi (ওয়েবশিল্পী)</span>
          <p className="mt-1 text-slate-400">
            {lang === 'bn'
              ? 'সম্পূর্ণ ফ্রিতে ওয়েবসাইট তৈরি ও ইন্টারনেটে লাইভ করার উন্মুক্ত নির্দেশিকা ও টুলকিট।'
              : 'Free website creation and lifetime publishing toolkit for everyone.'}
          </p>
        </div>

        <div className="flex items-center gap-6 text-slate-600 font-medium">
          <a href="#methods" className="hover:text-slate-900 transition">
            {lang === 'bn' ? 'পদ্ধতিসমূহ' : 'Methods'}
          </a>
          <a href="#builder" className="hover:text-slate-900 transition">
            {lang === 'bn' ? 'ওয়েবসাইট মেকার' : 'Builder'}
          </a>
          <a href="#publish" className="hover:text-slate-900 transition">
            {lang === 'bn' ? 'পাবলিশিং' : 'Publishing'}
          </a>
          <a href="#checklist" className="hover:text-slate-900 transition">
            {lang === 'bn' ? 'এফএকিউ' : 'FAQ'}
          </a>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-2xs text-slate-400">
        <p>© {new Date().getFullYear()} WebShilpi · সম্পূর্ণ বিনামূল্যে ব্যবহারযোগ্য</p>
        <p className="mt-1 sm:mt-0 flex items-center gap-1">
          <span>Google Sites · Netlify · GitHub Pages সহায়িকা</span>
        </p>
      </div>
    </footer>
  );
};
