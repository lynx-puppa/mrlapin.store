import React, { useState } from 'react';
import { Cloud, UploadCloud, CheckCircle2, Globe, ShieldCheck, ArrowRight, ExternalLink, Terminal, Sparkles, Copy, Check } from 'lucide-react';
import deployDiagram from '../assets/images/deployment_flow_diagram_1792492756559.jpg';

interface PublishingSimulatorProps {
  lang: 'bn' | 'en';
}

export const PublishingSimulator: React.FC<PublishingSimulatorProps> = ({ lang }) => {
  const [activeTab, setActiveTab] = useState<'netlify' | 'github' | 'googlesites'>('netlify');
  const [simState, setSimState] = useState<'idle' | 'uploading' | 'routing' | 'success'>('idle');
  const [customSubdomain, setCustomSubdomain] = useState('amar-notun-site');
  const [copiedUrl, setCopiedUrl] = useState(false);

  const handleStartSimulation = () => {
    setSimState('uploading');
    setTimeout(() => {
      setSimState('routing');
      setTimeout(() => {
        setSimState('success');
      }, 1200);
    }, 1000);
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const simulatedUrl = `https://${customSubdomain.toLowerCase().replace(/[^a-z0-9-]/g, '') || 'my-site'}.netlify.app`;

  return (
    <section id="publish" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">
            {lang === 'bn' ? 'বাস্তব লাইভ ডিপ্লয়মেন্ট নির্দেশিকা' : 'Live Deployment Walkthrough'}
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            {lang === 'bn' ? 'ওয়েবসাইট ইন্টারনেটে কীভাবে ফ্রিতে পাবলিশ করবেন?' : 'How to Publish Your Website for Free'}
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            {lang === 'bn'
              ? 'নিচের ৩টি সবচেয়ে নির্ভরযোগ্য মাধ্যমের যেকোনো একটি বেছে নিন। কোড ফাইল টেনে ছেড়ে দিলেই গোটা বিশ্ব আপনার সাইট দেখতে পারবে।'
              : 'Choose any of the 3 most reliable free hosts. Drag and drop your code and it goes live worldwide.'}
          </p>
        </div>

        {/* Global Cloud Deployment Architecture Diagram Banner */}
        <div className="mb-12 bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs grid grid-cols-1 lg:grid-cols-12 items-center">
          <div className="lg:col-span-7 p-6 sm:p-8 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600">
              <ShieldCheck className="w-4 h-4" />
              <span>{lang === 'bn' ? 'ক্লাউড ডিপ্লয়মেন্ট কীভাবে কাজ করে?' : 'How Cloud Deployment Works'}</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
              {lang === 'bn'
                ? 'আপনার কম্পিউটারের কোড থেকে পৃথিবীর যেকোনো প্রান্তের ব্রাউজারে লাইভ'
                : 'From local code to instant live worldwide access'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {lang === 'bn'
                ? 'যখন আপনি Netlify বা GitHub Pages-এ আপনার index.html আপলোড করেন, তখন গ্লোবাল ক্লাউড সার্ভার স্বয়ংক্রিয়ভাবে একটি ফ্রি সাবডোমেন (.netlify.app বা .github.io) এবং ফ্রি SSL এনক্রিপশন (HTTPS) যুক্ত করে বিশ্বজুড়ে ছড়িয়ে থাকা শত শত এজ সার্ভারে ক্যাশ করে দেয়।'
                : 'When you upload your index.html to Netlify or GitHub Pages, edge servers automatically attach a free subdomain (.netlify.app or .github.io), generate a free SSL certificate, and distribute it to global CDNs.'}
            </p>
            <div className="grid grid-cols-3 gap-3 pt-2 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900 block mb-0.5">১. ফাইল আপলোড</span>
                <span className="text-slate-500 text-2xs">index.html ড্রপ করুন</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900 block mb-0.5">২. ফ্রি SSL সেটআপ</span>
                <span className="text-slate-500 text-2xs">সবুজ প্যাডলক সক্রিয়</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900 block mb-0.5">৩. লাইভ শেয়ার</span>
                <span className="text-slate-500 text-2xs">সবার সাথে লিঙ্ক শেয়ার</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-slate-100 p-2 border-t lg:border-t-0 lg:border-l border-slate-200">
            <img
              src={deployDiagram || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'}
              alt="Deployment Architecture Workflow"
              className="w-full h-auto rounded-xl object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          <button
            onClick={() => setActiveTab('netlify')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activeTab === 'netlify'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {lang === 'bn' ? '১. Netlify Drop (৬০ সেকেন্ডে ড্র্যাগ ও ড্রপ)' : '1. Netlify Drop (Fastest)'}
          </button>

          <button
            onClick={() => setActiveTab('github')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activeTab === 'github'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {lang === 'bn' ? '২. GitHub Pages (আজীবন ফ্রি ও প্রফেশনাল)' : '2. GitHub Pages (Professional)'}
          </button>

          <button
            onClick={() => setActiveTab('googlesites')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activeTab === 'googlesites'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {lang === 'bn' ? '৩. Google Sites (০ কোডিং নো-কোড পদ্ধতি)' : '3. Google Sites (No-Code)'}
          </button>
        </div>

        {/* Active Tab 1: Netlify Drop Simulator */}
        {activeTab === 'netlify' && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-8 animate-in fade-in duration-200">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
              <div>
                <span className="text-2xs font-bold text-indigo-600 uppercase tracking-wider">পদ্ধতি ১: সবচেয়ে সহজ ও দ্রুততম</span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">Netlify Drop ইন্টারেক্টিভ সিমুলেটর</h3>
                <p className="text-xs text-slate-600 mt-1">
                  ব্রাউজারে কোনো কোড বা কমান্ড ছাড়াই শুধু ফোল্ডার টেনে এনে ফেললেই সাথে সাথে ওয়েবসাইট লাইভ হয়ে যায়।
                </p>
              </div>
              <a
                href="https://app.netlify.com/drop"
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition flex items-center gap-1.5 shrink-0 self-start md:self-auto"
              >
                <span>আসল Netlify Drop খুলুন</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Interactive Drop Simulation Zone */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              <div className="lg:col-span-6 space-y-4">
                <div className="text-xs font-semibold text-slate-800">
                  সরাসরি এখানে ডিপ্লয় টেস্ট করুন:
                </div>

                <div className="space-y-1.5">
                  <label className="block text-2xs font-medium text-slate-600">আপনার সাইটের কাঙ্ক্ষিত সাবডোমেন নাম:</label>
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-slate-400 font-mono">https://</span>
                    <input
                      type="text"
                      value={customSubdomain}
                      onChange={(e) => setCustomSubdomain(e.target.value)}
                      placeholder="my-portfolio"
                      className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded text-xs font-mono text-slate-800 w-44 focus:outline-none focus:border-indigo-600"
                    />
                    <span className="text-xs text-slate-400 font-mono">.netlify.app</span>
                  </div>
                </div>

                {/* Drop Area */}
                <div
                  onClick={handleStartSimulation}
                  className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${
                    simState === 'idle'
                      ? 'border-indigo-300 bg-indigo-50/40 hover:bg-indigo-50 hover:border-indigo-500'
                      : simState === 'uploading' || simState === 'routing'
                      ? 'border-amber-400 bg-amber-50/50'
                      : 'border-emerald-500 bg-emerald-50/40'
                  }`}
                >
                  {simState === 'idle' && (
                    <div className="space-y-2">
                      <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
                        <UploadCloud className="w-6 h-6" />
                      </div>
                      <div className="text-sm font-bold text-slate-800">
                        এখানে ক্লিক করে ফোল্ডার আপলোড টেস্ট করুন
                      </div>
                      <p className="text-xs text-slate-500">
                        আপনার 'index.html' ফাইল সম্বলিত ফোল্ডারটি এখানে ছেড়ে দিন
                      </p>
                    </div>
                  )}

                  {simState === 'uploading' && (
                    <div className="space-y-2">
                      <div className="w-10 h-10 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
                      <div className="text-xs font-bold text-slate-800">ফাইল আপলোড হচ্ছে... (১/৩)</div>
                      <p className="text-2xs text-slate-500">HTML এবং স্টাইলশিট কম্প্রেস করা হচ্ছে</p>
                    </div>
                  )}

                  {simState === 'routing' && (
                    <div className="space-y-2">
                      <div className="w-10 h-10 border-3 border-amber-600 border-t-transparent rounded-full animate-spin mx-auto" />
                      <div className="text-xs font-bold text-slate-800">ফ্রি SSL ও গ্লোবাল CDN অ্যাক্টিভেট হচ্ছে... (২/৩)</div>
                      <p className="text-2xs text-slate-500">HTTPS সিকিউরিটি প্রস্তুত করা হচ্ছে</p>
                    </div>
                  )}

                  {simState === 'success' && (
                    <div className="space-y-2">
                      <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                        <CheckCircle2 className="w-6 h-6" />
                      </div>
                      <div className="text-sm font-bold text-emerald-800">
                        অভিনন্দন! আপনার সাইট লাইভ হয়ে গেছে!
                      </div>
                      <p className="text-xs text-slate-600">
                        বিশ্বের যেকোনো স্থান থেকে এখন এটি দেখা যাচ্ছে
                      </p>
                    </div>
                  )}
                </div>

                {simState === 'success' && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 font-mono text-xs text-emerald-900 truncate">
                      <Globe className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="truncate">{simulatedUrl}</span>
                    </div>
                    <button
                      onClick={() => handleCopyUrl(simulatedUrl)}
                      className="px-2.5 py-1 text-2xs font-semibold text-emerald-800 bg-emerald-200/60 hover:bg-emerald-200 rounded transition cursor-pointer flex items-center gap-1 shrink-0"
                    >
                      {copiedUrl ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedUrl ? 'কপি হয়েছে' : 'লিংক কপি'}</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Steps Guide */}
              <div className="lg:col-span-6 space-y-3">
                <div className="text-xs font-bold text-slate-900 uppercase">
                  বাস্তবে করার ৪টি সহজ ধাপ:
                </div>
                
                <div className="space-y-2.5">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-2xs shrink-0">1</span>
                    <div>
                      <strong className="text-slate-900 block mb-0.5">ফাইল সেভ করুন:</strong>
                      আপনার ওয়েবসাইটের কোডটি <code className="bg-slate-200 px-1 py-0.5 rounded text-indigo-700">index.html</code> নামে সেভ করে একটি নতুন ফোল্ডারে রাখুন।
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-2xs shrink-0">2</span>
                    <div>
                      <strong className="text-slate-900 block mb-0.5">Netlify Drop এ যান:</strong>
                      ব্রাউজারে <code className="bg-slate-200 px-1 py-0.5 rounded text-indigo-700">app.netlify.com/drop</code> লিংকে প্রবেশ করুন এবং সাইন ইন করুন।
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-2xs shrink-0">3</span>
                    <div>
                      <strong className="text-slate-900 block mb-0.5">ফোল্ডারটি ড্র্যাগ করে ছেড়ে দিন:</strong>
                      আপনার ফোল্ডারটি টেনে এনে Netlify-এর গোল বক্সে ড্রপ করে দিন। ৫ সেকেন্ডের মধ্যে সাইট লাইভ হয়ে যাবে।
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-2xs shrink-0">4</span>
                    <div>
                      <strong className="text-slate-900 block mb-0.5">পছন্দের নাম পরিবর্তন করুন:</strong>
                      Site Configuration ➔ "Change site name" এ গিয়ে আপনার নাম লিখে Save দিন (যেমন: rahimsite.netlify.app)।
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Active Tab 2: GitHub Pages */}
        {activeTab === 'github' && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6 animate-in fade-in duration-200">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
              <div>
                <span className="text-2xs font-bold text-indigo-600 uppercase tracking-wider">পদ্ধতি ২: প্রফেশনাল ও লাইফটাইম ফ্রি</span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">GitHub Pages গাইডলাইন</h3>
                <p className="text-xs text-slate-600 mt-1">
                  মাইক্রোসফটের গিটহাব প্ল্যাটফর্মের মাধ্যমে সরাসরি আজীবন ফ্রি ওয়েবসাইট হোস্ট করুন।
                </p>
              </div>
              <a
                href="https://github.com/new"
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition flex items-center gap-1.5 shrink-0 self-start md:self-auto"
              >
                <span>GitHub এ New Repository খুলুন</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Step 1 & 2 */}
              <div className="space-y-4">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                    <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs">১</span>
                    <span>গিটহাবে রিপোজিটরি তৈরি করুন</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ১. <a href="https://github.com" target="_blank" className="text-indigo-600 underline">github.com</a> এ গিয়ে একটি ফ্রি অ্যাকাউন্ট খুলুন।<br/>
                    ২. ডানদিকের <strong>+</strong> আইকনে ক্লিক করে <strong>New repository</strong> চাপুন।<br/>
                    ৩. Repository name দিন (যেমন: <code className="bg-slate-200 px-1 rounded">my-portfolio</code>)।<br/>
                    ৪. এটি অবশ্যই <strong>Public</strong> রাখবেন।
                  </p>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                    <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs">২</span>
                    <span>index.html ফাইলটি আপলোড করুন</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ১. তৈরি হওয়া পেজে <strong>"uploading an existing file"</strong> লিংকে ক্লিক করুন।<br/>
                    ২. আপনার কম্পিউটারের <strong>index.html</strong> ফাইলটি টেনে এনে ছেড়ে দিন।<br/>
                    ৩. নিচে সবুজ <strong>Commit changes</strong> বাটনে চাপুন।
                  </p>
                </div>
              </div>

              {/* Step 3 & 4 */}
              <div className="space-y-4">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                    <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs">৩</span>
                    <span>GitHub Pages সক্রিয় (Enable) করুন</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ১. রিপোজিটরির উপরের মেনু থেকে <strong>Settings</strong> এ ক্লিক করুন।<br/>
                    ২. বাম পাশের মেনুতে স্ক্রল করে <strong>Pages</strong> এ চাপুন।<br/>
                    ৩. "Build and deployment" এর নিচে Branch অপশনে <strong>main</strong> বা <strong>master</strong> সিলেক্ট করে <strong>Save</strong> দিন।
                  </p>
                </div>

                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span>সাইট লাইভ ও রেডি!</span>
                  </div>
                  <p className="text-xs text-emerald-800 leading-relaxed">
                    মাত্র ১-২ মিনিট অপেক্ষা করে পেজ রিফ্রেশ করলেই উপরে লিংক দেখতে পাবেন:<br/>
                    <code className="block bg-white p-2 rounded border border-emerald-200 font-mono text-xs text-emerald-900 mt-1 font-semibold">
                      https://your-username.github.io/my-portfolio
                    </code>
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Active Tab 3: Google Sites */}
        {activeTab === 'googlesites' && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6 animate-in fade-in duration-200">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
              <div>
                <span className="text-2xs font-bold text-indigo-600 uppercase tracking-wider">পদ্ধতি ৩: ০ কোডিং, ১০০% নো-কোড</span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">Google Sites সম্পূর্ণ ফ্রি পদ্ধতি</h3>
                <p className="text-xs text-slate-600 mt-1">
                  গুগল ড্রাইভ ও জিমেইল দিয়েই মাউস দিয়ে টেনে এনে সুন্দর পেজ তৈরি ও পাবলিশ করুন।
                </p>
              </div>
              <a
                href="https://sites.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition flex items-center gap-1.5 shrink-0 self-start md:self-auto"
              >
                <span>Google Sites পেজে যান</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">1</span>
                <h4 className="font-bold text-sm text-slate-900">টেমপ্লেট বেছে নিন</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  sites.google.com এ লগইন করে টেমপ্লেট গ্যালারি থেকে Portfolio, Restaurant, Event বা Class প্রজেক্ট থেকে পছন্দসই টেমপ্লেট ক্লিক করুন।
                </p>
              </div>

              <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">2</span>
                <h4 className="font-bold text-sm text-slate-900">নিজের তথ্য ও ছবি দিন</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  যেকোনো লেখার ওপর ডাবল ক্লিক করে বাংলায় লিখুন। ডানদিকের প্যানেল থেকে ছবি, গুগল ড্রাইভের ফাইল, ম্যাপ অথবা ইউটিউব ভিডিও সহজে ড্রপ করুন।
                </p>
              </div>

              <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">3</span>
                <h4 className="font-bold text-sm text-slate-900">Publish এ ক্লিক করুন</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  উপরে ডানদিকের বেগুনি 'Publish' বাটনে চাপুন। আপনার পছন্দের ওয়েব অ্যাড্রেস লিখে দিলেই সাইট সাথে সাথে ইন্টারনেটে লাইভ হয়ে যাবে!
                </p>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
