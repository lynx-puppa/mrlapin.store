import React from 'react';
import { Lock, Globe, Server, CheckCircle2, AlertCircle } from 'lucide-react';

interface DomainAndSSLGuideProps {
  lang: 'bn' | 'en';
}

export const DomainAndSSLGuide: React.FC<DomainAndSSLGuideProps> = ({ lang }) => {
  return (
    <section className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">
            {lang === 'bn' ? 'ডোমেইন, সাবডোমেইন ও এসএসএল গাইড' : 'Domain, Subdomain & SSL Guide'}
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            {lang === 'bn' ? 'ফ্রি ডোমেইন বনাম কাস্টম ডোমেইন: কোনটি আপনার দরকার?' : 'Free Subdomain vs Custom Domain: Which Do You Need?'}
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            {lang === 'bn'
              ? 'ডোমেইন এবং হোস্টিং নিয়ে অনেকের ভুল ধারণা থাকে। কীভাবে আজীবন ০ টাকা খরচে সিকিউর ওয়েবসাইট চালানো যায় তা জেনে নিন।'
              : 'Understand how URL structures, free subdomains, and automatic HTTPS security work.'}
          </p>
        </div>

        {/* URL Anatomy Breakdown */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 mb-10">
          <div className="text-xs font-bold text-slate-700 uppercase mb-4 text-center">
            {lang === 'bn' ? 'একটি ফ্রি ওয়েব ঠিকানার ভেতরের অংশগুলো:' : 'Anatomy of a Free Live Website URL:'}
          </div>

          <div className="max-w-3xl mx-auto bg-white p-4 sm:p-6 rounded-xl border border-slate-300 shadow-xs flex flex-wrap items-center justify-center gap-2 font-mono text-sm sm:text-base text-center">
            <span className="bg-emerald-100 text-emerald-800 px-2 py-1 rounded border border-emerald-300 font-bold flex items-center gap-1">
              <Lock className="w-3.5 h-3.5" />
              https://
            </span>
            <span className="bg-indigo-100 text-indigo-800 px-2.5 py-1 rounded border border-indigo-300 font-bold">
              yourname
            </span>
            <span className="text-slate-400 font-bold">.</span>
            <span className="bg-slate-100 text-slate-800 px-2.5 py-1 rounded border border-slate-300 font-bold">
              netlify.app
            </span>
          </div>

          {/* Explanation 3 columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 pt-6 border-t border-slate-200 text-xs">
            <div className="space-y-1">
              <div className="font-bold text-emerald-800 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5" />
                <span>ফ্রি SSL এনক্রিপশন (HTTPS)</span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                ব্রাউজারের সবুজ প্যাডলক আইকন। এটি ভিজিটরদের ডেটা সুরক্ষিত রাখে এবং গুগলে আপনার সাইটের র‍্যাংকিং বাড়াতে সহায়তা করে।
              </p>
            </div>

            <div className="space-y-1">
              <div className="font-bold text-indigo-800 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5" />
                <span>আপনার ইউনিক নাম (Subdomain)</span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                আপনার নিজের নাম বা ব্যবসার নাম যা সম্পূর্ণ ফ্রিতে নির্বাচন করতে পারবেন (যেমন: rohim-restaurant, dev-sakib)।
              </p>
            </div>

            <div className="space-y-1">
              <div className="font-bold text-slate-800 flex items-center gap-1.5">
                <Server className="w-3.5 h-3.5" />
                <span>হোস্ট প্রোভাইডার এক্সটেনশন</span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                যেহেতু হোস্টিং ফ্রি দিচ্ছে, তাই .netlify.app বা .github.io বা .canva.site যুক্ত থাকে।
              </p>
            </div>
          </div>
        </div>

        {/* Comparison: Free vs Custom Domain */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Card 1: 100% Free Subdomain */}
          <div className="bg-slate-50 rounded-xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg text-slate-900">
                {lang === 'bn' ? '১০০% ফ্রি সাবডোমেন' : '100% Free Subdomain'}
              </h3>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                খরচ: ৳০ / $0
              </span>
            </div>

            <div className="text-xs text-slate-600 space-y-2">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>তৈরি করার সাথে সাথেই লাইভ চালু হয়ে যায়, কোনো রেজিস্ট্রেশন ফি নেই।</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>সিভি, পোর্টফোলিও, ছাত্র-ছাত্রীদের প্রজেক্ট বা প্রাথমিক ব্যবসার জন্য ১০০% পারফেক্ট।</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>আজীবন ফ্রিতে হোস্টিং ও আনলিমিটেড ট্রাফিক চালানো যায়।</span>
              </div>
            </div>
          </div>

          {/* Card 2: Custom .com Domain ($0 Hosting trick) */}
          <div className="bg-slate-50 rounded-xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg text-slate-900">
                {lang === 'bn' ? 'কাস্টম ডোমেইন (.com / .net) ট্রিক' : 'Custom .com Domain Trick'}
              </h3>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-indigo-100 text-indigo-800">
                হোস্টিং ফ্রি (৳০)
              </span>
            </div>

            <div className="text-xs text-slate-600 space-y-2">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <span>
                  <strong>হোস্টিংয়ের পেছনে প্রতি মাসে টাকা দেওয়ার কোনো দরকার নেই!</strong> শুধু Namecheap বা Cloudflare থেকে বছরে মাত্র ৮-১০ ডলার দিয়ে একটি .com ডোমেন কিনুন।
                </span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <span>এরপর সেই ডোমেনটি ফ্রিতে Netlify বা GitHub Pages-এর সাথে DNS পয়েন্ট করে দিন।</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <span>ফলাফল: আপনার নিজস্ব প্রফেশনাল .com সাইট সম্পূর্ণ বিশ্বমানের দ্রুতগতির ফ্রি সার্ভারে আজীবন চলবে!</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
