import React from 'react';
import { useStore } from '../context/StoreContext';
import { Home, PlusCircle, ShoppingBag, QrCode, User, PhoneCall, MessageCircle } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, isDarkMode, settings, t, isLoggedIn, setShowAuthModal } = useStore();

  const handleSupportClick = () => {
    if (settings.supportWhatsapp) {
      window.open(`https://wa.me/${settings.supportWhatsapp}`, '_blank');
    } else if (settings.telegramDmLink) {
      window.open(settings.telegramDmLink, '_blank');
    }
  };

  const handleNavClick = (tab: 'home' | 'add_fund' | 'my_orders' | 'my_codes' | 'account') => {
    if (tab !== 'home' && !isLoggedIn) {
      setShowAuthModal(true);
      return;
    }
    setActiveTab(tab);
  };

  return (
    <>
      {/* Floating Support Button ("সাহায্য লাগবে?" / "Need Help?") */}
      <div className="fixed bottom-20 right-3 sm:right-4 z-40 flex items-center gap-1.5">
        <button
          onClick={handleSupportClick}
          className="group flex items-center gap-1.5 px-2.5 py-1.5 sm:px-4 sm:py-2.5 rounded-full bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-700 hover:to-sky-600 text-white shadow-xl shadow-blue-500/30 transition-all transform hover:scale-105 active:scale-95 cursor-pointer text-xs font-bold"
          title={t('need_help')}
        >
          <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <PhoneCall className="w-3 h-3 text-white animate-pulse" />
          </div>
          <span className="text-2xs sm:text-xs font-bold whitespace-nowrap">
            {t('need_help')}
          </span>
        </button>
      </div>

      {/* 5-Tab Fixed Bottom Bar */}
      <nav
        className={`fixed bottom-0 left-0 right-0 z-40 border-t w-full max-w-full overflow-hidden transition-colors ${
          isDarkMode
            ? 'bg-slate-900/98 border-slate-800 text-slate-400'
            : 'bg-white/98 border-slate-200 text-slate-500'
        }`}
      >
        <div className="max-w-md mx-auto grid grid-cols-5 h-16 items-center px-1">
          
          {/* 1. Home */}
          <button
            onClick={() => handleNavClick('home')}
            className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
              activeTab === 'home'
                ? isDarkMode
                  ? 'text-amber-400'
                  : 'text-blue-600'
                : 'hover:text-slate-300'
            }`}
          >
            <Home className="w-5 h-5 mb-0.5" />
            <span className="text-2xs font-semibold">{t('nav_home')}</span>
          </button>

          {/* 2. Add Fund */}
          <button
            onClick={() => handleNavClick('add_fund')}
            className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
              activeTab === 'add_fund'
                ? isDarkMode
                  ? 'text-amber-400'
                  : 'text-blue-600'
                : 'hover:text-slate-300'
            }`}
          >
            <PlusCircle className="w-5 h-5 mb-0.5" />
            <span className="text-2xs font-semibold">{t('nav_add_fund')}</span>
          </button>

          {/* 3. My Orders */}
          <button
            onClick={() => handleNavClick('my_orders')}
            className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
              activeTab === 'my_orders'
                ? isDarkMode
                  ? 'text-amber-400'
                  : 'text-blue-600'
                : 'hover:text-slate-300'
            }`}
          >
            <ShoppingBag className="w-5 h-5 mb-0.5" />
            <span className="text-2xs font-semibold">{t('nav_my_orders')}</span>
          </button>

          {/* 4. My Codes */}
          <button
            onClick={() => handleNavClick('my_codes')}
            className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
              activeTab === 'my_codes'
                ? isDarkMode
                  ? 'text-amber-400'
                  : 'text-blue-600'
                : 'hover:text-slate-300'
            }`}
          >
            <QrCode className="w-5 h-5 mb-0.5" />
            <span className="text-2xs font-semibold">{t('nav_my_codes')}</span>
          </button>

          {/* 5. Account */}
          <button
            onClick={() => handleNavClick('account')}
            className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
              activeTab === 'account'
                ? isDarkMode
                  ? 'text-amber-400'
                  : 'text-blue-600'
                : 'hover:text-slate-300'
            }`}
          >
            <User className="w-5 h-5 mb-0.5" />
            <span className="text-2xs font-semibold">{t('nav_account')}</span>
          </button>

        </div>
      </nav>
    </>
  );
};
