import React from 'react';
import { ArrowRight, Code, ShieldCheck, Zap, Download } from 'lucide-react';
import heroImage from '../assets/images/web_creation_hero_1792492756472.jpg';

interface HeroProps {
  onStartBuilder: () => void;
  onExplorePublish: () => void;
  lang: 'bn' | 'en';
}

export const Hero: React.FC<HeroProps> = ({ onStartBuilder, onExplorePublish, lang }) => {
  return (
    <section className="relative overflow-hidden bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Editorial Content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 tracking-wide">
              <span>১০০% ফ্রি হোস্টিং ও ওয়েবসাইট নির্দেশিকা</span>
              <span aria-hidden="true">·</span>
              <span>কোনো হিডেন ফি নেই</span>
              <span aria-hidden="true">·</span>
              <span>লাইফটাইম ফ্রি টিয়ার</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight leading-tight" style={{ textWrap: 'balance' }}>
              {lang === 'bn' ? (
                <>
                  <span className="text-indigo-600">সম্পূর্ণ ফ্রিতে</span> ওয়েবসাইট বানান এবং মাত্র <span className="underline decoration-indigo-300 underline-offset-4">৫ মিনিটে</span> লাইভ পাবলিশ করুন
                </>
              ) : (
                <>
                  Build a Website for <span className="text-indigo-600">100% Free</span> and Publish Live in <span className="underline decoration-indigo-300 underline-offset-4">5 Minutes</span>
                </>
              )}
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              {lang === 'bn'
                ? 'ডোমেইন ও হোস্টিংয়ের পেছনে এক টাকাও খরচ করতে হবে না! কোনো কোডিং না জেনেও গুগল সাইটস দিয়ে অথবা রেডিমেড কোড বানিয়ে Netlify ও GitHub Pages-এর মতো বিশ্বমানের সুরক্ষিত সার্ভারে আপনার ওয়েবসাইট আজীবনের জন্য লাইভ করুন।'
                : 'Zero dollars spent on domain & hosting! Whether using zero-code visual builders like Google Sites or instant cloud deployment like Netlify and GitHub Pages, launch your live website with free SSL today.'}
            </p>

            {/* CTA action buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onStartBuilder}
                className="px-6 py-3 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm flex items-center gap-2 cursor-pointer"
              >
                <span>{lang === 'bn' ? 'সরাসরি সাইট বানিয়ে কোড ডাউনলোড করুন' : 'Open Live Builder & Get Code'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExplorePublish}
                className="px-5 py-3 text-sm font-medium text-slate-700 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>{lang === 'bn' ? 'পাবলিশ করার ৩টি সহজ উপায় দেখুন' : 'View 3 Publishing Methods'}</span>
              </button>
            </div>

            {/* Quick Benefits Matrix */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-100">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{lang === 'bn' ? '০ টাকা খরচ' : '$0 Lifetime'}</span>
                </div>
                <p className="text-xs text-slate-500">
                  {lang === 'bn' ? 'কোনো কার্ড বা টাকা কাটার ভয় নেই' : 'No credit card required'}
                </p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900">
                  <Zap className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>{lang === 'bn' ? 'ফ্রি SSL প্যাডলক' : 'Free SSL HTTPS'}</span>
                </div>
                <p className="text-xs text-slate-500">
                  {lang === 'bn' ? 'অটোমেটিক সবুজ সিকিউর লক' : 'Fast, safe & encrypted'}
                </p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900">
                  <Download className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span>{lang === 'bn' ? '১০০% নিজের কন্ট্রোল' : '100% Control'}</span>
                </div>
                <p className="text-xs text-slate-500">
                  {lang === 'bn' ? 'কোড ডাউনলোড করে যেকোনো জায়গায় রাখুন' : 'Download code anytime'}
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Graphic */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-50 shadow-sm group">
              <img
                src={heroImage || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'}
                alt="Website Creation and Publishing Process Illustration"
                className="w-full h-auto object-cover transform transition-transform duration-500 group-hover:scale-102"
                referrerPolicy="no-referrer"
              />
              <div className="p-4 bg-white/95 border-t border-slate-200 text-xs text-slate-600 flex items-center justify-between">
                <span className="font-medium text-slate-800">
                  {lang === 'bn' ? 'ডিজাইন ➔ কোড ➔ ক্লাউড ডিপ্লয় ➔ ওয়ার্ল্ডওয়াইড লাইভ' : 'Design ➔ Code ➔ Cloud Deploy ➔ Live Worldwide'}
                </span>
                <span className="text-emerald-600 font-semibold flex items-center gap-1">
                  <span>●</span> {lang === 'bn' ? 'লাইভ লিঙ্ক রেডি' : 'Live Ready'}
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
