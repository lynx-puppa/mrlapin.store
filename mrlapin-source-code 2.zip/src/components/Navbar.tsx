import React from 'react';
import { Sparkles, Globe } from 'lucide-react';

interface NavbarProps {
  onNavigate: (sectionId: string) => void;
  lang: 'bn' | 'en';
  setLang: (l: 'bn' | 'en') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate, lang, setLang }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text wordmark */}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <span className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-black text-sm">
              W
            </span>
            <span>{lang === 'bn' ? 'ওয়েবশিল্পী' : 'WebShilpi'}</span>
          </a>

          {/* Zone 2: 4-5 single-line clean text nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => onNavigate('methods')}
              className="hover:text-indigo-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {lang === 'bn' ? 'পদ্ধতিসমূহ' : 'Methods'}
            </button>
            <button
              onClick={() => onNavigate('builder')}
              className="hover:text-indigo-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {lang === 'bn' ? 'ওয়েবসাইট মেকার' : 'Web Maker'}
            </button>
            <button
              onClick={() => onNavigate('publish')}
              className="hover:text-indigo-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {lang === 'bn' ? 'পাবলিশিং গাইড' : 'Publishing Guide'}
            </button>
            <button
              onClick={() => onNavigate('quiz')}
              className="hover:text-indigo-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {lang === 'bn' ? 'প্ল্যাটফর্ম কুইজ' : 'Platform Quiz'}
            </button>
            <button
              onClick={() => onNavigate('checklist')}
              className="hover:text-indigo-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {lang === 'bn' ? 'চেকলিস্ট ও এফএকিউ' : 'Checklist & FAQ'}
            </button>
          </nav>

          {/* Zone 3: 1 primary action + compact language toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}
              className="px-2.5 py-1 text-xs font-semibold rounded border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1"
              title="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>{lang === 'bn' ? 'English' : 'বাংলা'}</span>
            </button>

            <button
              onClick={() => onNavigate('builder')}
              className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-sm flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'সাইট বানান (০ টাকা)' : 'Build Site ($0)'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
