import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCategory, Product, HeroSlideItem } from '../types';
import { COMMUNITY_RECENT_ORDERS } from '../data/initialData';
import {
  Wrench,
  AlertCircle,
  Play,
  ShieldCheck,
  Zap,
  Headphones,
  CheckCircle,
  Phone,
  MessageCircle,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  ExternalLink
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const {
    products,
    setSelectedProduct,
    isDarkMode,
    settings,
    setActiveTab,
    recentOrders,
    language,
    t
  } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [bannerIndex, setBannerIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const slides: HeroSlideItem[] = settings.heroSlides && settings.heroSlides.length > 0
    ? settings.heroSlides
    : [
        {
          id: 'slide_1',
          badge: 'OFFICIAL VIP PANEL 2026',
          title: 'কীভাবে প্যানেল কিনবেন?',
          subtitle: 'নিরাপদ, দ্রুত ও বিশ্বস্ত সেবা · ইনস্ট্যান্ট অটোমেটেড ডেলিভারি ও ২৪/৭ ডেডিকেটেড সাপোর্ট',
          buttonText: 'টিউটোরিয়াল দেখুন',
          link: 'https://youtube.com',
          tags: ['100% FAST SERVICE', 'SECURE PAYMENT', '24/7 SUPPORT'],
          bgGradient: 'from-red-950 via-slate-900 to-indigo-950'
        }
      ];

  // Automatic slide rotation (every 4.5 seconds)
  useEffect(() => {
    if (isPaused || slides.length <= 1) return;
    const timer = setInterval(() => {
      setBannerIndex((prev) => (prev + 1) % slides.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [isPaused, slides.length]);

  // Ensure bannerIndex is valid if slides count changed
  useEffect(() => {
    if (bannerIndex >= slides.length) {
      setBannerIndex(0);
    }
  }, [slides.length, bannerIndex]);

  const currentSlide = slides[bannerIndex] || slides[0];

  const handleSlideAction = (slide: HeroSlideItem) => {
    if (!slide.link) return;
    const cleanLink = slide.link.trim();
    if (cleanLink === '#add_fund') {
      setActiveTab('add_fund');
    } else if (cleanLink === '#my_orders') {
      setActiveTab('my_orders');
    } else if (cleanLink === '#my_codes') {
      setActiveTab('my_codes');
    } else if (cleanLink === '#account') {
      setActiveTab('account');
    } else if (cleanLink.startsWith('http://') || cleanLink.startsWith('https://')) {
      window.open(cleanLink, '_blank', 'noopener,noreferrer');
    } else if (cleanLink.startsWith('t.me') || cleanLink.startsWith('wa.me')) {
      window.open(`https://${cleanLink}`, '_blank', 'noopener,noreferrer');
    } else {
      window.open(cleanLink, '_blank', 'noopener,noreferrer');
    }
  };

  const filteredProducts = products.filter((p) => {
    if (selectedCategory === 'all') return true;
    return p.category === selectedCategory;
  });

  return (
    <div className="space-y-6 sm:space-y-8 pb-36 w-full max-w-full overflow-hidden">
      
      {/* Hero Banner Carousel (Admin customizable 1-4 slides with automatic slide rotation) */}
      <div
        className="relative overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md group"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        <div
          className={`p-6 sm:p-8 rounded-2xl transition-all duration-500 relative overflow-hidden bg-gradient-to-r ${
            currentSlide.bgGradient || 'from-red-950 via-slate-900 to-indigo-950'
          } text-white`}
        >
          {/* Ambient Glow */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-72 h-72 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-3 text-center md:text-left flex-1 min-w-0">
              
              {/* Badge Tag */}
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-2xs font-extrabold uppercase bg-red-500/20 text-red-400 border border-red-500/30">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{currentSlide.badge || 'OFFICIAL VIP PANEL 2026'}</span>
              </div>
              
              {/* Title */}
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-tight line-clamp-2">
                {currentSlide.title}
              </h2>

              {/* Subtitle */}
              <p className="text-xs sm:text-sm text-slate-300 max-w-lg leading-relaxed line-clamp-3">
                {currentSlide.subtitle}
              </p>

              {/* 3 Trust Badges */}
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 pt-2 text-2xs font-bold text-slate-200">
                {(currentSlide.tags || ['100% FAST SERVICE', 'SECURE PAYMENT', '24/7 SUPPORT']).map((tag, tIdx) => (
                  <span key={tIdx} className="flex items-center gap-1.5 bg-black/40 px-3 py-1 rounded-lg border border-white/10">
                    {tIdx === 0 && <Zap className="w-3.5 h-3.5 text-amber-400" />}
                    {tIdx === 1 && <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />}
                    {tIdx >= 2 && <Headphones className="w-3.5 h-3.5 text-sky-400" />}
                    <span>{tag}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Logo / Video Play Affordance (Clicks to configured link) */}
            <div
              onClick={() => handleSlideAction(currentSlide)}
              className="relative group/btn shrink-0 cursor-pointer flex flex-col items-center"
              title={currentSlide.link ? `Go to: ${currentSlide.link}` : 'Open link'}
            >
              {currentSlide.logoOrImage && currentSlide.logoOrImage.trim() !== '' ? (
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 border-white/30 shadow-2xl group-hover/btn:scale-105 transition-transform bg-slate-900 flex items-center justify-center">
                  <img
                    src={currentSlide.logoOrImage}
                    alt={currentSlide.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).style.display = 'none';
                    }}
                  />
                </div>
              ) : (
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-tr from-red-600 to-red-500 flex items-center justify-center shadow-xl shadow-red-600/40 group-hover/btn:scale-105 transition-transform">
                  <Play className="w-10 h-10 text-white fill-white translate-x-0.5" />
                </div>
              )}

              {/* Action Button Label */}
              <span className="mt-2 px-3 py-1 rounded-full bg-white/10 hover:bg-white/20 text-2xs font-extrabold text-white border border-white/20 inline-flex items-center gap-1 shadow-sm transition">
                <span>{currentSlide.buttonText || 'টিউটোরিয়াল দেখুন'}</span>
                <ExternalLink className="w-3 h-3 text-red-400" />
              </span>
            </div>
          </div>
        </div>

        {/* Carousel Prev & Next Arrows (visible on hover) */}
        {slides.length > 1 && (
          <>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setBannerIndex((prev) => (prev - 1 + slides.length) % slides.length);
              }}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity z-20 cursor-pointer"
              title="Previous Slide"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setBannerIndex((prev) => (prev + 1) % slides.length);
              }}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity z-20 cursor-pointer"
              title="Next Slide"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </>
        )}

        {/* Carousel Dots (Supports 1 to 4 slides) */}
        {slides.length > 1 && (
          <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
            {slides.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setBannerIndex(idx)}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  bannerIndex === idx ? 'w-6 bg-red-500' : 'w-2 bg-white/40 hover:bg-white/70'
                }`}
                title={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Category Filter Pills (matching video 00:06) */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {(['all', 'non_root', 'root', 'iphone', 'pc'] as ProductCategory[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 ring-2 ring-blue-400'
                  : isDarkMode
                  ? 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 border border-slate-700/60'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat === 'all'
                ? (language === 'bn' ? 'সব প্যানেল (ALL)' : 'ALL')
                : cat === 'non_root'
                ? (language === 'bn' ? 'নন রুট' : 'NON ROOT')
                : cat === 'root'
                ? (language === 'bn' ? 'রুট' : 'ROOT')
                : cat === 'iphone'
                ? (language === 'bn' ? 'আইফোন' : 'IPHONE')
                : (language === 'bn' ? 'পিসি' : 'PC')}
            </button>
          ))}
        </div>

        {/* Category Heading & Items Count */}
        <div className="flex items-center justify-between text-xs font-bold px-1 text-slate-700 dark:text-slate-300">
          <span className="uppercase tracking-wider text-sm font-black">
            {selectedCategory === 'all'
              ? (language === 'bn' ? 'সকল প্যানেল তালিকা' : 'ALL PRODUCTS')
              : selectedCategory === 'non_root'
              ? (language === 'bn' ? 'নন রুট প্যানেল' : 'NON ROOT PANELS')
              : selectedCategory === 'root'
              ? (language === 'bn' ? 'রুট প্যানেল' : 'ROOT PANELS')
              : selectedCategory === 'iphone'
              ? (language === 'bn' ? 'আইফোন (iOS) প্যানেল' : 'IPHONE (iOS) PANELS')
              : (language === 'bn' ? 'পিসি (PC) প্যানেল' : 'PC PANELS')}
          </span>
          <span className="text-slate-400 font-mono text-2xs">
            {filteredProducts.length} items
          </span>
        </div>
      </div>

      {/* Product Grid (matching video 00:07 - 00:14) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {filteredProducts.map((product) => {
          const isOnline = product.status === 'online';
          const isMaintenance = product.status === 'maintenance';
          const isOutOfStock = product.status === 'out_of_stock';
          const isNotAvailable = product.status === 'not_available';

          return (
            <div
              key={product.id}
              className={`rounded-2xl border transition-all overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-lg ${
                isDarkMode
                  ? 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div>
                {/* Top Status Bar matching video */}
                <div
                  className={`px-3 py-1.5 flex items-center justify-center text-center text-2xs font-extrabold uppercase tracking-wider ${
                    isOnline
                      ? 'bg-emerald-600 text-white'
                      : isMaintenance
                      ? 'bg-red-700 text-white'
                      : isOutOfStock
                      ? 'bg-amber-600 text-white'
                      : 'bg-rose-900 text-white'
                  }`}
                >
                  {isOnline && (
                    <span className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                      ONLINE
                    </span>
                  )}
                  {isMaintenance && (
                    <span className="flex items-center gap-1.5">
                      <Wrench className="w-3 h-3" />
                      MAINTENANCE
                    </span>
                  )}
                  {isOutOfStock && (
                    <span className="flex items-center gap-1.5 animate-pulse">
                      <AlertCircle className="w-3 h-3" />
                      AUTOMATIC SHOT OUT
                    </span>
                  )}
                  {isNotAvailable && (
                    <span className="flex items-center gap-1.5">
                      <AlertCircle className="w-3 h-3" />
                      NOT AVAILABLE
                    </span>
                  )}
                </div>

                {/* Card Media Banner */}
                <div className="relative aspect-video sm:aspect-square overflow-hidden bg-slate-950 flex items-center justify-center">
                  <img
                    src={product.image && product.image.trim() !== '' ? product.image : 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'}
                    alt={product.name}
                    className={`w-full h-full object-cover transition-transform duration-500 hover:scale-105 ${
                      !isOnline ? 'grayscale-70 opacity-60' : ''
                    }`}
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80';
                    }}
                  />

                  {/* If Maintenance / Not Available overlay banner as in video */}
                  {!isOnline && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-2xs flex flex-col items-center justify-center p-4 text-center">
                      <div className="w-10 h-10 rounded-full bg-red-600/30 text-red-400 border border-red-500/40 flex items-center justify-center mb-2">
                        <Wrench className="w-5 h-5 animate-pulse" />
                      </div>
                      <span className="text-xs font-black text-white tracking-wider uppercase">
                        {product.customBadge || (isMaintenance ? 'UNDER MAINTENANCE' : isOutOfStock ? 'AUTOMATIC SHOT OUT' : 'THIS PRODUCT NOT AVAILABLE')}
                      </span>
                      <span className="text-2xs text-slate-300 mt-0.5">
                        {isOutOfStock ? 'ALL KEYS SOLD' : 'BACK SOON'}
                      </span>
                    </div>
                  )}
                </div>

                {/* Card Body */}
                <div className="p-4 space-y-3">
                  <h3 className="font-black text-sm text-slate-900 dark:text-white line-clamp-1">
                    {product.name}
                  </h3>

                  {/* Price Tag matching video */}
                  <div className="py-1 px-2.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-center font-mono text-xs font-bold text-slate-700 dark:text-slate-200">
                    PRICE · <span className="text-amber-500 font-black">৳{product.basePrice}</span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-4 pt-0">
                <button
                  onClick={() => setSelectedProduct(product)}
                  className={`w-full py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer shadow-sm ${
                    isOnline
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20 active:scale-98'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-400 border border-slate-700'
                  }`}
                >
                  {isOnline
                    ? (language === 'bn' ? 'অর্ডার করুন' : 'Order Now')
                    : (language === 'bn' ? 'অর্ডার বন্ধ আছে' : 'Purchase Disabled')}
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Latest Orders Live Feed (matching video 00:15 - 00:18) */}
      <div
        className={`rounded-2xl border p-5 sm:p-6 transition-all ${
          isDarkMode
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200 dark:border-slate-800">
          <h3 className="font-black text-base tracking-tight flex items-center gap-2">
            <span>{t('latest_orders')}</span>
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-3xs font-extrabold uppercase tracking-wider border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              {t('live_feed')}
            </span>
          </h3>
          <span className="text-2xs font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
            {recentOrders.length} {language === 'bn' ? 'টি অর্ডার' : 'orders'}
          </span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[460px] overflow-y-auto scrollbar-thin">
          {(recentOrders.length > 0 ? recentOrders : COMMUNITY_RECENT_ORDERS).map((ord, idx) => (
            <div key={ord.id || idx} className="py-3 flex items-center justify-between gap-3 hover:bg-slate-500/5 px-1 rounded-lg transition-colors">
              <div className="flex items-center gap-3 min-w-0">
                <div className={`w-8 h-8 rounded-full ${ord.avatarBg || 'bg-blue-600'} text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-sm`}>
                  {ord.user ? ord.user.charAt(0).toUpperCase() : 'U'}
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-xs text-slate-900 dark:text-white truncate flex items-center gap-1.5">
                    <span>{ord.user}</span>
                    <span className="text-3xs font-semibold px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {t('verified')}
                    </span>
                  </div>
                  <div className="text-2xs text-slate-400 truncate">
                    {ord.product}
                  </div>
                </div>
              </div>

              <div className="text-right shrink-0">
                <div className="font-mono font-bold text-xs text-amber-500">
                  {ord.price}
                </div>
                <span className="text-2xs font-bold text-emerald-500 flex items-center justify-end gap-1">
                  <CheckCircle className="w-3 h-3" />
                  {t('completed')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stay Connected & Footer Info (matching video 00:16 - 00:18) */}
      <div
        className={`rounded-2xl border p-6 text-center space-y-4 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-100/60 border-slate-200'
        }`}
      >
        <h4 className="font-black text-xs uppercase tracking-wider text-slate-400">
          {t('stay_connected')}
        </h4>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          {t('support_msg')}
        </p>

        {/* Support Phone Bar */}
        <div className="flex items-center justify-center gap-3 pt-2">
          <a
            href={`https://wa.me/${settings.supportWhatsapp}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition cursor-pointer"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{t('helpline_prefix')} [{settings.supportPhone}]</span>
          </a>
        </div>

        <div className="text-2xs text-slate-500 pt-3 border-t border-slate-200/40 dark:border-slate-800">
          © Copyright 2026 {settings.siteName} PANEL · {t('copyright')}
        </div>
      </div>

    </div>
  );
};
