import React, { useState } from 'react';
import { QUIZ_QUESTIONS, PLATFORMS_DATA } from '../data/guideData';
import { Sparkles, ArrowRight, RotateCcw, CheckCircle2 } from 'lucide-react';

interface PlatformQuizProps {
  lang: 'bn' | 'en';
  onSelectPlatform: (platformId: string) => void;
}

export const PlatformQuiz: React.FC<PlatformQuizProps> = ({ lang, onSelectPlatform }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [scores, setScores] = useState<Record<string, number>>({});
  const [isCompleted, setIsCompleted] = useState(false);

  const handleSelectOption = (points: Record<string, number | undefined>) => {
    const updated = { ...scores };
    Object.entries(points).forEach(([platform, pts]) => {
      if (pts) {
        updated[platform] = (updated[platform] || 0) + pts;
      }
    });
    setScores(updated);

    if (currentQuestion < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setIsCompleted(true);
    }
  };

  const handleReset = () => {
    setCurrentQuestion(0);
    setScores({});
    setIsCompleted(false);
  };

  // Determine top platform
  const getTopPlatform = () => {
    let topId = 'netlify-drop';
    let maxScore = -1;
    Object.entries(scores).forEach(([id, score]) => {
      if (score > maxScore) {
        maxScore = score;
        topId = id;
      }
    });
    return PLATFORMS_DATA.find((p) => p.id === topId) || PLATFORMS_DATA[0];
  };

  const topPlatform = getTopPlatform();

  return (
    <section id="quiz" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-10 space-y-2">
          <div className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">
            {lang === 'bn' ? 'স্মার্ট রিকমেন্ডার কুইজ' : 'Smart Platform Matcher'}
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            {lang === 'bn' ? 'আপনার জন্য কোন ফ্রি প্ল্যাটফর্মটি পারফেক্ট?' : 'Which Free Platform is Best for You?'}
          </h2>
          <p className="text-sm text-slate-600">
            {lang === 'bn'
              ? '৩টি সহজ প্রশ্নের উত্তর দিন, আমাদের টুল আপনার উপযোগী সেরা উপায়টি বের করে দেবে।'
              : 'Answer 3 quick questions to discover your optimal free website platform.'}
          </p>
        </div>

        {/* Quiz Body */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          {!isCompleted ? (
            <div className="space-y-6">
              
              {/* Progress Bar */}
              <div className="flex items-center justify-between text-xs font-medium text-slate-500">
                <span>
                  {lang === 'bn' ? `প্রশ্ন ${currentQuestion + 1} / ${QUIZ_QUESTIONS.length}` : `Question ${currentQuestion + 1} of ${QUIZ_QUESTIONS.length}`}
                </span>
                <span className="font-mono text-indigo-600 font-bold">
                  {Math.round(((currentQuestion) / QUIZ_QUESTIONS.length) * 100)}%
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-indigo-600 h-1.5 transition-all duration-300"
                  style={{ width: `${((currentQuestion) / QUIZ_QUESTIONS.length) * 100}%` }}
                />
              </div>

              {/* Question Text */}
              <h3 className="text-lg sm:text-xl font-bold text-slate-900 pt-2">
                {QUIZ_QUESTIONS[currentQuestion].question}
              </h3>

              {/* Options */}
              <div className="grid grid-cols-1 gap-3">
                {QUIZ_QUESTIONS[currentQuestion].options.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(opt.points)}
                    className="p-4 rounded-xl border border-slate-200 hover:border-indigo-500 hover:bg-indigo-50/40 transition-all text-left group cursor-pointer flex items-start justify-between gap-4"
                  >
                    <div>
                      <div className="font-bold text-sm text-slate-900 group-hover:text-indigo-900">
                        {opt.label}
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        {opt.description}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 shrink-0 mt-1" />
                  </button>
                ))}
              </div>

            </div>
          ) : (
            /* Results Screen */
            <div className="text-center space-y-6 animate-in zoom-in-95 duration-200">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <Sparkles className="w-7 h-7" />
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">
                  {lang === 'bn' ? 'ম্যাচ রেজাল্ট' : 'Best Match Found'}
                </span>
                <h3 className="text-2xl font-bold text-slate-900">
                  {lang === 'bn' ? 'আপনার জন্য সেরা পরামর্শ:' : 'Your Recommended Platform:'}{' '}
                  <span className="text-indigo-600">{topPlatform.name}</span>
                </h3>
                <p className="text-sm text-slate-600 max-w-lg mx-auto">
                  {topPlatform.bestFor}
                </p>
              </div>

              {/* Highlight Box */}
              <div className="p-5 bg-slate-50 border border-slate-200 rounded-xl max-w-lg mx-auto text-left space-y-3">
                <div className="text-xs font-bold text-slate-800">
                  {lang === 'bn' ? 'কেন এটি আপনার জন্য পারফেক্ট?' : 'Why it matches your profile:'}
                </div>
                <div className="space-y-1.5">
                  {topPlatform.freeTierFeatures.slice(0, 3).map((f, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
                <div className="pt-2 border-t border-slate-200 text-xs text-slate-500 font-mono">
                  ফ্রি URL: https://{topPlatform.freeUrlFormat}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => onSelectPlatform(topPlatform.id)}
                  className="px-6 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition cursor-pointer flex items-center gap-1.5"
                >
                  <span>{lang === 'bn' ? 'ধাপসমূহ দেখে এখনই শুরু করুন' : 'View Step-by-Step Guide'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={handleReset}
                  className="px-4 py-2.5 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg transition cursor-pointer flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'আবার শুরু করুন' : 'Retake Quiz'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </section>
  );
};
