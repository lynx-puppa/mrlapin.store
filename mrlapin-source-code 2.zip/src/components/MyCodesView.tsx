import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Copy, Check, QrCode, Gift, CheckCircle2 } from 'lucide-react';

export const MyCodesView: React.FC = () => {
  const { codes, isDarkMode } = useStore();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showRedeemInput, setShowRedeemInput] = useState(false);
  const [redeemInput, setRedeemInput] = useState('');
  const [redeemMessage, setRedeemMessage] = useState<string | null>(null);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!redeemInput.trim()) return;
    setRedeemMessage('Code redeemed successfully! License activated.');
    setTimeout(() => {
      setRedeemMessage(null);
      setShowRedeemInput(false);
      setRedeemInput('');
    }, 2000);
  };

  return (
    <div className="space-y-6 pb-36 max-w-4xl mx-auto w-full max-w-full overflow-hidden">
      
      {/* Header Bar matching video 01:01 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <QrCode className="w-6 h-6 text-blue-500" />
            <span>My Codes</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            View, copy, and activate your purchased VIP keys and vouchers.
          </p>
        </div>

        {/* Redeem Code Button */}
        <button
          onClick={() => setShowRedeemInput(!showRedeemInput)}
          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm shadow-blue-500/20 transition cursor-pointer"
        >
          <Gift className="w-3.5 h-3.5" />
          <span>Redeem Code</span>
        </button>
      </div>

      {/* Redeem Input Box */}
      {showRedeemInput && (
        <form onSubmit={handleRedeem} className="p-4 rounded-xl border border-blue-500/30 bg-blue-500/5 space-y-3 animate-in fade-in duration-200">
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
            Enter Gift Card or License Code:
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={redeemInput}
              onChange={(e) => setRedeemInput(e.target.value)}
              placeholder="e.g. AMHK-XXXX-XXXX-XXXX"
              className="flex-1 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono uppercase text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg cursor-pointer"
            >
              Apply
            </button>
          </div>
          {redeemMessage && (
            <div className="text-2xs font-bold text-emerald-500 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{redeemMessage}</span>
            </div>
          )}
        </form>
      )}

      {/* Codes List (matching video 01:02 - 01:06) */}
      {codes.length === 0 ? (
        <div
          className={`p-12 text-center rounded-2xl border ${
            isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-white border-slate-200 text-slate-500'
          }`}
        >
          <QrCode className="w-12 h-12 mx-auto mb-2 text-slate-600" />
          <p className="text-sm font-bold">No Codes Found</p>
          <p className="text-xs text-slate-400 mt-1">
            When you purchase a panel or game key, your activation code will be listed here.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {codes.map((item) => {
            const isCopied = copiedId === item.id;

            return (
              <div
                key={item.id}
                className={`p-5 rounded-2xl border shadow-2xs space-y-3 transition-all ${
                  isDarkMode
                    ? 'bg-slate-900 border-slate-800 text-white'
                    : 'bg-white border-slate-200 text-slate-900'
                }`}
              >
                {/* Top Row: Serial & Status */}
                <div className="flex items-center justify-between text-xs font-bold">
                  <span>Serial NO: {item.serialNo}</span>
                  <span className="text-2xs font-extrabold uppercase px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    Status: {item.status}
                  </span>
                </div>

                {/* Date */}
                <div className="text-2xs font-mono text-slate-400">
                  Date: {item.date}
                </div>

                {/* Package & Price */}
                <div className="text-xs flex items-center justify-between">
                  <div>
                    <span className="text-slate-400">Package: </span>
                    <strong className="text-slate-900 dark:text-white">{item.packageTitle}</strong>
                  </div>
                  <div className="font-mono font-bold text-amber-500">
                    Price: ৳{item.price}
                  </div>
                </div>

                {/* Your Code Monospace Display Box matching video */}
                <div className="pt-1">
                  <span className="text-2xs font-bold text-slate-400 block mb-1">
                    Your Code:
                  </span>
                  <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 font-mono text-xs sm:text-sm font-black text-indigo-600 dark:text-indigo-300 break-all select-all">
                    {item.code}
                  </div>
                </div>

                {/* Copy Code Button matching video */}
                <button
                  onClick={() => handleCopy(item.id, item.code)}
                  className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
                    isCopied
                      ? 'bg-emerald-600 text-white'
                      : isDarkMode
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200'
                  }`}
                >
                  {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? 'কপি সম্পন্ন!' : 'Copy Code'}</span>
                </button>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
