import React, { useState, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductStatus, Product, PackageTier, PaymentGatewayConfig, OrderRecord, HeroSlideItem } from '../types';
import {
  Shield,
  CreditCard,
  Package,
  Send,
  UserCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Plus,
  Trash2,
  Edit,
  Save,
  RotateCcw,
  DollarSign,
  Phone,
  Megaphone,
  Wrench,
  Ban,
  Search,
  Copy,
  Check,
  Filter,
  Wallet,
  ArrowUpRight,
  Key,
  Clock,
  Image as ImageIcon,
  Layers,
  Sparkles,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Eye,
  RefreshCw,
  Upload,
  Mail,
  User,
  Video,
  Play,
  MessageCircle,
  Link as LinkIcon
} from 'lucide-react';

const LOGO_PRESETS = [
  { name: '🐰 MR LAPIN Mascot', url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80' },
  { name: '💀 Red Skull VIP', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=600&q=80' },
  { name: '⚡ Cyber Hacker Neon', url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80' },
  { name: '🎯 Pro Aim Crosshair', url: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=600&q=80' },
  { name: '🐉 Red Dragon FF', url: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=600&q=80' },
  { name: '🛡️ Phantom Safe Shield', url: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?auto=format&fit=crop&w=600&q=80' }
];

export const AdminPanelView: React.FC = () => {
  const {
    settings,
    updateSettings,
    updateHeroSlides,
    gateways,
    updateGatewayNumber,
    updateGatewayDetails,
    products,
    updateProductStatus,
    updateProductDetails,
    editProductPackage,
    addPackageToProduct,
    deletePackageFromProduct,
    addKeysToPackageTier,
    removeKeyFromPackageTier,
    clearPackageKeys,
    addNewProduct,
    deleteProduct,
    deposits,
    orders,
    approveDeposit,
    rejectDeposit,
    manualAddBalance,
    recentOrders,
    deleteRecentOrder,
    clearRecentOrders,
    triggerSimulatedOrder,
    user,
    isDarkMode,
    resetToDefaults
  } = useStore();

  const [activeAdminTab, setActiveAdminTab] = useState<'products' | 'sold_keys' | 'gateways' | 'approve_payments' | 'telegram' | 'banners' | 'publish'>('products');
  
  // Feedback toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Gallery File Upload Input Refs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const newProdFileInputRef = useRef<HTMLInputElement>(null);

  // Sold Keys Tab Search State
  const [soldKeySearch, setSoldKeySearch] = useState('');
  const [copiedKeyText, setCopiedKeyText] = useState<string | null>(null);

  // Approve Payments Search & Filter States
  const [depositFilter, setDepositFilter] = useState<'all' | 'completed' | 'pending' | 'rejected'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [gatewayFilter, setGatewayFilter] = useState('all');
  const [adjustingDepositId, setAdjustingDepositId] = useState<string | null>(null);
  const [adjustedAmount, setAdjustedAmount] = useState<string>('');
  const [rejectingDepositId, setRejectingDepositId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState<string>('TrxID not found or payment not received');
  const [copiedTrxId, setCopiedTrxId] = useState<string | null>(null);

  // Manual Balance State
  const [manualAmount, setManualAmount] = useState<string>('100');
  const [manualNote, setManualNote] = useState<string>('Admin Direct Recharge');

  // Telegram Settings State
  const [tgTitle, setTgTitle] = useState(settings.telegramPopupTitle);
  const [tgDesc, setTgDesc] = useState(settings.telegramPopupDesc);
  const [tgGroupLink, setTgGroupLink] = useState(settings.telegramLink);
  const [tgDmLink, setTgDmLink] = useState(settings.telegramDmLink);
  const [tgEnabled, setTgEnabled] = useState(settings.telegramPopupEnabled);
  const [siteName, setSiteName] = useState(settings.siteName);
  const [marqueeText, setMarqueeText] = useState(settings.noticeMarquee);
  const [whatsappPhone, setWhatsappPhone] = useState(settings.supportWhatsapp || '8801813913894');
  const [supportPhoneText, setSupportPhoneText] = useState(settings.supportPhone || '+8801813913894');

  const handleSupportPhoneChange = (val: string) => {
    setSupportPhoneText(val);
    const digitsOnly = val.replace(/[^0-9]/g, '');
    if (digitsOnly.length >= 10) {
      if (digitsOnly.startsWith('01')) {
        setWhatsappPhone(`88${digitsOnly}`);
      } else if (digitsOnly.startsWith('8801')) {
        setWhatsappPhone(digitsOnly);
      }
    }
  };

  const handleSaveHelplineNumber = () => {
    const cleanDigits = whatsappPhone.trim().replace(/[^0-9]/g, '') || '8801813913894';
    const cleanDisplay = supportPhoneText.trim() || '+8801813913894';
    updateSettings({
      supportPhone: cleanDisplay,
      supportWhatsapp: cleanDigits
    });
    showToast(`হেল্পলাইন নম্বর সফলভাবে সেভ হয়েছে! [${cleanDisplay}]`);
  };

  // Banner Carousel & Notice State (1 to 4 items)
  const [slidesList, setSlidesList] = useState<HeroSlideItem[]>(() => settings.heroSlides || []);
  const [activeSlideEditIndex, setActiveSlideEditIndex] = useState<number>(0);
  const slideFileInputRef = useRef<HTMLInputElement>(null);

  const handleAddSlide = () => {
    if (slidesList.length >= 4) {
      showToast('সর্বোচ্চ ৪টি স্লাইড যোগ করা যাবে!');
      return;
    }
    const newSlide: HeroSlideItem = {
      id: `slide_${Date.now()}`,
      badge: 'OFFICIAL VIP PANEL 2026',
      title: 'নতুন ভিআইপি প্যানেল অফার',
      subtitle: 'নিরাপদ, দ্রুত ও বিশ্বস্ত সেবা · ইনস্ট্যান্ট অটোমেটেড ডেলিভারি ও ২৪/৭ ডেডিকেটেড সাপোর্ট',
      buttonText: 'টিউটোরিয়াল দেখুন',
      link: 'https://youtube.com',
      logoOrImage: '',
      tags: ['100% FAST SERVICE', 'SECURE PAYMENT', '24/7 SUPPORT'],
      bgGradient: 'from-red-950 via-slate-900 to-indigo-950'
    };
    const updated = [...slidesList, newSlide];
    setSlidesList(updated);
    setActiveSlideEditIndex(updated.length - 1);
    updateHeroSlides(updated);
    showToast('নতুন স্লাইড যোগ করা হয়েছে! এবার টাইটেল ও লিংক এডিট করে সেভ করুন।');
  };

  const handleRemoveSlide = (slideIndex: number) => {
    if (slidesList.length <= 1) {
      showToast('কমপক্ষে ১টি স্লাইড থাকতে হবে!');
      return;
    }
    const updated = slidesList.filter((_, idx) => idx !== slideIndex);
    setSlidesList(updated);
    setActiveSlideEditIndex(0);
    updateHeroSlides(updated);
    showToast('স্লাইড মুছে ফেলা হয়েছে!');
  };

  const handleUpdateSlideField = (index: number, field: keyof HeroSlideItem, value: any) => {
    const updated = [...slidesList];
    updated[index] = { ...updated[index], [field]: value };
    setSlidesList(updated);
  };

  const handleSlideGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>, slideIndex: number) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('অনুগ্রহ করে ছবি ফাইল (JPG, PNG, WEBP) নির্বাচন করুন!');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        handleUpdateSlideField(slideIndex, 'logoOrImage', dataUrl);
        showToast(`স্লাইড ${slideIndex + 1}-এর লোগো/ছবি গ্যালারি থেকে আপডেট হয়েছে!`);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveBannerAndNotice = () => {
    updateSettings({ noticeMarquee: marqueeText });
    updateHeroSlides(slidesList);
    showToast('উপরে নোটিশ বার ও হোম স্লাইডার সফলভাবে সেভ হয়েছে!');
  };

  // Products Tab Management State
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<'non_root' | 'root' | 'iphone' | 'pc'>('non_root');
  const [newProdPrice, setNewProdPrice] = useState('20');
  const [newProdImage, setNewProdImage] = useState(LOGO_PRESETS[0].url);
  const [newProdStatus, setNewProdStatus] = useState<ProductStatus>('online');
  const [newProdVideoLink, setNewProdVideoLink] = useState('https://youtube.com');
  const [newProdAppLink, setNewProdAppLink] = useState('https://t.me/mrlapin_official');

  // Duration Tier Add Form State
  const [showAddTierModal, setShowAddTierModal] = useState(false);
  const [newTierDuration, setNewTierDuration] = useState('2 Hours');
  const [newTierName, setNewTierName] = useState('');
  const [newTierPrice, setNewTierPrice] = useState('35');
  const [newTierInitialKeys, setNewTierInitialKeys] = useState('');

  // Key Pool text inputs mapped by package ID
  const [tierKeysInput, setTierKeysInput] = useState<Record<string, string>>({});
  const [viewingKeysTierId, setViewingKeysTierId] = useState<string | null>(null);

  // Gateway edit state
  const [editingGateways, setEditingGateways] = useState<Record<string, {
    numberOrAddress: string;
    subType: string;
    minAmount: number;
    maxAmount: number;
    instructions: string;
    isActive: boolean;
  }>>(() => {
    const map: Record<string, any> = {};
    gateways.forEach((g) => {
      map[g.id] = {
        numberOrAddress: g.numberOrAddress,
        subType: g.subType,
        minAmount: g.minAmount,
        maxAmount: g.maxAmount,
        instructions: g.instructions,
        isActive: g.isActive
      };
    });
    return map;
  });

  const activeProduct = products.find((p) => p.id === selectedProductId) || products[0];

  // Mobile Gallery Image Upload Handler
  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>, isNewProduct = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('অনুগ্রহ করে ছবি ফাইল (JPG, PNG, WEBP) নির্বাচন করুন!');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        if (isNewProduct) {
          setNewProdImage(dataUrl);
          showToast('মোবাইল গ্যালারি থেকে নতুন ছবি সিলেক্ট হয়েছে!');
        } else if (activeProduct) {
          updateProductDetails(activeProduct.id, { image: dataUrl });
          showToast(`${activeProduct.name}-এর ছবি গ্যালারি থেকে আপডেট হয়েছে!`);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveGateway = (gatewayId: string) => {
    const data = editingGateways[gatewayId];
    if (data) {
      updateGatewayDetails(gatewayId, data);
      showToast(`${gatewayId.toUpperCase()} পেমেন্ট তথ্য সফলভাবে আপডেট হয়েছে!`);
    }
  };

  const handleSaveTelegramAndSite = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      siteName,
      telegramPopupTitle: tgTitle,
      telegramPopupDesc: tgDesc,
      telegramLink: tgGroupLink,
      telegramDmLink: tgDmLink,
      telegramPopupEnabled: tgEnabled,
      noticeMarquee: marqueeText,
      supportWhatsapp: whatsappPhone.trim().replace(/[^0-9]/g, ''),
      supportPhone: supportPhoneText.trim()
    });
    showToast('টেলিগ্রাম, হেল্পলাইন ও সাইট সেটিংস সেভ করা হয়েছে!');
  };

  const handleManualAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(manualAmount);
    if (!amt || amt <= 0) {
      showToast('সঠিক টাকার পরিমাণ দিন!');
      return;
    }
    manualAddBalance(user.id, amt, manualNote);
    showToast(`সফল হয়েছে! ${user.name}-এর একাউন্টে ৳ ${amt} যুক্ত করা হয়েছে।`);
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) return;

    const priceNum = parseFloat(newProdPrice) || 20;
    const newId = `prod_${Date.now()}`;
    const newP: Product = {
      id: newId,
      name: newProdName.trim(),
      category: newProdCategory,
      basePrice: priceNum,
      image: newProdImage.trim() || LOGO_PRESETS[0].url,
      status: newProdStatus,
      description: 'MR LAPIN VIP menu with safe anti-ban bypass and instant key delivery.',
      appLink: newProdAppLink.trim() || 'https://t.me/mrlapin_official',
      videoLink: newProdVideoLink.trim() || 'https://youtube.com',
      packages: [
        {
          id: `pk_${Date.now()}_1`,
          name: `${newProdName.trim()} - 1 HOUR`,
          duration: '1 Hour',
          price: priceNum,
          status: 'online',
          keysPool: [`${newProdName.slice(0, 4).toUpperCase()}-1H-1029-ABC`, `${newProdName.slice(0, 4).toUpperCase()}-1H-9921-XYZ`]
        },
        {
          id: `pk_${Date.now()}_2`,
          name: `${newProdName.trim()} - 24 HOURS`,
          duration: '24 Hours',
          price: priceNum * 4,
          status: 'online',
          keysPool: [`${newProdName.slice(0, 4).toUpperCase()}-24H-5501-KLM`]
        }
      ]
    };

    addNewProduct(newP);
    setSelectedProductId(newId);
    setShowAddProduct(false);
    setNewProdName('');
    showToast('নতুন প্রোডাক্ট সফলভাবে যুক্ত হয়েছে!');
  };

  const handleAddTierToProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeProduct) return;

    const priceNum = parseFloat(newTierPrice) || 20;
    const durationLabel = newTierDuration.trim() || '1 Hour';
    const tierName = newTierName.trim() || `${activeProduct.name} - ${durationLabel.toUpperCase()}`;
    
    // Parse initial keys from textarea
    const keysArray = newTierInitialKeys
      .split('\n')
      .map((k) => k.trim())
      .filter((k) => k.length > 0);

    const newPkg: PackageTier = {
      id: `pkg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: tierName,
      duration: durationLabel,
      price: priceNum,
      status: keysArray.length > 0 ? 'online' : 'online',
      keysPool: keysArray
    };

    addPackageToProduct(activeProduct.id, newPkg);
    setShowAddTierModal(false);
    setNewTierName('');
    setNewTierInitialKeys('');
    showToast(`${durationLabel} প্যাকেজ সফলভাবে যোগ করা হয়েছে!`);
  };

  const handleAddKeysToTier = (productId: string, tierId: string) => {
    const rawText = tierKeysInput[tierId] || '';
    const keys = rawText
      .split('\n')
      .map((k) => k.trim())
      .filter((k) => k.length > 0);

    if (keys.length === 0) {
      showToast('কোনো Key লেখা হয়নি! প্রতি লাইনে ১টি Key লিখুন।');
      return;
    }

    addKeysToPackageTier(productId, tierId, keys);
    setTierKeysInput({ ...tierKeysInput, [tierId]: '' });
    showToast(`সফল হয়েছে! ${keys.length}টি Key স্টকে যুক্ত হয়েছে।`);
  };

  const handleGenerateTestKeys = (productId: string, tierId: string, durationLabel: string) => {
    const prefix = activeProduct?.name.substring(0, 4).replace(/[^A-Z]/gi, '').toUpperCase() || 'LAPIN';
    const tag = durationLabel.replace(/\s+/g, '').toUpperCase();
    const testKeys = Array.from({ length: 5 }, () => {
      const p1 = Math.random().toString(36).substring(2, 6).toUpperCase();
      const p2 = Math.random().toString(36).substring(2, 6).toUpperCase();
      return `${prefix}-${tag}-${p1}-${p2}`;
    });

    addKeysToPackageTier(productId, tierId, testKeys);
    showToast(`৫টি টেস্ট Key (${tag}) স্টকে যুক্ত হয়েছে!`);
  };

  return (
    <div className="space-y-6 pb-24 max-w-5xl mx-auto w-full max-w-full overflow-hidden">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-emerald-600 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 animate-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Admin Panel Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-red-950 text-white border border-red-500/30 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-2xs font-extrabold uppercase bg-red-600 text-white shadow-xs">
            <Shield className="w-3.5 h-3.5" />
            <span>MR LAPIN MASTER ADMIN PANEL</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight mt-2">
            অ্যাডমিন কন্ট্রোল রুম
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            মোবাইল গ্যালারি থেকে ছবি আপলোড, প্যাকেজের সময় ও কি স্টক, বিক্রি হওয়া Key ও গ্রাহকের Gmail হিস্টোরি।
          </p>
        </div>

        <button
          onClick={() => {
            if (confirm('Are you sure you want to reset all demo data to default?')) {
              resetToDefaults();
              showToast('Reset to default values.');
            }
          }}
          className="px-3.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700 text-2xs font-bold flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>রিসেট ডাটা</span>
        </button>
      </div>

      {/* Admin Nav Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        
        {/* TAB 1: PRODUCT & DURATION & KEY CONTROLLER */}
        <button
          onClick={() => setActiveAdminTab('products')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer ${
            activeAdminTab === 'products'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : isDarkMode
              ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>প্রোডাক্ট, ছবি ও সময়/Key কন্ট্রোল</span>
        </button>

        {/* TAB 2: SOLD KEYS & BUYER GMAIL LOG (NEW!) */}
        <button
          onClick={() => setActiveAdminTab('sold_keys')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer ${
            activeAdminTab === 'sold_keys'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : isDarkMode
              ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>বিক্রি হওয়া Key ও ক্রেতার Gmail</span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-2xs">
            {orders.length} Sold
          </span>
        </button>

        {/* TAB 3: PAYMENT GATEWAY NUMBERS */}
        <button
          onClick={() => setActiveAdminTab('gateways')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer ${
            activeAdminTab === 'gateways'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : isDarkMode
              ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>পেমেন্ট নম্বর পরিবর্তন (bKash/Nagad/Rocket)</span>
        </button>

        {/* TAB 4: APPROVE PAYMENTS */}
        <button
          onClick={() => setActiveAdminTab('approve_payments')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer ${
            activeAdminTab === 'approve_payments'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : isDarkMode
              ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>পেমেন্ট ও ডিপোজিট হিস্টোরি</span>
          <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 font-mono text-2xs">
            {deposits.length} Records
          </span>
        </button>

        {/* TAB 5: TELEGRAM & NOTICE */}
        <button
          onClick={() => setActiveAdminTab('telegram')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer ${
            activeAdminTab === 'telegram'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : isDarkMode
              ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Send className="w-4 h-4" />
          <span>টেলিগ্রাম পপআপ</span>
        </button>

        {/* TAB 6: BANNER SLIDER & NOTICE (NEW!) */}
        <button
          onClick={() => setActiveAdminTab('banners')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer ${
            activeAdminTab === 'banners'
              ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md shadow-red-600/30'
              : isDarkMode
              ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>ব্যানার স্লাইডার (১-৪) ও নোটিশ</span>
          <span className="px-2 py-0.5 rounded-full bg-red-500 text-white font-mono text-2xs">
            {slidesList.length}/4
          </span>
        </button>

        {/* TAB 7: PUBLISH TO NETLIFY / GITHUB (NEW!) */}
        <button
          onClick={() => setActiveAdminTab('publish')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer ${
            activeAdminTab === 'publish'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-600/30 ring-2 ring-emerald-400'
              : isDarkMode
              ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Upload className="w-4 h-4 text-emerald-400" />
          <span>Netlify / GitHub পাবলিশ ফাইল</span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-2xs animate-pulse">
            FREE ZIP
          </span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: PRODUCT, GALLERY LOGO, DURATION HOURS & LICENSE KEY MANAGEMENT     */}
      {/* ========================================================================= */}
      {activeAdminTab === 'products' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Top Actions: Product Selector + New Product Button */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
            <div className="flex-1 min-w-0">
              <label className="block text-2xs font-extrabold uppercase text-slate-400 mb-1">
                যে প্রোডাক্টটি এডিট করবেন তা নির্বাচন করুন:
              </label>
              <div className="flex items-center gap-2 flex-wrap">
                <select
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-black text-slate-900 dark:text-white max-w-xs focus:outline-none focus:border-blue-500"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.packages.length} Tiers) - {p.status.toUpperCase()}
                    </option>
                  ))}
                </select>

                <span className="text-2xs text-slate-400">
                  মোট {products.length}টি প্রোডাক্ট রয়েছে
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowAddProduct(!showAddProduct)}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন প্রোডাক্ট তৈরি করুন</span>
            </button>
          </div>

          {/* Add Product Modal Form */}
          {showAddProduct && (
            <form onSubmit={handleCreateProduct} className="p-5 rounded-2xl border border-blue-500/30 bg-blue-500/5 space-y-4 animate-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between border-b border-blue-500/20 pb-3">
                <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>নতুন প্যানেল / প্রোডাক্ট তৈরি করুন</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setShowAddProduct(false)}
                  className="text-slate-400 hover:text-slate-200 text-xs cursor-pointer"
                >
                  বাতিল
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    প্রোডাক্টের নাম:
                  </label>
                  <input
                    type="text"
                    value={newProdName}
                    onChange={(e) => setNewProdName(e.target.value)}
                    placeholder="e.g. VIP HEADSHOT REGEDIT"
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    ক্যাটাগরি:
                  </label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="non_root">Non Root (নন রুট)</option>
                    <option value="root">Root (রুট)</option>
                    <option value="iphone">iPhone (আইফোন / আইওএস)</option>
                    <option value="pc">PC (কম্পিউটার)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    প্রাথমিক মূল্য (৳):
                  </label>
                  <input
                    type="number"
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    প্রাথমিক স্ট্যাটাস:
                  </label>
                  <select
                    value={newProdStatus}
                    onChange={(e) => setNewProdStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="online">Online (চালু)</option>
                    <option value="maintenance">Under Maintenance</option>
                    <option value="out_of_stock">Out of Stock</option>
                    <option value="not_available">This Product Not Available</option>
                  </select>
                </div>

                {/* Mobile Gallery Upload in New Product Form */}
                <div className="sm:col-span-2 p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block text-2xs font-bold text-slate-400">
                      প্রোডাক্টের ছবি (মোবাইল গ্যালারি অথবা ছবির লিংক):
                    </label>
                    
                    <input
                      type="file"
                      ref={newProdFileInputRef}
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleGalleryUpload(e, true)}
                    />
                    <button
                      type="button"
                      onClick={() => newProdFileInputRef.current?.click()}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-2xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>📱 মোবাইল গ্যালারি থেকে ছবি আপলোড</span>
                    </button>
                  </div>

                  <input
                    type="text"
                    value={newProdImage}
                    onChange={(e) => setNewProdImage(e.target.value)}
                    placeholder="অথবা ছবির URL দিন: https://..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    🎥 সেটআপ ভিডিও লিংক (YouTube URL):
                  </label>
                  <input
                    type="text"
                    value={newProdVideoLink}
                    onChange={(e) => setNewProdVideoLink(e.target.value)}
                    placeholder="https://youtube.com/watch?v=..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    📱 অ্যাপ ডাউনলোড লিংক (Telegram / App Link):
                  </label>
                  <input
                    type="text"
                    value={newProdAppLink}
                    onChange={(e) => setNewProdAppLink(e.target.value)}
                    placeholder="https://t.me/mrlapin_official"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddProduct(false)}
                  className="px-3.5 py-1.5 rounded-lg text-slate-400 hover:text-slate-200 text-xs font-bold cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                >
                  প্রোডাক্ট তৈরি করুন
                </button>
              </div>
            </form>
          )}

          {/* ACTIVE PRODUCT EDITOR */}
          {activeProduct && (
            <div className={`p-6 rounded-2xl border space-y-6 shadow-sm ${
              isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}>
              
              {/* Product Identity & Logo Editor */}
              <div className="space-y-4 border-b border-slate-200 dark:border-slate-800 pb-6">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <span className="text-2xs font-extrabold text-blue-500 uppercase tracking-wider">
                      ১. প্রোডাক্ট ছবি/লোগো (মোবাইল গ্যালারি বা URL) ও মূল তথ্য পরিবর্তন
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                      {activeProduct.name}
                    </h3>
                  </div>

                  <button
                    onClick={() => {
                      if (confirm(`Are you sure you want to delete ${activeProduct.name}?`)) {
                        deleteProduct(activeProduct.id);
                        showToast(`${activeProduct.name} মুছে ফেলা হয়েছে!`);
                      }
                    }}
                    className="px-3 py-1.5 rounded-lg bg-red-600/10 hover:bg-red-600/20 text-red-400 border border-red-500/30 text-2xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>প্রোডাক্ট ডিলিট করুন</span>
                  </button>
                </div>

                {/* Logo Editor with Mobile Gallery Upload Button + Live Preview */}
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    {/* Live Image Box */}
                    <div className="relative group shrink-0">
                      <img
                        src={activeProduct.image && activeProduct.image.trim() !== '' ? activeProduct.image : 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'}
                        alt={activeProduct.name}
                        className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-indigo-500/40 shadow-md"
                        onError={(e) => {
                          (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80';
                        }}
                      />
                      <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/80 text-white font-bold text-3xs font-mono">
                        Preview
                      </span>
                    </div>

                    {/* Gallery Upload + Logo URL Input & Presets */}
                    <div className="flex-1 min-w-0 space-y-2.5 w-full">
                      
                      {/* Mobile Gallery Upload Button (Primary feature user requested) */}
                      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                        <input
                          type="file"
                          ref={fileInputRef}
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handleGalleryUpload(e, false)}
                        />
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md transition"
                        >
                          <Upload className="w-4 h-4" />
                          <span>📱 মোবাইল গ্যালারি / ফাইল থেকে ছবি দিন</span>
                        </button>
                        
                        <span className="text-2xs text-slate-400 text-center sm:text-left">
                          ফোন বা পিসির গ্যালারি থেকে যেকোনো ছবি সিলেক্ট করলেই সাথে সাথে সেভ হবে
                        </span>
                      </div>

                      {/* Direct URL Input fallback */}
                      <div>
                        <label className="block text-2xs font-bold text-slate-400 mb-1 flex items-center gap-1">
                          <ImageIcon className="w-3.5 h-3.5 text-blue-400" />
                          <span>অথবা ছবির URL পেস্ট করুন:</span>
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={activeProduct.image}
                            onChange={(e) => updateProductDetails(activeProduct.id, { image: e.target.value })}
                            placeholder="https://..."
                            className="flex-1 px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                          />
                          <button
                            type="button"
                            onClick={() => showToast('লোগো URL সেভ হয়েছে!')}
                            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer shrink-0"
                          >
                            <Save className="w-3.5 h-3.5" />
                            <span>সেভ</span>
                          </button>
                        </div>
                      </div>

                      {/* 1-Click Preset Logos */}
                      <div>
                        <span className="block text-3xs font-extrabold uppercase text-slate-400 mb-1">
                          দ্রুত রেডিমেড লোগো নির্বাচন (১-ক্লিক):
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {LOGO_PRESETS.map((preset, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => {
                                updateProductDetails(activeProduct.id, { image: preset.url });
                                showToast(`লোগো পরিবর্তন করা হয়েছে: ${preset.name}`);
                              }}
                              className={`px-2.5 py-1 rounded-lg text-2xs font-bold border transition cursor-pointer flex items-center gap-1 ${
                                activeProduct.image === preset.url
                                  ? 'bg-blue-600 text-white border-blue-500'
                                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:border-blue-400'
                              }`}
                            >
                              <span>{preset.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Product Name, Category & Price Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-2xs font-bold text-slate-400 mb-1">
                      প্রোডাক্টের নাম (Title):
                    </label>
                    <input
                      type="text"
                      value={activeProduct.name}
                      onChange={(e) => updateProductDetails(activeProduct.id, { name: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-2xs font-bold text-slate-400 mb-1">
                      ক্যাটাগরি:
                    </label>
                    <select
                      value={activeProduct.category}
                      onChange={(e) => updateProductDetails(activeProduct.id, { category: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                    >
                      <option value="non_root">Non Root</option>
                      <option value="root">Root</option>
                      <option value="iphone">iPhone</option>
                      <option value="pc">PC</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-2xs font-bold text-slate-400 mb-1">
                      বেস মূল্য (৳):
                    </label>
                    <input
                      type="number"
                      value={activeProduct.basePrice}
                      onChange={(e) => updateProductDetails(activeProduct.id, { basePrice: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                {/* Setup Video & App Download Links (Admin can edit anytime) */}
                <div className="p-4 rounded-xl border border-indigo-500/30 bg-indigo-500/5 dark:bg-indigo-950/20 space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-2xs font-extrabold uppercase text-indigo-400 flex items-center gap-1.5">
                      <Play className="w-3.5 h-3.5 text-red-500" />
                      <span>সেটআপ ভিডিও ও অ্যাপ ডাউনলোড লিংক (Setup Video & App Link)</span>
                    </span>
                    <span className="text-3xs text-slate-400">
                      কাস্টমার প্রোডাক্ট ডিটেইলসে "App Link + Setup Video" চাপলে এই ভিডিও/লিংক দেখতে পাবে
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Setup Video Link */}
                    <div>
                      <label className="block text-2xs font-bold text-slate-400 mb-1 flex items-center gap-1">
                        <Video className="w-3.5 h-3.5 text-red-500" />
                        <span>সেটআপ ভিডিও লিংক (Setup Video YouTube URL):</span>
                      </label>
                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          value={activeProduct.videoLink || ''}
                          onChange={(e) => updateProductDetails(activeProduct.id, { videoLink: e.target.value })}
                          placeholder="https://youtube.com/watch?v=... অথবা https://t.me/..."
                          className="flex-1 px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
                        />
                        {activeProduct.videoLink && (
                          <a
                            href={activeProduct.videoLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/40 text-xs font-bold rounded-xl flex items-center gap-1 cursor-pointer transition shrink-0"
                            title="ভিডিও লিংক টেস্ট করুন"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>ভিডিও টেস্ট</span>
                          </a>
                        )}
                      </div>
                    </div>

                    {/* App Link */}
                    <div>
                      <label className="block text-2xs font-bold text-slate-400 mb-1 flex items-center gap-1">
                        <LinkIcon className="w-3.5 h-3.5 text-blue-400" />
                        <span>অ্যাপ ডাউনলোড লিংক (App Download Link):</span>
                      </label>
                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          value={activeProduct.appLink || ''}
                          onChange={(e) => updateProductDetails(activeProduct.id, { appLink: e.target.value })}
                          placeholder="https://t.me/mrlapin_official/..."
                          className="flex-1 px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                        />
                        {activeProduct.appLink && (
                          <a
                            href={activeProduct.appLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/40 text-xs font-bold rounded-xl flex items-center gap-1 cursor-pointer transition shrink-0"
                            title="অ্যাপ লিংক টেস্ট করুন"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>লিংক টেস্ট</span>
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Status Switcher Buttons matching user instructions */}
                <div>
                  <label className="block text-2xs font-bold text-slate-400 mb-1.5">
                    স্ট্যাটাস সুইচ করুন (Online / Maintenance / Out of Stock / Not Available):
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-2xs">
                    
                    {/* ONLINE */}
                    <button
                      type="button"
                      onClick={() => {
                        updateProductStatus(activeProduct.id, 'online');
                        showToast(`${activeProduct.name} এখন Online!`);
                      }}
                      className={`px-3 py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                        activeProduct.status === 'online'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Online (চালু)</span>
                    </button>

                    {/* MAINTENANCE */}
                    <button
                      type="button"
                      onClick={() => {
                        updateProductStatus(activeProduct.id, 'maintenance', 'UNDER MAINTENANCE - BACK SOON');
                        showToast(`${activeProduct.name} মেইনটেন্যান্সে দেওয়া হয়েছে!`);
                      }}
                      className={`px-3 py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                        activeProduct.status === 'maintenance'
                          ? 'bg-red-700 text-white shadow-xs'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      <Wrench className="w-3.5 h-3.5" />
                      <span>Maintenance</span>
                    </button>

                    {/* OUT OF STOCK */}
                    <button
                      type="button"
                      onClick={() => {
                        updateProductStatus(activeProduct.id, 'out_of_stock', 'OUT OF STOCK');
                        showToast(`${activeProduct.name} Out of Stock হিসেবে সেট করা হয়েছে!`);
                      }}
                      className={`px-3 py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                        activeProduct.status === 'out_of_stock'
                          ? 'bg-amber-600 text-white shadow-xs'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>Out Of Stock</span>
                    </button>

                    {/* THIS PRODUCT NOT AVAILABLE */}
                    <button
                      type="button"
                      onClick={() => {
                        updateProductStatus(activeProduct.id, 'not_available', 'THIS PRODUCT NOT AVAILABLE');
                        showToast(`${activeProduct.name} Not Available হিসেবে সেট করা হয়েছে!`);
                      }}
                      className={`px-3 py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                        activeProduct.status === 'not_available'
                          ? 'bg-rose-900 text-white shadow-xs'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>Not Available</span>
                    </button>

                  </div>
                </div>

                {/* Custom Badge Text Input */}
                <div>
                  <label className="block text-2xs text-slate-400 mb-0.5">
                    কাস্টম ব্যাজ টেক্সট (Custom Badge Text, e.g. "THIS PRODUCT NOT AVAILABLE", "UPDATING TO OB44"):
                  </label>
                  <input
                    type="text"
                    value={activeProduct.customBadge || ''}
                    placeholder="e.g. THIS PRODUCT NOT AVAILABLE"
                    onChange={(e) => updateProductDetails(activeProduct.id, { customBadge: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* ========================================================================= */}
              {/* SECTION 2: DURATION / HOURS CUSTOMIZATION (সময়/ঘন্টা ও দাম পরিবর্তন)     */}
              {/* ========================================================================= */}
              <div className="space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <span className="text-2xs font-extrabold text-amber-500 uppercase tracking-wider flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>২. প্যাকেজের সময়/ঘন্টা (Durations/Hours) ও লাইসেন্স Key কন্ট্রোল</span>
                    </span>
                    <h4 className="text-sm font-black text-slate-900 dark:text-white mt-0.5">
                      যে কয় ঘন্টার জন্য নিবে, তার সময়, দাম ও স্টক কী (Keys) ম্যানেজ করুন
                    </h4>
                  </div>

                  <button
                    onClick={() => setShowAddTierModal(!showAddTierModal)}
                    className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>নতুন সময়/ঘন্টা যোগ করুন</span>
                  </button>
                </div>

                {/* Add New Duration Tier Form */}
                {showAddTierModal && (
                  <form onSubmit={handleAddTierToProduct} className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/5 space-y-3 animate-in fade-in duration-200">
                    <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
                      <strong className="text-xs font-bold text-amber-400">
                        নতুন সময়/ঘন্টা প্যাকেজ যুক্ত করুন
                      </strong>
                      <button
                        type="button"
                        onClick={() => setShowAddTierModal(false)}
                        className="text-2xs text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        বাতিল
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-2xs font-bold text-slate-400 mb-1">
                          সময় / ঘন্টা (Duration, e.g. "2 Hours", "1 Day", "7 Days"):
                        </label>
                        <input
                          type="text"
                          value={newTierDuration}
                          onChange={(e) => setNewTierDuration(e.target.value)}
                          placeholder="e.g. 2 Hours, 24 Hours, 7 Days"
                          required
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold"
                        />
                      </div>

                      <div>
                        <label className="block text-2xs font-bold text-slate-400 mb-1">
                          প্রদর্শিত নাম (Display Name):
                        </label>
                        <input
                          type="text"
                          value={newTierName}
                          onChange={(e) => setNewTierName(e.target.value)}
                          placeholder={`e.g. ${activeProduct.name} - 2 HOURS`}
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-2xs font-bold text-slate-400 mb-1">
                          মূল্য (৳):
                        </label>
                        <input
                          type="number"
                          value={newTierPrice}
                          onChange={(e) => setNewTierPrice(e.target.value)}
                          required
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                        />
                      </div>

                      <div className="sm:col-span-3">
                        <label className="block text-2xs font-bold text-slate-400 mb-1">
                          প্রাথমিক লাইসেন্স Key গুলো দিন (ঐচ্ছিক, প্রতি লাইনে ১টি কী):
                        </label>
                        <textarea
                          rows={2}
                          value={newTierInitialKeys}
                          onChange={(e) => setNewTierInitialKeys(e.target.value)}
                          placeholder="LAPIN-2H-1029-ABC&#10;LAPIN-2H-9921-XYZ"
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setShowAddTierModal(false)}
                        className="px-3 py-1 text-2xs font-bold text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        বাতিল
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                      >
                        প্যাকেজ যোগ করুন
                      </button>
                    </div>
                  </form>
                )}

                {/* List of Existing Duration Packages with Inline Edit & Keys Pool */}
                <div className="space-y-3">
                  {activeProduct.packages.map((pkg) => {
                    const poolCount = pkg.keysPool?.length || 0;
                    const isViewingKeys = viewingKeysTierId === pkg.id;

                    return (
                      <div
                        key={pkg.id}
                        className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3"
                      >
                        {/* Package Row Top: Duration, Price, Status */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="flex items-center gap-3 flex-wrap">
                            <span className="px-2.5 py-1 rounded-lg bg-indigo-600/10 dark:bg-indigo-500/20 text-indigo-500 dark:text-indigo-400 font-black text-xs font-mono border border-indigo-500/30">
                              {pkg.duration}
                            </span>
                            <span className="font-bold text-xs text-slate-900 dark:text-white truncate max-w-xs">
                              {pkg.name}
                            </span>
                            <span className="font-mono text-xs font-black text-amber-500">
                              ৳{pkg.price}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 flex-wrap">
                            {/* Stock Badge - Matches user: "key shes hoye gele dekhay jani automatic shot out" */}
                            {poolCount > 0 ? (
                              <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono text-2xs font-bold flex items-center gap-1">
                                <Key className="w-3 h-3" />
                                <span>{poolCount} Keys In Stock</span>
                              </span>
                            ) : (
                              <span className="px-2.5 py-1 rounded-full bg-red-600/20 text-red-400 border border-red-500/50 font-mono text-2xs font-black flex items-center gap-1 animate-pulse">
                                <Ban className="w-3 h-3" />
                                <span>🔴 AUTOMATIC SHOT OUT (Stock 0)</span>
                              </span>
                            )}

                            {/* Status Toggle Button */}
                            <button
                              type="button"
                              onClick={() => {
                                const nextStatus = pkg.status === 'online' ? 'out_of_stock' : 'online';
                                editProductPackage(activeProduct.id, pkg.id, { status: nextStatus });
                                showToast(`${pkg.duration} স্ট্যাটাস: ${nextStatus.toUpperCase()}`);
                              }}
                              className={`px-2.5 py-1 rounded-lg text-2xs font-bold cursor-pointer transition ${
                                pkg.status === 'online'
                                  ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-red-600/20 text-red-400 border border-red-500/30'
                              }`}
                            >
                              {pkg.status === 'online' ? 'Online' : 'Out of Stock'}
                            </button>

                            {/* Delete Tier */}
                            <button
                              type="button"
                              onClick={() => {
                                if (confirm(`Delete package ${pkg.duration}?`)) {
                                  deletePackageFromProduct(activeProduct.id, pkg.id);
                                  showToast(`${pkg.duration} ডিলিট করা হয়েছে!`);
                                }
                              }}
                              className="p-1 text-slate-400 hover:text-red-400 cursor-pointer"
                              title="Delete package"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Inline Fields to Edit Duration Name and Price */}
                        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-1 border-t border-slate-200/40 dark:border-slate-700/40 items-center">
                          <div className="sm:col-span-3">
                            <label className="block text-3xs font-bold text-slate-400 mb-0.5">
                              সময় (Duration Text):
                            </label>
                            <input
                              type="text"
                              value={pkg.duration}
                              onChange={(e) => editProductPackage(activeProduct.id, pkg.id, { duration: e.target.value })}
                              className="w-full px-2 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-mono"
                            />
                          </div>

                          <div className="sm:col-span-5">
                            <label className="block text-3xs font-bold text-slate-400 mb-0.5">
                              পূর্ণ নাম (Package Name):
                            </label>
                            <input
                              type="text"
                              value={pkg.name}
                              onChange={(e) => editProductPackage(activeProduct.id, pkg.id, { name: e.target.value })}
                              className="w-full px-2 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <label className="block text-3xs font-bold text-slate-400 mb-0.5">
                              মূল্য (৳):
                            </label>
                            <input
                              type="number"
                              value={pkg.price}
                              onChange={(e) => editProductPackage(activeProduct.id, pkg.id, { price: parseFloat(e.target.value) || 0 })}
                              className="w-full px-2 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-mono"
                            />
                          </div>

                          <div className="sm:col-span-2 flex items-end">
                            <button
                              type="button"
                              onClick={() => showToast(`${pkg.duration} আপডেট করা হয়েছে!`)}
                              className="w-full py-1 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-xs font-bold cursor-pointer"
                            >
                              সেভ
                            </button>
                          </div>
                        </div>

                        {/* License Key Stock Manager for this Duration */}
                        <div className="p-3 rounded-lg bg-blue-50/50 dark:bg-slate-900/90 border border-blue-200 dark:border-slate-700/60 space-y-2">
                          <div className="flex items-center justify-between flex-wrap gap-2">
                            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400">
                              <Key className="w-3.5 h-3.5" />
                              <span>লাইসেন্স Key স্টক ({pkg.duration} এর জন্য):</span>
                              <span className="font-mono text-2xs px-1.5 py-0.2 rounded bg-blue-500/10">
                                {poolCount} টি Key প্রস্তুত
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              {/* 5 Test Keys quick generator */}
                              <button
                                type="button"
                                onClick={() => handleGenerateTestKeys(activeProduct.id, pkg.id, pkg.duration)}
                                className="px-2 py-1 rounded text-2xs font-bold bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 border border-amber-500/30 cursor-pointer flex items-center gap-1"
                              >
                                <Sparkles className="w-3 h-3" />
                                <span>+৫টি টেস্ট Key তৈরি করুন</span>
                              </button>

                              {/* Toggle View Loaded Keys */}
                              <button
                                type="button"
                                onClick={() => setViewingKeysTierId(isViewingKeys ? null : pkg.id)}
                                className="px-2 py-1 rounded text-2xs font-bold bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 cursor-pointer flex items-center gap-1"
                              >
                                <Eye className="w-3 h-3" />
                                <span>{isViewingKeys ? 'লুকান' : `কী তালিকা (${poolCount})`}</span>
                              </button>
                            </div>
                          </div>

                          {/* Textarea to Add New Keys */}
                          <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-end">
                            <div className="flex-1 min-w-0">
                              <label className="block text-3xs font-bold text-slate-400 mb-0.5">
                                নতুন Key পেস্ট করুন (প্রতি লাইনে ১টি Key দিন):
                              </label>
                              <textarea
                                rows={2}
                                value={tierKeysInput[pkg.id] || ''}
                                onChange={(e) => setTierKeysInput({ ...tierKeysInput, [pkg.id]: e.target.value })}
                                placeholder={`LAPIN-${pkg.duration.replace(/\s+/g, '').toUpperCase()}-8821-ABC\nLAPIN-${pkg.duration.replace(/\s+/g, '').toUpperCase()}-4412-XYZ`}
                                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-2xs text-slate-900 dark:text-emerald-400 focus:outline-none focus:border-blue-500"
                              />
                            </div>

                            <button
                              type="button"
                              onClick={() => handleAddKeysToTier(activeProduct.id, pkg.id)}
                              className="px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-2xs cursor-pointer flex items-center justify-center gap-1 shrink-0 shadow-xs"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>স্টকে Key যুক্ত করুন</span>
                            </button>
                          </div>

                          {/* View All Currently Loaded Keys for this Tier */}
                          {isViewingKeys && (
                            <div className="mt-2 p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2 animate-in fade-in duration-150">
                              <div className="flex items-center justify-between text-2xs text-slate-400 border-b border-slate-800 pb-1.5">
                                <span className="font-bold">বর্তমানে লোড থাকা লাইসেন্স Key সমূহ ({poolCount}টি):</span>
                                {poolCount > 0 && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (confirm(`Clear all ${poolCount} keys for ${pkg.duration}?`)) {
                                        clearPackageKeys(activeProduct.id, pkg.id);
                                        showToast(`সব Key মুছে ফেলা হয়েছে!`);
                                      }
                                    }}
                                    className="text-red-400 hover:text-red-300 text-3xs font-bold cursor-pointer"
                                  >
                                    সব Key মুছুন
                                  </button>
                                )}
                              </div>

                              {poolCount === 0 ? (
                                <p className="text-2xs text-slate-500 italic py-1">
                                  এই প্যাকেজে কোনো কী নেই। গ্রাহক কিনলে স্বয়ংক্রিয়ভাবে আউট অফ স্টক (AUTOMATIC SHOT OUT) দেখাবে। উপরে কী পেস্ট করে যুক্ত করুন।
                                </p>
                              ) : (
                                <div className="max-h-36 overflow-y-auto space-y-1 pr-1 font-mono text-2xs">
                                  {pkg.keysPool!.map((k, kIdx) => (
                                    <div
                                      key={kIdx}
                                      className="flex items-center justify-between px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-emerald-400"
                                    >
                                      <span className="truncate select-all">{kIdx + 1}. {k}</span>
                                      <div className="flex items-center gap-1.5 shrink-0">
                                        <button
                                          type="button"
                                          onClick={() => {
                                            navigator.clipboard.writeText(k);
                                            showToast('Key কপি হয়েছে!');
                                          }}
                                          className="text-slate-400 hover:text-white p-0.5"
                                          title="Copy key"
                                        >
                                          <Copy className="w-3 h-3" />
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            removeKeyFromPackageTier(activeProduct.id, pkg.id, kIdx);
                                            showToast('Key মুছে ফেলা হয়েছে!');
                                          }}
                                          className="text-slate-400 hover:text-red-400 p-0.5"
                                          title="Remove key"
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          )}

                        </div>

                      </div>
                    );
                  })}
                </div>

              </div>

            </div>
          )}

        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: SOLD KEYS & BUYER GMAIL LOG (DELIVERY TRACKING AUDIT)              */}
      {/* ========================================================================= */}
      {activeAdminTab === 'sold_keys' && (() => {
        const totalSoldRevenue = orders.reduce((acc, o) => acc + o.totalPrice, 0);
        const uniqueGmails = new Set(orders.map((o) => o.userEmail).filter(Boolean));

        const filteredOrders = orders.filter((o) => {
          if (!soldKeySearch.trim()) return true;
          const q = soldKeySearch.toLowerCase().trim();
          return (
            o.userEmail?.toLowerCase().includes(q) ||
            o.userName?.toLowerCase().includes(q) ||
            o.productName?.toLowerCase().includes(q) ||
            o.licenseKey?.toLowerCase().includes(q) ||
            o.serialNo?.toString().includes(q)
          );
        });

        return (
          <div className="space-y-6 animate-in fade-in duration-200">
            
            {/* Header info */}
            <div>
              <h3 className="font-black text-base sm:text-lg flex items-center gap-2">
                <Key className="w-5 h-5 text-amber-400" />
                <span>বিক্রি হওয়া লাইসেন্স Key ও ক্রেতার Gmail হিস্টোরি</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                "admin ১০ টা key দিলে সেখান থেকে ৫ জন ৫টি কিনলে কোন gmail দিয়ে কিনেছে সেটা দেখাবে এবং কী শেষ হলে Automatic Shot Out দেখাবে"
              </p>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 space-y-1">
                <span className="text-2xs font-extrabold uppercase text-emerald-400">
                  মোট বিক্রি হওয়া Key
                </span>
                <div className="font-mono text-2xl font-black text-emerald-400">
                  {orders.length} টি
                </div>
                <span className="text-2xs text-slate-400 font-mono">
                  স্বয়ংক্রিয়ভাবে স্টক থেকে ডেলিভারি সম্পন্ন
                </span>
              </div>

              <div className="p-4 rounded-2xl border border-blue-500/30 bg-blue-500/5 space-y-1">
                <span className="text-2xs font-extrabold uppercase text-blue-400">
                  ইউনিক ক্রেতার Gmail সংখ্যা
                </span>
                <div className="font-mono text-2xl font-black text-blue-400">
                  {uniqueGmails.size} টি অ্যাকাউন্ট
                </div>
                <span className="text-2xs text-slate-400 font-mono">
                  রেজিস্টার্ড ও ভেরিফাইড ক্রেতা
                </span>
              </div>

              <div className="p-4 rounded-2xl border border-amber-500/30 bg-amber-500/5 space-y-1">
                <span className="text-2xs font-extrabold uppercase text-amber-400">
                  মোট Key বিক্রির আয়
                </span>
                <div className="font-mono text-2xl font-black text-amber-400">
                  ৳ {totalSoldRevenue}
                </div>
                <span className="text-2xs text-slate-400 font-mono">
                  সরাসরি ওয়ালেট থেকে কর্তনকৃত
                </span>
              </div>
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={soldKeySearch}
                onChange={(e) => setSoldKeySearch(e.target.value)}
                placeholder="ক্রেতার Gmail (@gmail.com), নাম, Key অথবা প্রোডাক্ট সার্চ করুন..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Sold Keys Table */}
            <div
              className={`p-5 rounded-2xl border space-y-3 ${
                isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                <strong className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider">
                  ডেলিভারিকৃত Key ও ক্রেতা লগ ({filteredOrders.length} টি রেকর্ড)
                </strong>
                <span className="text-2xs font-mono text-slate-400">
                  Realtime Automated Delivery
                </span>
              </div>

              {filteredOrders.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  কোনো বিক্রি হওয়া Key রেকর্ড পাওয়া যায়নি।
                </div>
              ) : (
                <div className="space-y-2.5">
                  {filteredOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      {/* Customer info + Product */}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-3xs px-2 py-0.5 rounded bg-blue-600/10 text-blue-400 font-bold border border-blue-500/20">
                            #{ord.serialNo}
                          </span>
                          <strong className="text-sm font-black text-slate-900 dark:text-white">
                            {ord.productName}
                          </strong>
                          <span className="text-2xs px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
                            {ord.packageTitle}
                          </span>
                          <span
                            className={`text-3xs font-extrabold uppercase px-2 py-0.5 rounded border ${
                              ord.status === 'completed'
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                                : ord.status === 'processing' || ord.status === 'pending'
                                ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                                : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                            }`}
                          >
                            {ord.status}
                          </span>
                        </div>

                        {/* Customer Gmail Highlight */}
                        <div className="flex items-center gap-3 text-2xs text-slate-400 flex-wrap">
                          <span className="flex items-center gap-1 font-bold text-slate-700 dark:text-slate-200">
                            <User className="w-3 h-3 text-slate-400" />
                            <span>{ord.userName}</span>
                          </span>
                          <span>·</span>
                          <span className="flex items-center gap-1 font-mono font-bold text-amber-500 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                            <Mail className="w-3 h-3 text-amber-500" />
                            <span>{ord.userEmail || 'reddevil3069@gmail.com'}</span>
                          </span>
                          <span>·</span>
                          <span className="font-mono text-slate-400">{ord.date}</span>
                        </div>
                      </div>

                      {/* License Key box */}
                      <div className="flex items-center gap-3 shrink-0 justify-between sm:justify-end">
                        <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 font-mono text-xs font-black text-emerald-400 flex items-center gap-2">
                          <span className="select-all">{ord.licenseKey}</span>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(ord.licenseKey);
                              setCopiedKeyText(ord.id);
                              setTimeout(() => setCopiedKeyText(null), 2000);
                              showToast('Key কপি হয়েছে!');
                            }}
                            className="text-slate-400 hover:text-white p-1"
                            title="Copy Key"
                          >
                            {copiedKeyText === ord.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>

                        <div className="font-mono text-xs font-black text-amber-500 shrink-0">
                          ৳ {ord.totalPrice}
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              )}

            </div>

          </div>
        );
      })()}

      {/* ========================================================================= */}
      {/* TAB 3: PAYMENT GATEWAY NUMBERS (BKASH, NAGAD, ROCKET, BINANCE, INDIAPAY)  */}
      {/* ========================================================================= */}
      {activeAdminTab === 'gateways' && (
        <div
          className={`p-6 rounded-2xl border space-y-6 shadow-sm ${
            isDarkMode
              ? 'bg-slate-900 border-slate-800 text-white'
              : 'bg-white border-slate-200 text-slate-900'
          }`}
        >
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="font-black text-base sm:text-lg flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-blue-500" />
                <span>পেমেন্ট নম্বর পরিবর্তন (bKash / Nagad / Rocket / Binance / IndiaPay)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                এখানে নম্বর পরিবর্তন করলে ওয়েবসাইট ও Add Fund পেজে গ্রাহকদের কাছে সরাসরি নতুন নম্বর প্রদর্শিত হবে।
              </p>
            </div>

            <button
              onClick={() => {
                gateways.forEach((gw) => handleSaveGateway(gw.id));
                showToast('সব পেমেন্ট নম্বর সফলভাবে সেভ করা হয়েছে!');
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Save className="w-4 h-4" />
              <span>সব নম্বর সেভ করুন</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {gateways.map((gw) => {
              const currentEdit = editingGateways[gw.id] || {
                numberOrAddress: gw.numberOrAddress,
                subType: gw.subType,
                minAmount: gw.minAmount,
                maxAmount: gw.maxAmount,
                instructions: gw.instructions,
                isActive: gw.isActive
              };

              return (
                <div
                  key={gw.id}
                  className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-4"
                >
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-4 h-4 rounded-full shrink-0 shadow-sm"
                        style={{ backgroundColor: gw.color }}
                      />
                      <strong className="text-base font-black">{gw.name}</strong>
                      <span className="text-2xs font-mono font-bold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                        {currentEdit.subType}
                      </span>
                    </div>

                    {/* Active toggle */}
                    <div className="flex items-center gap-2">
                      <label className="text-2xs font-bold text-slate-400 cursor-pointer">
                        স্ট্যাটাস:
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          const updated = { ...currentEdit, isActive: !currentEdit.isActive };
                          setEditingGateways({ ...editingGateways, [gw.id]: updated });
                          updateGatewayDetails(gw.id, { isActive: !currentEdit.isActive });
                          showToast(`${gw.name} ${!currentEdit.isActive ? 'সক্রিয় (Active)' : 'নিষ্ক্রিয় (Inactive)'} করা হয়েছে!`);
                        }}
                        className={`px-3 py-1 rounded-full text-2xs font-black transition cursor-pointer ${
                          currentEdit.isActive
                            ? 'bg-emerald-600 text-white'
                            : 'bg-red-600/20 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {currentEdit.isActive ? '✓ Active (চালু)' : '✕ Inactive (বন্ধ)'}
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                    
                    {/* Payment Number Input */}
                    <div className="sm:col-span-5">
                      <label className="block text-2xs font-bold text-slate-400 mb-1">
                        পেমেন্ট নম্বর / ওয়ালেট এড্রেস (গ্রাহক যে নম্বরে টাকা পাঠাবে):
                      </label>
                      <input
                        type="text"
                        value={currentEdit.numberOrAddress}
                        onChange={(e) =>
                          setEditingGateways({
                            ...editingGateways,
                            [gw.id]: { ...currentEdit, numberOrAddress: e.target.value }
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-sm font-black text-slate-900 dark:text-amber-400 focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    {/* Subtype (Personal / Merchant / Agent) */}
                    <div className="sm:col-span-3">
                      <label className="block text-2xs font-bold text-slate-400 mb-1">
                        অ্যাকাউন্টের ধরন (Account SubType):
                      </label>
                      <input
                        type="text"
                        value={currentEdit.subType}
                        onChange={(e) =>
                          setEditingGateways({
                            ...editingGateways,
                            [gw.id]: { ...currentEdit, subType: e.target.value }
                          })
                        }
                        placeholder="e.g. পার্সোনাল, মার্চেন্ট, এজেন্ট"
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    {/* Min & Max Amount */}
                    <div className="sm:col-span-2">
                      <label className="block text-2xs font-bold text-slate-400 mb-1">
                        সর্বনিম্ন (৳):
                      </label>
                      <input
                        type="number"
                        value={currentEdit.minAmount}
                        onChange={(e) =>
                          setEditingGateways({
                            ...editingGateways,
                            [gw.id]: { ...currentEdit, minAmount: parseFloat(e.target.value) || 0 }
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs text-slate-900 dark:text-white"
                      />
                    </div>

                    {/* Single Save Button */}
                    <div className="sm:col-span-2 flex items-end">
                      <button
                        type="button"
                        onClick={() => handleSaveGateway(gw.id)}
                        className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>সেভ করুন</span>
                      </button>
                    </div>

                    {/* Instructions Text */}
                    <div className="sm:col-span-12">
                      <label className="block text-3xs font-bold text-slate-400 mb-1">
                        গ্রাহকের জন্য নির্দেশনা নোট (Instructions displayed under payment box):
                      </label>
                      <input
                        type="text"
                        value={currentEdit.instructions}
                        onChange={(e) =>
                          setEditingGateways({
                            ...editingGateways,
                            [gw.id]: { ...currentEdit, instructions: e.target.value }
                          })
                        }
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-300"
                      />
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: APPROVE PAYMENTS & TRANSACTION QUEUE                               */}
      {/* ========================================================================= */}
      {activeAdminTab === 'approve_payments' && (() => {
        const completedList = deposits.filter((d) => d.status === 'completed');
        const pendingList = deposits.filter((d) => d.status === 'pending');
        const rejectedList = deposits.filter((d) => d.status === 'rejected');

        const completedSum = completedList.reduce((acc, d) => acc + d.amount, 0);

        const filteredDeposits = deposits.filter((d) => {
          if (depositFilter === 'completed' && d.status !== 'completed') return false;
          if (depositFilter === 'pending' && d.status !== 'pending') return false;
          if (depositFilter === 'rejected' && d.status !== 'rejected') return false;

          if (gatewayFilter !== 'all' && !d.gateway.toLowerCase().includes(gatewayFilter.toLowerCase())) {
            return false;
          }

          if (searchQuery.trim()) {
            const q = searchQuery.toLowerCase().trim();
            const matchTrx = d.trxId.toLowerCase().includes(q);
            const matchSender = d.senderNumber.toLowerCase().includes(q);
            const matchSerial = d.serialNo.toString().includes(q);
            const matchUser = d.userName.toLowerCase().includes(q) || d.userEmail.toLowerCase().includes(q);
            if (!matchTrx && !matchSender && !matchSerial && !matchUser) return false;
          }

          return true;
        });

        return (
          <div className="space-y-6">
            
            {/* KPI Summary Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 space-y-1">
                <span className="text-2xs font-extrabold uppercase tracking-wider text-emerald-500 block">
                  ইনস্ট্যান্ট যুক্ত ব্যালেন্স
                </span>
                <div className="font-mono text-xl sm:text-2xl font-black text-emerald-400">
                  {completedList.length}
                </div>
                <span className="text-2xs text-slate-400 block font-mono">
                  মোট: ৳{completedSum}
                </span>
              </div>

              <div className="p-4 rounded-2xl border border-amber-500/30 bg-amber-500/5 space-y-1">
                <span className="text-2xs font-extrabold uppercase tracking-wider text-amber-500 block">
                  Pending Approvals
                </span>
                <div className="font-mono text-xl sm:text-2xl font-black text-amber-400">
                  {pendingList.length}
                </div>
                <span className="text-2xs text-slate-400 block">
                  যাচাই অপেক্ষমান
                </span>
              </div>

              <div className="p-4 rounded-2xl border border-blue-500/30 bg-blue-500/5 space-y-1">
                <span className="text-2xs font-extrabold uppercase tracking-wider text-blue-500 block">
                  User Current Balance
                </span>
                <div className="font-mono text-xl sm:text-2xl font-black text-blue-400">
                  ৳{user.balance}
                </div>
                <span className="text-2xs text-slate-400 block truncate">
                  {user.name} ({user.email})
                </span>
              </div>

              <div className="p-4 rounded-2xl border border-red-500/30 bg-red-500/5 space-y-1">
                <span className="text-2xs font-extrabold uppercase tracking-wider text-red-500 block">
                  Rejected Payments
                </span>
                <div className="font-mono text-xl sm:text-2xl font-black text-red-400">
                  {rejectedList.length}
                </div>
                <span className="text-2xs text-slate-400 block">
                  বাতিলকৃত
                </span>
              </div>
            </div>

            {/* Manual Account Credit Tool */}
            <div
              className={`p-5 rounded-2xl border ${
                isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex items-center gap-2 mb-3">
                <UserCheck className="w-5 h-5 text-emerald-500" />
                <h3 className="font-black text-sm text-slate-900 dark:text-white">
                  ম্যানুয়াল ব্যালেন্স অ্যাড (অ্যাডমিন সরাসরি যেকোনো গ্রাহককে টাকা দিতে পারবে)
                </h3>
              </div>
              <p className="text-2xs text-slate-400 mb-4">
                "কেউ tk দিছে সেই tk websit এ না add হইলে admin নিজেই add করে দিতে পারবে সেই বেক্তি কে"
              </p>

              <form onSubmit={handleManualAdd} className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                <div className="sm:col-span-4">
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    গ্রাহক নির্বাচন করুন:
                  </label>
                  <div className="p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white">
                    {user.name} ({user.email}) · বর্তমান ব্যালেন্স: ৳{user.balance}
                  </div>
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    টাকার পরিমাণ (৳):
                  </label>
                  <input
                    type="number"
                    value={manualAmount}
                    onChange={(e) => setManualAmount(e.target.value)}
                    placeholder="100"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-2xs font-bold text-slate-400 mb-1">
                    নোট / রেফারেন্স:
                  </label>
                  <input
                    type="text"
                    value={manualNote}
                    onChange={(e) => setManualNote(e.target.value)}
                    placeholder="Admin Manual Recharge"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>ব্যালেন্স যুক্ত করুন</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Transaction Queue Table & Actions */}
            <div
              className={`p-5 rounded-2xl border space-y-4 ${
                isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-black text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-500" />
                    <span>পেমেন্ট রিকোয়েস্ট তালিকা ও হিস্টোরি (Payment History)</span>
                  </h3>
                  <p className="text-2xs text-slate-400 mt-0.5">
                    গ্রাহক bKash/Nagad/Rocket এ টাকা পাঠানোর পর TrxID দিলে স্বয়ংক্রিয়ভাবে ওয়ালেটে টাকা যুক্ত হয় এবং এখানে লগ তৈরি হয়।
                  </p>
                </div>

                {/* Filter Pills */}
                <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                  {(['all', 'completed', 'pending', 'rejected'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setDepositFilter(f)}
                      className={`px-3 py-1 rounded-lg text-2xs font-black capitalize transition cursor-pointer ${
                        depositFilter === f
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {f === 'all' ? 'All' : f === 'completed' ? 'Auto Credited' : f === 'pending' ? 'Pending' : 'Rejected'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Search & Method Filter */}
              <div className="flex flex-col sm:flex-row items-center gap-2.5">
                <div className="relative flex-1 w-full">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search TrxID, Phone, Name, Serial..."
                    className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <select
                  value={gatewayFilter}
                  onChange={(e) => setGatewayFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-white w-full sm:w-auto"
                >
                  <option value="all">All Gateways</option>
                  <option value="bkash">bKash</option>
                  <option value="nagad">Nagad</option>
                  <option value="rocket">Rocket</option>
                  <option value="binance">Binance</option>
                  <option value="indiapay">IndiaPay</option>
                </select>
              </div>

              {/* Transactions List */}
              {filteredDeposits.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  কোনো ডিপোজিট রিকোয়েস্ট পাওয়া যায়নি।
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredDeposits.map((dep) => {
                    const isAdjusting = adjustingDepositId === dep.id;
                    const isRejecting = rejectingDepositId === dep.id;

                    return (
                      <div
                        key={dep.id}
                        className={`p-4 rounded-xl border transition-all ${
                          dep.status === 'completed'
                            ? 'border-emerald-500/30 bg-emerald-500/5'
                            : dep.status === 'pending'
                            ? 'border-amber-500/40 bg-amber-500/5'
                            : 'border-red-500/30 bg-red-500/5'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          
                          {/* Info block */}
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-mono text-2xs px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold">
                                #{dep.serialNo}
                              </span>
                              <strong className="text-sm font-black text-slate-900 dark:text-white">
                                {dep.paymentMethod}
                              </strong>
                              <span
                                className={`text-3xs font-extrabold uppercase px-2 py-0.5 rounded-full ${
                                  dep.status === 'completed'
                                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                    : dep.status === 'pending'
                                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                                    : 'bg-red-500/20 text-red-400 border border-red-500/30'
                                }`}
                              >
                                {dep.status === 'completed' ? 'Auto Credited' : dep.status}
                              </span>
                            </div>

                            <div className="text-xs text-slate-400 flex items-center gap-3 flex-wrap">
                              <span>Customer: <strong className="text-slate-200">{dep.userName}</strong></span>
                              <span>·</span>
                              <span className="font-mono text-amber-400 font-bold">{dep.userEmail}</span>
                              <span>·</span>
                              <span>Sender: <strong className="text-amber-400 font-mono">{dep.senderNumber}</strong></span>
                              <span>·</span>
                              <span>Time: {dep.date}</span>
                            </div>

                            <div className="flex items-center gap-2 pt-1 font-mono text-xs">
                              <span className="text-slate-400">TrxID:</span>
                              <span className="font-bold text-slate-900 dark:text-white select-all">
                                {dep.trxId}
                              </span>
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(dep.trxId);
                                  setCopiedTrxId(dep.id);
                                  setTimeout(() => setCopiedTrxId(null), 2000);
                                }}
                                className="text-slate-400 hover:text-white p-0.5"
                                title="Copy TrxID"
                              >
                                {copiedTrxId === dep.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                          </div>

                          {/* Price & Action Buttons */}
                          <div className="flex sm:flex-col items-end justify-between sm:justify-center gap-2 shrink-0">
                            <div className="font-mono text-lg sm:text-xl font-black text-emerald-400">
                              ৳{dep.amount}
                            </div>

                            {dep.status === 'completed' && (
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-2xs text-emerald-400 font-bold flex items-center gap-1">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>ওয়ালেটে যুক্ত হয়েছে</span>
                                </span>
                                <button
                                  onClick={() => {
                                    setAdjustingDepositId(isAdjusting ? null : dep.id);
                                    setAdjustedAmount(dep.amount.toString());
                                  }}
                                  className="px-2 py-0.5 rounded text-3xs font-bold text-slate-400 hover:text-white bg-slate-800"
                                >
                                  এডজাস্ট
                                </button>
                              </div>
                            )}

                            {dep.status === 'pending' && (
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <button
                                  onClick={() => {
                                    approveDeposit(dep.id);
                                    showToast(`Approved #${dep.serialNo} and credited ৳${dep.amount}!`);
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 cursor-pointer shadow-xs"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Approve</span>
                                </button>
                                <button
                                  onClick={() => setRejectingDepositId(isRejecting ? null : dep.id)}
                                  className="px-2.5 py-1.5 rounded-lg bg-red-600/20 hover:bg-red-600/30 text-red-400 font-bold text-xs flex items-center gap-1 cursor-pointer"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span>Reject</span>
                                </button>
                              </div>
                            )}
                          </div>

                        </div>

                        {/* Adjust Amount Drawer */}
                        {isAdjusting && (
                          <div className="mt-3 p-3 rounded-xl bg-slate-800 border border-slate-700 space-y-2 animate-in fade-in duration-200">
                            <span className="text-2xs font-bold text-slate-300 block">
                              সঠিক টাকার পরিমাণ লিখে আপডেট করুন:
                            </span>
                            <div className="flex items-center gap-2">
                              <input
                                type="number"
                                value={adjustedAmount}
                                onChange={(e) => setAdjustedAmount(e.target.value)}
                                className="px-3 py-1.5 rounded-lg border border-slate-600 bg-slate-900 font-mono text-xs text-white w-32 focus:outline-none focus:border-emerald-500"
                              />
                              <button
                                onClick={() => {
                                  const customAmt = parseFloat(adjustedAmount);
                                  if (customAmt && customAmt > 0) {
                                    dep.amount = customAmt;
                                    setAdjustingDepositId(null);
                                    showToast(`Updated #${dep.serialNo} to ৳${customAmt}!`);
                                  }
                                }}
                                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer"
                              >
                                Save ৳{adjustedAmount}
                              </button>
                              <button
                                onClick={() => setAdjustingDepositId(null)}
                                className="px-2.5 py-1.5 text-2xs text-slate-400 hover:text-slate-200 cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        )}

                      </div>
                    );
                  })}
                </div>
              )}

            </div>

          </div>
        );
      })()}

      {/* ========================================================================= */}
      {/* TAB 5: TELEGRAM POPUP & NOTICE SETTINGS                                   */}
      {/* ========================================================================= */}
      {activeAdminTab === 'telegram' && (
        <form
          onSubmit={handleSaveTelegramAndSite}
          className={`p-6 rounded-2xl border space-y-5 ${
            isDarkMode
              ? 'bg-slate-900 border-slate-800 text-white'
              : 'bg-white border-slate-200 text-slate-900'
          }`}
        >
          <div>
            <h3 className="font-black text-base">
              টেলিগ্রাম ডিএম লিংক ও ওয়েবসাইট সেটিংস
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              ওয়েবসাইটে প্রবেশের সময় প্রদর্শিত টেলিগ্রাম পপআপ ও নোটিশ টেক্সট এখান থেকে পরিবর্তন করুন।
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Site Name */}
            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1">
                Website Name (ওয়েবসাইটের নাম):
              </label>
              <input
                type="text"
                value={siteName}
                onChange={(e) => setSiteName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white"
              />
            </div>

            {/* Support WhatsApp & Help line Number - Matching User Request (IMG_1227) */}
            <div className="sm:col-span-2 p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-emerald-500/20">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-xs text-emerald-400">
                    হোয়াটসঅ্যাপ ও হেল্পলাইন নম্বর এডিটর (Help line Phone & WhatsApp Editor)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleSaveHelplineNumber}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-2xs flex items-center gap-1 shadow-sm transition cursor-pointer self-start sm:self-auto"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>নম্বর সেভ করুন</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-2xs font-bold text-slate-300 mb-1">
                    ১. ডিসপ্লে হেল্পলাইন নম্বর (Help line Button Text):
                  </label>
                  <input
                    type="text"
                    value={supportPhoneText}
                    onChange={(e) => handleSupportPhoneChange(e.target.value)}
                    placeholder="+8801813913894"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono font-bold text-emerald-400 focus:outline-none focus:border-emerald-500"
                  />
                  <p className="text-3xs text-slate-400 mt-1">
                    হোম পেজের নিচে বাটনে হুবহু এই লেখাটি দেখাবে (যেমন: Help line [+8801813913894])
                  </p>
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-300 mb-1">
                    ২. হোয়াটসঅ্যাপ ডিরেক্ট চ্যাট ডিজিট (WhatsApp Link Digits):
                  </label>
                  <input
                    type="text"
                    value={whatsappPhone}
                    onChange={(e) => setWhatsappPhone(e.target.value)}
                    placeholder="8801813913894"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                  <p className="text-3xs text-slate-400 mt-1">
                    চাপ দিলে https://wa.me/ নম্বরটিতে হোয়াটসঅ্যাপ ওপেন হবে
                  </p>
                </div>
              </div>

              {/* Live Button Preview */}
              <div className="pt-2 flex items-center gap-3 bg-slate-950/40 p-2.5 rounded-lg border border-emerald-500/10">
                <span className="text-3xs text-slate-400 font-bold uppercase shrink-0">বাটন লাইভ প্রিভিউ:</span>
                <div className="flex items-center gap-2">
                  <div className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-2xs flex items-center gap-1.5 shadow-sm">
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Help line [{supportPhoneText}]</span>
                  </div>
                  <div className="px-3 py-1.5 rounded-full bg-blue-600 text-white font-bold text-3xs flex items-center gap-1">
                    <Phone className="w-3 h-3" />
                    <span>সাহায্য লাগবে ?</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Telegram Direct DM Link matching user request */}
            <div className="sm:col-span-2 p-3.5 rounded-xl border border-sky-500/30 bg-sky-500/5">
              <label className="block text-xs font-bold text-sky-400 mb-1">
                অ্যাডমিন টেলিগ্রাম Direct Message (DM) লিংক:
              </label>
              <p className="text-2xs text-slate-400 mb-2">
                "websit ঢোকার সময় আমার টেলিগ্রাম এর dm করতে পারে সেইটা ও আমি অ্যাডমিন প্যানেল থেকে add করতে পারব"
              </p>
              <input
                type="text"
                value={tgDmLink}
                onChange={(e) => setTgDmLink(e.target.value)}
                placeholder="https://t.me/your_telegram_dm_username"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-sky-400"
              />
            </div>

            {/* Telegram Official Group/Channel Link */}
            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1">
                টেলিগ্রাম গ্রুপ / চ্যানেল লিংক:
              </label>
              <input
                type="text"
                value={tgGroupLink}
                onChange={(e) => setTgGroupLink(e.target.value)}
                placeholder="https://t.me/mrlapin_official"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
              />
            </div>

            {/* Toggle Popup Modal on/off */}
            <div className="flex items-center gap-3 pt-6">
              <input
                type="checkbox"
                id="tgToggle"
                checked={tgEnabled}
                onChange={(e) => setTgEnabled(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded cursor-pointer"
              />
              <label htmlFor="tgToggle" className="text-xs font-bold cursor-pointer">
                প্রবেশের সময় টেলিগ্রাম পপআপ প্রদর্শন করুন
              </label>
            </div>

            {/* Popup Title */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-400 mb-1">
                পপআপ টাইটেল:
              </label>
              <input
                type="text"
                value={tgTitle}
                onChange={(e) => setTgTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
              />
            </div>

            {/* Popup Description */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-400 mb-1">
                পপআপ বিবরণ:
              </label>
              <textarea
                rows={2}
                value={tgDesc}
                onChange={(e) => setTgDesc(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
              />
            </div>

            {/* Marquee Notice Bar Text */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-400 mb-1">
                স্ক্রলিং নোটিশ বার টেক্সট (Marquee Notice):
              </label>
              <textarea
                rows={2}
                value={marqueeText}
                onChange={(e) => setMarqueeText(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
              />
            </div>

          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center gap-2 shadow-md transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>সমস্ত সেটিংস সেভ করুন</span>
            </button>
          </div>
        </form>
      )}

      {/* ========================================================================= */}
      {/* TAB 6: BANNER SLIDER (1-4 ITEMS) & TOP NOTICE MARQUEE MANAGER             */}
      {/* ========================================================================= */}
      {activeAdminTab === 'banners' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Header */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-red-950 via-slate-900 to-amber-950 border border-amber-500/30 text-white shadow-lg space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-2xs font-extrabold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>ব্যানার স্লাইডার ও নোটিশ কন্ট্রোল রুম</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black">
              উপরে নোটিশ বার ও হোম স্লাইডার (১-৪) ম্যানেজমেন্ট
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
              "উপরে নোটিশ অপশনে যা লিখতে চান তা এখান থেকে এডিট করুন + নিচে 'কীভাবে প্যানেল কিনবেন' স্লাইডারে ১-৪টি জিনিস অ্যাড করুন, অটোমেটিক স্লাইড হবে এবং চাপ দিলেই লিংকে নিয়ে যাবে।"
            </p>
          </div>

          {/* SECTION 1: TOP NOTICE MARQUEE EDITOR */}
          <div
            className={`p-6 rounded-2xl border space-y-4 ${
              isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-amber-500 animate-bounce" />
                <div>
                  <h4 className="font-black text-sm text-slate-900 dark:text-white">
                    ১. উপরে নোটিশ অপশন এডিটর (Top Scrolling Notice Bar)
                  </h4>
                  <p className="text-3xs text-slate-400">
                    ওয়েবসাইটের সবার উপরে যে নোটিশটি স্ক্রল করে চলে সেটি এখান থেকে এডিট করুন
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  updateSettings({ noticeMarquee: marqueeText });
                  showToast('উপরে নোটিশ বার সফলভাবে সেভ হয়েছে!');
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>নোটিশ সেভ করুন</span>
              </button>
            </div>

            <div>
              <label className="block text-2xs font-bold text-slate-400 mb-1">
                নোটিশ বার টেক্সট (Notice Bar Content):
              </label>
              <textarea
                rows={3}
                value={marqueeText}
                onChange={(e) => setMarqueeText(e.target.value)}
                placeholder="Notice: লিখুন..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Live Preview of Scrolling Notice */}
            <div className="space-y-1 pt-1">
              <span className="text-3xs font-extrabold uppercase text-slate-400 flex items-center gap-1">
                <Eye className="w-3 h-3 text-blue-400" />
                <span>লাইভ প্রিভিউ (Live Marquee Preview):</span>
              </span>
              <div className="p-2.5 rounded-xl bg-indigo-950 text-indigo-200 border border-indigo-900 overflow-hidden flex items-center gap-2 text-xs">
                <span className="text-2xs font-bold px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-black shrink-0 uppercase">
                  ঘোষণা
                </span>
                <div className="flex-1 overflow-hidden whitespace-nowrap">
                  <div className="inline-block animate-marquee font-medium">
                    {marqueeText || 'নোটিশ খালি আছে...'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 2: HOME HERO CAROUSEL SLIDER (1 to 4 slides) */}
          <div
            className={`p-6 rounded-2xl border space-y-6 ${
              isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            {/* Section Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-red-500" />
                <div>
                  <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <span>২. হোম ব্যানার স্লাইডার কন্ট্রোল</span>
                    <span className="px-2 py-0.5 rounded-full bg-red-600/10 text-red-400 font-mono text-2xs border border-red-500/20">
                      {slidesList.length}/4 টি স্লাইড
                    </span>
                  </h4>
                  <p className="text-3xs text-slate-400">
                    এখানে ১-৪টি জিনিস অ্যাড করতে পারবেন, যা অটোমেটিক স্লাইড হবে এবং চাপ দিলে লিংকে নিয়ে যাবে
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAddSlide}
                  disabled={slidesList.length >= 4}
                  className={`px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer ${
                    slidesList.length >= 4
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-md'
                  }`}
                  title={slidesList.length >= 4 ? 'সর্বোচ্চ ৪টি স্লাইড সম্ভব' : 'নতুন স্লাইড যোগ করুন'}
                >
                  <Plus className="w-4 h-4" />
                  <span>নতুন স্লাইড যোগ করুন ({slidesList.length}/4)</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveBannerAndNotice}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>সব সেভ করুন</span>
                </button>
              </div>
            </div>

            {/* Slide Selector Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              {slidesList.map((s, idx) => (
                <button
                  key={s.id || idx}
                  type="button"
                  onClick={() => setActiveSlideEditIndex(idx)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer border ${
                    activeSlideEditIndex === idx
                      ? 'bg-red-600 text-white border-red-500 shadow-md shadow-red-600/30 ring-2 ring-red-400/50'
                      : isDarkMode
                      ? 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                  }`}
                >
                  <span>স্লাইড {idx + 1}</span>
                  <span className="text-3xs font-mono opacity-80 truncate max-w-[100px]">
                    {s.title}
                  </span>
                </button>
              ))}
            </div>

            {/* Currently Active Slide Editor Form */}
            {slidesList[activeSlideEditIndex] && (() => {
              const currentEditSlide = slidesList[activeSlideEditIndex];
              const slideIdx = activeSlideEditIndex;

              return (
                <div className="p-5 rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950/70 space-y-5">
                  
                  {/* Top Bar of Slide */}
                  <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-2xs font-extrabold px-2.5 py-1 rounded-lg bg-red-600 text-white">
                        Slide #{slideIdx + 1}
                      </span>
                      <strong className="text-sm font-black text-slate-900 dark:text-white">
                        {currentEditSlide.title || 'শিরোনাম নেই'}
                      </strong>
                    </div>

                    <div className="flex items-center gap-2">
                      {slidesList.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveSlide(slideIdx)}
                          className="px-3 py-1.5 rounded-xl bg-rose-600/10 hover:bg-rose-600/20 text-rose-500 border border-rose-500/30 text-2xs font-bold flex items-center gap-1 cursor-pointer transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>এই স্লাইডটি মুছুন</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Badge / Tag text */}
                    <div>
                      <label className="block text-2xs font-bold text-slate-400 mb-1">
                        স্লাইড ব্যাজ / ট্যাগ (Slide Tag):
                      </label>
                      <input
                        type="text"
                        value={currentEditSlide.badge || ''}
                        onChange={(e) => handleUpdateSlideField(slideIdx, 'badge', e.target.value)}
                        placeholder="e.g. OFFICIAL VIP PANEL 2026"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold text-slate-900 dark:text-white"
                      />
                    </div>

                    {/* Headline Title */}
                    <div>
                      <label className="block text-2xs font-bold text-slate-400 mb-1">
                        প্রধান শিরোনাম (Slide Title):
                      </label>
                      <input
                        type="text"
                        value={currentEditSlide.title}
                        onChange={(e) => handleUpdateSlideField(slideIdx, 'title', e.target.value)}
                        placeholder="e.g. কীভাবে প্যানেল কিনবেন?"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-black text-slate-900 dark:text-white"
                      />
                    </div>

                    {/* Subtitle / Description */}
                    <div className="sm:col-span-2">
                      <label className="block text-2xs font-bold text-slate-400 mb-1">
                        উপ-শিরোনাম / বিবরণ (Subtitle / Description):
                      </label>
                      <textarea
                        rows={2}
                        value={currentEditSlide.subtitle}
                        onChange={(e) => handleUpdateSlideField(slideIdx, 'subtitle', e.target.value)}
                        placeholder="e.g. নিরাপদ, দ্রুত ও বিশ্বস্ত সেবা · ইনস্ট্যান্ট অটোমেটেড ডেলিভারি ও ২৪/৭ ডেডিকেটেড সাপোর্ট"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                      />
                    </div>

                    {/* Button Text */}
                    <div>
                      <label className="block text-2xs font-bold text-slate-400 mb-1">
                        বাটন টেক্সট (Button Label):
                      </label>
                      <input
                        type="text"
                        value={currentEditSlide.buttonText}
                        onChange={(e) => handleUpdateSlideField(slideIdx, 'buttonText', e.target.value)}
                        placeholder="e.g. টিউটোরিয়াল দেখুন বা ভিডিও দেখুন"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold text-slate-900 dark:text-white"
                      />
                    </div>

                    {/* Link URL (The crucial feature: চাপ দিলেই link এ নিয়ে যাবে) */}
                    <div>
                      <label className="block text-2xs font-bold text-slate-400 mb-1 flex items-center gap-1">
                        <LinkIcon className="w-3.5 h-3.5 text-blue-400" />
                        <span>লিংক (চাপ দিলেই যেখানে যাবে - YouTube / Telegram / Web):</span>
                      </label>
                      <input
                        type="text"
                        value={currentEditSlide.link}
                        onChange={(e) => handleUpdateSlideField(slideIdx, 'link', e.target.value)}
                        placeholder="e.g. https://youtube.com/watch?v=... অথবা https://t.me/... অথবা #add_fund"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-blue-500 dark:text-blue-400"
                      />
                      <span className="text-3xs text-slate-400 mt-0.5 block">
                        টিপস: যেকোনো ইউটিউব ভিডিও লিংক, টেলিগ্রাম লিংক অথবা #add_fund দিতে পারেন।
                      </span>
                    </div>

                    {/* Logo / Image Edit (Gallery upload + URL input) */}
                    <div className="sm:col-span-2 p-4 rounded-xl border border-indigo-500/20 bg-indigo-500/5 space-y-3">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <label className="text-2xs font-bold text-indigo-400 flex items-center gap-1.5">
                          <ImageIcon className="w-4 h-4 text-indigo-400" />
                          <span>স্লাইডের লোগো বা ছবি (Logo / Image):</span>
                        </label>
                        <span className="text-3xs text-slate-400">
                          ছবি না দিলে ডিফল্ট লাল Play বাটন প্রদর্শিত হবে
                        </span>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center gap-4">
                        {/* Thumbnail Preview */}
                        <div className="w-20 h-20 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center overflow-hidden shrink-0 shadow-md">
                          {currentEditSlide.logoOrImage && currentEditSlide.logoOrImage.trim() !== '' ? (
                            <img
                              src={currentEditSlide.logoOrImage}
                              alt="Logo preview"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="text-center p-1 text-slate-500">
                              <Play className="w-6 h-6 mx-auto text-red-500 fill-red-500" />
                              <span className="text-3xs block mt-1">Play Button</span>
                            </div>
                          )}
                        </div>

                        {/* Upload & URL Controls */}
                        <div className="flex-1 w-full space-y-2">
                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                            {/* Hidden file input */}
                            <input
                              type="file"
                              ref={slideFileInputRef}
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => handleSlideGalleryUpload(e, slideIdx)}
                            />
                            <button
                              type="button"
                              onClick={() => slideFileInputRef.current?.click()}
                              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                            >
                              <Upload className="w-4 h-4" />
                              <span>📱 মোবাইল গ্যালারি থেকে লোগো/ছবি আপলোড করুন</span>
                            </button>

                            {currentEditSlide.logoOrImage && (
                              <button
                                type="button"
                                onClick={() => handleUpdateSlideField(slideIdx, 'logoOrImage', '')}
                                className="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs hover:bg-rose-600 hover:text-white transition cursor-pointer"
                              >
                                ছবি সরান (Reset to Play)
                              </button>
                            )}
                          </div>

                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={currentEditSlide.logoOrImage || ''}
                              onChange={(e) => handleUpdateSlideField(slideIdx, 'logoOrImage', e.target.value)}
                              placeholder="অথবা ছবির অনলাইন URL পেস্ট করুন: https://..."
                              className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Gradient Theme Picker */}
                    <div className="sm:col-span-2">
                      <label className="block text-2xs font-bold text-slate-400 mb-1.5">
                        স্লাইড ব্যাকগ্রাউন্ড কালার থিম:
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { name: 'Red Flame (ভিআইপি লাল)', value: 'from-red-950 via-slate-900 to-indigo-950' },
                          { name: 'Indigo Emerald (ক্যাশ/টাকা)', value: 'from-indigo-950 via-slate-900 to-emerald-950' },
                          { name: 'Blue Sky (টেলিগ্রাম)', value: 'from-blue-950 via-slate-900 to-purple-950' },
                          { name: 'Purple Night (স্পেশাল)', value: 'from-purple-950 via-slate-900 to-amber-950' }
                        ].map((g, gIdx) => (
                          <button
                            key={gIdx}
                            type="button"
                            onClick={() => handleUpdateSlideField(slideIdx, 'bgGradient', g.value)}
                            className={`px-3 py-1.5 rounded-xl text-2xs font-bold border transition cursor-pointer flex items-center gap-2 ${
                              (currentEditSlide.bgGradient || 'from-red-950 via-slate-900 to-indigo-950') === g.value
                                ? 'bg-blue-600 text-white border-blue-500 shadow-xs'
                                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                            }`}
                          >
                            <span className={`w-3 h-3 rounded-full bg-gradient-to-r ${g.value}`} />
                            <span>{g.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                  </div>

                  {/* Save single slide quick trigger */}
                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={handleSaveBannerAndNotice}
                      className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>এই স্লাইড ও নোটিশ সেভ করুন</span>
                    </button>
                  </div>

                </div>
              );
            })()}

          </div>

          {/* SECTION 3: WHATSAPP & HELPLINE PHONE NUMBER EDITOR (Matching IMG_1227) */}
          <div
            className={`p-6 rounded-2xl border space-y-5 ${
              isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <span>৩. হোয়াটসঅ্যাপ হেল্পলাইন নম্বর এডিটর</span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-2xs border border-emerald-500/20">
                      Help line [{supportPhoneText}]
                    </span>
                  </h4>
                  <p className="text-3xs text-slate-400">
                    হোম পেজের নিচে থাকা "Help line [+8801813913894]" বাটন এবং ভাসমান "সাহায্য লাগবে ?" বাটনের নম্বর এখান থেকে পরিবর্তন করতে পারবেন
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleSaveHelplineNumber}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer self-start sm:self-auto"
              >
                <Save className="w-4 h-4" />
                <span>হেল্পলাইন নম্বর সেভ করুন</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="block text-2xs font-bold text-slate-400">
                  ১. হেল্পলাইন ডিসপ্লে নম্বর (বাটনে যা দেখাবে):
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={supportPhoneText}
                    onChange={(e) => handleSupportPhoneChange(e.target.value)}
                    placeholder="+8801813913894"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-mono font-bold text-emerald-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <p className="text-3xs text-slate-400">
                  উদাহরণ: <span className="font-mono text-emerald-400">+8801813913894</span> (বাটনে হুবহু এই লেখাটি দেখাবে)
                </p>
              </div>

              <div className="space-y-1">
                <label className="block text-2xs font-bold text-slate-400">
                  ২. হোয়াটসঅ্যাপ ডিরেক্ট চ্যাট ডিজিট (লিংক):
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={whatsappPhone}
                    onChange={(e) => setWhatsappPhone(e.target.value)}
                    placeholder="8801813913894"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <p className="text-3xs text-slate-400">
                  কান্ট্রি কোড সহ শুধু সংখ্যা দিন (যেমন: <span className="font-mono">8801813913894</span>)। চাপ দিলে এই নম্বরে হোয়াটসঅ্যাপ খুলবে।
                </p>
              </div>
            </div>

            {/* Live Interactive Button Preview */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-3xs font-extrabold uppercase text-slate-400 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-blue-400" />
                  <span>হোম পেজ বাটন লাইভ প্রিভিউ (Live Preview):</span>
                </span>
                <span className="text-3xs font-bold text-emerald-500">
                  Active & Clickable
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <a
                  href={`https://wa.me/${whatsappPhone}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Help line [{supportPhoneText}]</span>
                </a>

                <div className="px-3.5 py-2 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm">
                  <Phone className="w-3.5 h-3.5" />
                  <span>সাহায্য লাগবে ?</span>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 4: LATEST ORDERS LIVE FEED & 1-MINUTE SIMULATOR (Matching IMG_1226) */}
          <div
            className={`p-6 rounded-2xl border space-y-5 ${
              isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <span>৪. সর্বশেষ অর্ডার লাইভ ফিড কন্ট্রোল (Latest Orders)</span>
                    <span className="px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 font-mono text-2xs border border-blue-500/20">
                      {recentOrders.length} টি অর্ডার
                    </span>
                  </h4>
                  <p className="text-3xs text-slate-400">
                    আসল কোনো অর্ডার হলে সাথে সাথে যুক্ত হবে। এছাড়া প্রতি ১ মিনিট পর পর অটোমেটিক নতুন ফেক গেমার নামের অর্ডার তৈরি হবে।
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    triggerSimulatedOrder();
                    showToast('১টি নতুন সিমুলেটেড অর্ডার লাইভ ফিডে যুক্ত করা হয়েছে!');
                  }}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>এখনই ১টি ফেক অর্ডার যুক্ত করুন</span>
                </button>

                {recentOrders.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('আপনি কি সব সাম্প্রতিক অর্ডার ফিড খালি করতে চান?')) {
                        clearRecentOrders();
                        showToast('সাম্প্রতিক অর্ডার ফিড খালি করা হয়েছে!');
                      }
                    }}
                    className="px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-bold text-xs border border-rose-500/20 transition cursor-pointer"
                  >
                    ফিড ক্লিয়ার
                  </button>
                )}
              </div>
            </div>

            {/* Feature Note Banner */}
            <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-900/50 flex items-start gap-2.5 text-xs text-indigo-200">
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-white text-2xs mb-0.5">১ মিনিট অটো-অর্ডার সিমুলেটর সক্রিয় আছে:</p>
                <p className="text-3xs text-indigo-300">
                  • কোনো কাস্টমার প্যানেল ক্রয় করলে তৎক্ষণাৎ তার নাম ও প্যাকেজ লাইভ ফিডে দেখায়।<br />
                  • ক্রয় করার ঠিক ১ মিনিট (60s) পর স্বয়ংক্রিয়ভাবে আরও একটি গেমার নামের ফেক অর্ডার যুক্ত হয়।<br />
                  • এছাড়া ব্যাকগ্রাউন্ডে নিয়মিত প্রতি ৬০ সেকেন্ড পরপর লাইভ অর্ডার ফিড আপডেট হতে থাকে।
                </p>
              </div>
            </div>

            {/* Recent Orders List in Admin Panel */}
            <div className="space-y-2">
              <span className="text-2xs font-extrabold text-slate-400 uppercase tracking-wider block">
                বর্তমান ফিডের অর্ডার তালিকা ({recentOrders.length}):
              </span>

              <div className="divide-y divide-slate-100 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800 max-h-60 overflow-y-auto scrollbar-thin bg-slate-50/50 dark:bg-slate-950/50">
                {recentOrders.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-500">
                    কোনো অর্ডার নেই। উপরের বোতামে চাপ দিয়ে সিমুলেটেড অর্ডার যোগ করুন।
                  </div>
                ) : (
                  recentOrders.map((ord, idx) => (
                    <div key={ord.id || idx} className="p-2.5 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className={`w-7 h-7 rounded-full ${ord.avatarBg || 'bg-blue-600'} text-white font-bold text-2xs flex items-center justify-center shrink-0`}>
                          {ord.user ? ord.user.charAt(0).toUpperCase() : 'G'}
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 dark:text-white truncate">
                            {ord.user}
                          </div>
                          <div className="text-3xs text-slate-400 truncate">
                            {ord.product}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="font-mono font-bold text-amber-500 text-xs">
                          {ord.price}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            deleteRecentOrder(ord.id);
                            showToast('অর্ডারটি ফিড থেকে ডিলিট করা হয়েছে');
                          }}
                          className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition cursor-pointer"
                          title="ফিড থেকে ডিলিট করুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 7: NETLIFY & GITHUB PUBLISHING SUITE (DIRECT DOWNLOADS & TUTORIAL)   */}
      {/* ========================================================================= */}
      {activeAdminTab === 'publish' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Hero Banner */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/30 text-white space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-2xs font-extrabold uppercase bg-emerald-600 text-white shadow-xs">
                ১০০% ফ্রি হোস্টিং · ০ টাকা খরচ
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-2xs font-bold bg-white/10 text-emerald-300 border border-white/20">
                Netlify & GitHub Ready
              </span>
            </div>
            <h3 className="text-xl font-black">
              আপনার প্রজেক্ট Netlify ও GitHub-এ ফ্রিতে পাবলিশ করুন
            </h3>
            <p className="text-xs text-emerald-200/80 leading-relaxed max-w-2xl">
              আপনার অনুরোধ অনুযায়ী সম্পূর্ণ প্রজেক্টের ফাইল তৈরি করে জিপ আকারে দেওয়া হয়েছে। নিচে দেওয়া বাটনে চাপ দিয়ে যেকোনো একটি জিপ ফাইল ডাউনলোড করে আপনি খুব সহজেই নেটলিফাই কিংবা গিটহাবে সম্পূর্ণ ফ্রিতে লাইভ করতে পারবেন।
            </p>
          </div>

          {/* 2 Main Download Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* OPTION 1: NETLIFY DROP (EASIEST - NO CODING) */}
            <div
              className={`p-6 rounded-2xl border flex flex-col justify-between space-y-4 shadow-sm ${
                isDarkMode ? 'bg-slate-900 border-emerald-500/30' : 'bg-white border-emerald-500/30'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center font-black">
                    ⚡
                  </div>
                  <span className="text-2xs font-extrabold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    সবচেয়ে সহজ (১ মিনিটে লাইভ)
                  </span>
                </div>

                <div>
                  <h4 className="font-black text-base text-slate-900 dark:text-white">
                    ১. Netlify Ready জিপ ফাইল
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    সম্পূর্ণ প্রোডাকশন বিল্ড এবং Netlify-এর জন্য প্রয়োজনীয় <code className="text-emerald-400 font-mono">_redirects</code> ফাইল সহ প্রস্তুত করা আছে।
                  </p>
                </div>

                {/* Steps List */}
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-xs space-y-2 text-slate-600 dark:text-slate-300">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-3xs flex items-center justify-center shrink-0 mt-0.5">1</span>
                    <span>নিচের বাটনে চাপ দিয়ে জিপ ফাইলটি ডাউনলোড করুন এবং আনজিপ করুন।</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-3xs flex items-center justify-center shrink-0 mt-0.5">2</span>
                    <span>ব্রাউজারে <strong>app.netlify.com/drop</strong> ওপেন করুন (একটি ফ্রি একাউন্ট খুলুন)।</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-3xs flex items-center justify-center shrink-0 mt-0.5">3</span>
                    <span>আনজিপ করা ফোল্ডারটি সেখানে ড্রপ করুন — সাথে সাথে সাইট লাইভ হয়ে যাবে!</span>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <a
                  href="/mrlapin-netlify-ready.zip"
                  download="mrlapin-netlify-ready.zip"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>Netlify Ready ZIP ডাউনলোড করুন</span>
                </a>
              </div>
            </div>

            {/* OPTION 2: GITHUB SOURCE CODE (FOR DEVELOPERS & AUTO DEPLOY) */}
            <div
              className={`p-6 rounded-2xl border flex flex-col justify-between space-y-4 shadow-sm ${
                isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center font-black">
                    🐙
                  </div>
                  <span className="text-2xs font-extrabold px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30">
                    GitHub ও Vercel সাপোর্ট
                  </span>
                </div>

                <div>
                  <h4 className="font-black text-base text-slate-900 dark:text-white">
                    ২. সম্পূর্ণ সোর্স কোড জিপ (Source Code)
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    সম্পূর্ণ React + Vite + Tailwind কোড, <code className="text-blue-400 font-mono">netlify.toml</code> ও <code className="text-blue-400 font-mono">vercel.json</code> সহ।
                  </p>
                </div>

                {/* Steps List */}
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-xs space-y-2 text-slate-600 dark:text-slate-300">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold text-3xs flex items-center justify-center shrink-0 mt-0.5">1</span>
                    <span>সোর্স কোডের জিপ ফাইলটি ডাউনলোড করুন।</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold text-3xs flex items-center justify-center shrink-0 mt-0.5">2</span>
                    <span>GitHub-এ একটি নতুন Repository তৈরি করে কোডগুলো পুশ করুন।</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold text-3xs flex items-center justify-center shrink-0 mt-0.5">3</span>
                    <span>Netlify বা Vercel-এ "New Site from Git" দিয়ে কানেক্ট করুন।</span>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <a
                  href="/mrlapin-source-code.zip"
                  download="mrlapin-source-code.zip"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>GitHub Source Code ZIP ডাউনলোড</span>
                </a>
              </div>
            </div>

          </div>

          {/* Netlify Drop Quick Link Helper */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-xl">🌐</span>
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">Netlify Drop অফিসিয়াল লিংক:</span>
                <span className="text-2xs text-slate-400">https://app.netlify.com/drop</span>
              </div>
            </div>
            <a
              href="https://app.netlify.com/drop"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 transition self-start sm:self-auto cursor-pointer"
            >
              <span>Netlify Drop সাইটে যান</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>
      )}

    </div>
  );
};
