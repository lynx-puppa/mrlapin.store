import React from 'react';
import { useStore } from '../context/StoreContext';
import { Sun, Moon, Wallet, Shield, Megaphone, Send } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    language,
    toggleLanguage,
    t,
    isDarkMode,
    setIsDarkMode,
    user,
    isAdmin,
    isLoggedIn,
    setActiveTab,
    activeTab,
    settings,
    setShowTelegramPopup,
    setShowAuthModal,
    setAuthModalInitialTab
  } = useStore();

  return (
    <header className="sticky top-0 z-40">
      {/* Main Top Navigation */}
      <div
        className={`border-b transition-colors ${
          isDarkMode
            ? 'bg-slate-900/95 border-slate-800 text-white backdrop-blur-md'
            : 'bg-white/95 border-slate-200 text-slate-900 backdrop-blur-md'
        }`}
      >
        <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 sm:h-16 gap-1 sm:gap-3">
            
            {/* Brand Logo Zone */}
            <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
              <button
                onClick={() => setActiveTab('home')}
                className="flex items-center gap-1.5 sm:gap-2 group text-left cursor-pointer"
              >
                <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-lg sm:rounded-xl bg-gradient-to-tr from-amber-500 via-red-500 to-indigo-600 flex items-center justify-center font-black text-sm sm:text-lg text-white shadow-xs group-hover:scale-105 transition-transform">
                  🐰
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-black text-xs sm:text-lg tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-red-400 to-indigo-400 uppercase">
                      {settings.siteName}
                    </span>
                    <span className="text-3xs font-extrabold px-1 py-0.2 rounded bg-amber-500/10 text-amber-500 border border-amber-500/30">
                      VIP
                    </span>
                  </div>
                  <span className="hidden sm:block text-2xs text-slate-400 -mt-1 tracking-widest font-mono">
                    PANEL.COM
                  </span>
                </div>
              </button>
            </div>

            {/* Right Action Controls */}
            <div className="flex items-center gap-1 sm:gap-2 shrink-0">

              {/* Language On/Off Toggle Switch (বাং / EN) */}
              <button
                type="button"
                onClick={toggleLanguage}
                className={`relative inline-flex items-center h-7 sm:h-8 px-1 rounded-full border transition-all cursor-pointer ${
                  isDarkMode
                    ? 'bg-slate-800/90 border-slate-700 text-slate-300 hover:border-slate-600'
                    : 'bg-slate-100 border-slate-300 text-slate-700 hover:border-slate-400'
                }`}
                title={language === 'bn' ? 'Switch to English' : 'বাংলা ভাষায় পরিবর্তন করুন'}
                aria-label="Toggle Language"
              >
                <div className="flex items-center text-3xs font-black tracking-tight select-none gap-0.5">
                  <span
                    className={`px-1 sm:px-1.5 py-0.5 rounded-full transition-all duration-150 ${
                      language === 'bn'
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs font-black'
                        : 'text-slate-400 opacity-60'
                    }`}
                  >
                    বাং
                  </span>
                  <span
                    className={`px-1 sm:px-1.5 py-0.5 rounded-full transition-all duration-150 ${
                      language === 'en'
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs font-black'
                        : 'text-slate-400 opacity-60'
                    }`}
                  >
                    EN
                  </span>
                </div>
              </button>
              
              {/* Day / Night Switch */}
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className={`w-7 h-7 sm:w-8 sm:h-8 p-1 sm:p-1.5 rounded-lg sm:rounded-xl border flex items-center justify-center transition-all cursor-pointer ${
                  isDarkMode
                    ? 'bg-slate-800 border-slate-700 text-amber-400 hover:bg-slate-700'
                    : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                }`}
                title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {isDarkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              </button>

              {/* Auth Controls matching IMG_1243 */}
              {!isLoggedIn ? (
                <>
                  <button
                    onClick={() => {
                      setAuthModalInitialTab('login');
                      setShowAuthModal(true);
                    }}
                    className="h-7 sm:h-8 px-2 sm:px-3 rounded-lg sm:rounded-xl border border-red-500 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 font-black text-2xs sm:text-xs transition active:scale-95 cursor-pointer uppercase tracking-wider"
                  >
                    LOGIN
                  </button>
                  <button
                    onClick={() => {
                      setAuthModalInitialTab('register');
                      setShowAuthModal(true);
                    }}
                    className="h-7 sm:h-8 px-2 sm:px-3 rounded-lg sm:rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-2xs sm:text-xs transition active:scale-95 cursor-pointer uppercase tracking-wider shadow-xs shadow-red-600/30"
                  >
                    REGISTER
                  </button>
                </>
              ) : (
                <>
                  {/* Balance Pill Button */}
                  <button
                    onClick={() => setActiveTab('add_fund')}
                    className="h-7 sm:h-8 px-2 sm:px-3 rounded-lg sm:rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs flex items-center gap-1 shadow-xs transition-transform active:scale-95 cursor-pointer"
                    title="Add Money / View Balance"
                  >
                    <Wallet className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                    <span className="font-mono text-2xs sm:text-xs font-bold">৳{user.balance}</span>
                  </button>

                  {/* User Profile Avatar Button */}
                  <button
                    onClick={() => setActiveTab('account')}
                    className="relative w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-gradient-to-tr from-amber-500 to-orange-600 text-white font-bold text-xs sm:text-sm flex items-center justify-center shadow-xs hover:ring-2 hover:ring-amber-400 transition cursor-pointer"
                    title={`Account: ${user.name} (${user.email})`}
                  >
                    {user.authProvider === 'telegram' ? (
                      <span className="text-xs">✈️</span>
                    ) : user.authProvider === 'google' ? (
                      <span>{user.name.charAt(0).toUpperCase()}</span>
                    ) : (
                      user.name.charAt(0).toUpperCase()
                    )}
                    {user.authProvider && (
                      <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-white dark:border-slate-900 bg-emerald-500" />
                    )}
                  </button>

                  {/* Admin Panel Direct Entry Button (Restricted to verified admin) */}
                  {isAdmin && (
                    <button
                      onClick={() => setActiveTab(activeTab === 'admin' ? 'home' : 'admin')}
                      className={`h-7 sm:h-8 px-2 sm:px-3 rounded-lg sm:rounded-xl font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                        activeTab === 'admin'
                          ? 'bg-red-600 text-white shadow-md shadow-red-600/30 ring-2 ring-red-400'
                          : isDarkMode
                          ? 'bg-slate-800 hover:bg-slate-700 text-red-400 border border-red-500/30'
                          : 'bg-red-50 hover:bg-red-100 text-red-600 border border-red-200'
                      }`}
                      title="Admin Control Room"
                    >
                      <Shield className="w-3.5 h-3.5 text-red-500" />
                      <span className="hidden sm:inline">অ্যাডমিন</span>
                    </button>
                  )}
                </>
              )}

            </div>

          </div>
        </div>
      </div>

      {/* Marquee Notice Bar with Horn Icon & Telegram Quick DM */}
      <div
        className={`px-3 py-1.5 border-b text-xs flex items-center gap-3 overflow-hidden ${
          isDarkMode
            ? 'bg-indigo-950/70 border-indigo-900/60 text-indigo-200'
            : 'bg-indigo-50 border-indigo-100 text-indigo-900'
        }`}
      >
        <div className="flex items-center gap-1 font-bold shrink-0 text-amber-500">
          <Megaphone className="w-3.5 h-3.5 animate-bounce" />
          <span className="text-2xs uppercase tracking-wider hidden sm:inline">ঘোষণা</span>
        </div>

        {/* Scrolling text */}
        <div className="flex-1 overflow-hidden whitespace-nowrap">
          <div className="inline-block animate-marquee font-medium">
            {settings.noticeMarquee}
          </div>
        </div>

        {/* Quick Telegram popup trigger */}
        <button
          onClick={() => setShowTelegramPopup(true)}
          className="shrink-0 px-2 py-0.5 rounded bg-sky-500 hover:bg-sky-600 text-white text-2xs font-bold flex items-center gap-1 cursor-pointer transition"
          title="Open Telegram Community"
        >
          <Send className="w-2.5 h-2.5" />
          <span>Telegram</span>
        </button>
      </div>
    </header>
  );
};
