import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { TelegramModal } from './components/TelegramModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { HomeView } from './components/HomeView';
import { AddFundView } from './components/AddFundView';
import { MyOrdersView } from './components/MyOrdersView';
import { MyCodesView } from './components/MyCodesView';
import { AccountView } from './components/AccountView';
import { AdminPanelView } from './components/AdminPanelView';
import { AuthModal } from './components/AuthModal';

const MainContent: React.FC = () => {
  const { activeTab, isDarkMode, isAdmin, loginWithEmail, setActiveTab } = useStore();

  return (
    <div
      className={`min-h-screen w-full max-w-full overflow-x-hidden transition-colors duration-200 ${
        isDarkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Top Header */}
      <Header />

      {/* Main View Container */}
      <main className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-4 sm:py-5 w-full overflow-x-hidden">
        {activeTab === 'home' && <HomeView />}
        {activeTab === 'add_fund' && <AddFundView />}
        {activeTab === 'my_orders' && <MyOrdersView />}
        {activeTab === 'my_codes' && <MyCodesView />}
        {activeTab === 'account' && <AccountView />}
        {activeTab === 'admin' && (
          isAdmin ? (
            <AdminPanelView />
          ) : (
            <div className="max-w-md mx-auto p-8 rounded-2xl border border-red-500/30 bg-white dark:bg-slate-900 text-center space-y-4 shadow-xl my-12">
              <div className="w-16 h-16 mx-auto rounded-full bg-red-600/10 text-red-500 border border-red-500/20 flex items-center justify-center">
                <span className="text-2xl font-black">🔒</span>
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                অ্যাডমিন এক্সেস সংরক্ষিত
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                এই প্যানেলটি শুধুমাত্র অনুমোদিত প্রধান অ্যাডমিনের জন্য সংরক্ষিত। আপনার এই বিভাগে প্রবেশের অনুমতি নেই।
              </p>
              <div className="pt-2">
                <button
                  onClick={() => setActiveTab('home')}
                  className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
                >
                  হোমে ফিরে যান
                </button>
              </div>
            </div>
          )
        )}
      </main>

      {/* Telegram Entry Popup Modal */}
      <TelegramModal />

      {/* Product Recharge & Detail Modal */}
      <ProductDetailModal />

      {/* Login & Register Auth Modal */}
      <AuthModal />

      {/* 5-Tab Fixed Bottom Bar */}
      <BottomNav />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <MainContent />
    </StoreProvider>
  );
}
