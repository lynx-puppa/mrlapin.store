import { AppLanguage } from '../types';

export const TRANSLATIONS = {
  // Navigation
  nav_home: { bn: 'হোম', en: 'Home' },
  nav_add_fund: { bn: 'এড ফান্ড', en: 'Add Fund' },
  nav_my_orders: { bn: 'অর্ডারসমূহ', en: 'My Orders' },
  nav_my_codes: { bn: 'আমার কোড', en: 'My Codes' },
  nav_account: { bn: 'একাউন্ট', en: 'Account' },
  nav_admin: { bn: 'এডমিন', en: 'Admin' },
  need_help: { bn: 'সাহায্য লাগবে ?', en: 'Need Help?' },

  // Header
  wallet_balance: { bn: 'ওয়ালেট ব্যালেন্স', en: 'Wallet Balance' },
  light_mode: { bn: 'লাইট মোড', en: 'Light Mode' },
  dark_mode: { bn: 'ডার্ক মোড', en: 'Dark Mode' },

  // Categories
  cat_all: { bn: 'সব প্যানেল', en: 'ALL' },
  cat_non_root: { bn: 'নন রুট', en: 'NON ROOT' },
  cat_root: { bn: 'রুট', en: 'ROOT' },
  cat_iphone: { bn: 'আইফোন (iOS)', en: 'IPHONE' },
  cat_pc: { bn: 'পিসি (PC)', en: 'PC' },

  // Product Actions
  buy_now: { bn: 'প্যানেল কিনুন', en: 'Buy Panel' },
  view_details: { bn: 'বিস্তারিত দেখুন', en: 'View Details' },
  download_app: { bn: 'অ্যাপ ডাউনলোড', en: 'Download App' },
  watch_tutorial: { bn: 'টিউটোরিয়াল দেখুন', en: 'Watch Tutorial' },
  select_package: { bn: 'প্যাকেজ নির্বাচন করুন', en: 'Select Package' },
  confirm_purchase: { bn: 'ক্রয় নিশ্চিত করুন', en: 'Confirm Purchase' },
  purchase_success: { bn: 'ক্রয় সম্পন্ন হয়েছে!', en: 'Purchase Completed!' },

  // Product Status Badges
  status_online: { bn: 'সক্রিয় ও ইনস্ট্যান্ট ডেলিভারি', en: 'ONLINE & INSTANT' },
  status_out_of_stock: { bn: 'স্টক শেষ', en: 'OUT OF STOCK' },
  status_maintenance: { bn: 'মেইনটেন্যান্স চলছে', en: 'UNDER MAINTENANCE' },
  status_not_available: { bn: 'এখন পাওয়া যাচ্ছে না', en: 'NOT AVAILABLE' },

  // Latest Orders
  latest_orders: { bn: 'সর্বশেষ অর্ডার', en: 'Latest Orders' },
  live_feed: { bn: 'লাইভ ফিড', en: 'Live Feed' },
  completed: { bn: 'সম্পন্ন', en: 'Completed' },
  verified: { bn: 'যাচাইকৃত', en: 'Verified' },

  // Support & Footer
  stay_connected: { bn: 'যুক্ত থাকুন', en: 'STAY CONNECTED' },
  support_msg: {
    bn: 'কোনো সমস্যায় পড়লে হোয়াটসঅ্যাপ এ যোগাযোগ করবেন। তাহলে দ্রুত সমাধান পেয়ে যাবেন।',
    en: 'For any issues, please reach out via WhatsApp for fast and dedicated support.'
  },
  helpline_prefix: { bn: 'হেল্পলাইন', en: 'Help line' },
  copyright: { bn: 'সর্বস্বত্ব সংরক্ষিত', en: 'All Rights Reserved' },

  // Notice Bar
  announcement: { bn: 'ঘোষণা', en: 'NOTICE' },

  // Quantity & Pricing
  quantity_label: { bn: 'পরিমাণ (টি)', en: 'Quantity' },
  total_price: { bn: 'মোট মূল্য', en: 'Total Price' },
  balance_remaining: { bn: 'অবশিষ্ট ব্যালেন্স', en: 'Remaining Balance' },
  insufficient_balance: { bn: 'পর্যাপ্ত ব্যালেন্স নেই! প্রথমে ব্যালেন্স এড করুন।', en: 'Insufficient balance! Please add funds first.' },

  // Codes & Orders view
  my_keys: { bn: 'আপনার কেনা লাইসেন্স কীসমূহ', en: 'My Purchased License Keys' },
  copy_key: { bn: 'কী কপি করুন', en: 'Copy Key' },
  copied: { bn: 'কপি হয়েছে!', en: 'Copied!' },
  order_history: { bn: 'অর্ডারের বিবরণ', en: 'Order History' },
  serial_no: { bn: 'সিরিয়াল নং', en: 'Serial No' },
  date: { bn: 'তারিখ', en: 'Date' }
} as const;

export type TranslationKey = keyof typeof TRANSLATIONS;

export const getTranslation = (key: TranslationKey, lang: AppLanguage): string => {
  const item = TRANSLATIONS[key];
  if (!item) return key;
  return item[lang] || item['en'] || key;
};
