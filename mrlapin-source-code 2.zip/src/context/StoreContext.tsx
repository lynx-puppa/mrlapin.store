import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  PackageTier,
  PaymentGatewayConfig,
  DepositRecord,
  OrderRecord,
  UserCodeRecord,
  SiteSettings,
  UserProfile,
  RegisteredAccount,
  ProductStatus,
  RecentOrderItem,
  HeroSlideItem,
  AppLanguage
} from '../types';
import { getTranslation, TranslationKey } from '../utils/translations';
import {
  sanitizeInput,
  hashPassword,
  checkRateLimit,
  recordFailedLogin,
  clearRateLimit,
  generateSessionToken,
  verifySessionAdminIntegrity,
  isValidEmail
} from '../utils/security';
import {
  INITIAL_PRODUCTS,
  INITIAL_GATEWAYS,
  INITIAL_DEPOSITS,
  INITIAL_ORDERS,
  INITIAL_CODES,
  INITIAL_SITE_SETTINGS,
  INITIAL_USER,
  INITIAL_RECENT_ORDERS
} from '../data/initialData';

interface StoreContextType {
  // Language (BN / EN)
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  toggleLanguage: () => void;
  t: (key: TranslationKey) => string;

  // Navigation & Theme
  activeTab: 'home' | 'add_fund' | 'my_orders' | 'my_codes' | 'account' | 'admin';
  setActiveTab: (tab: 'home' | 'add_fund' | 'my_orders' | 'my_codes' | 'account' | 'admin') => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  
  // Selected Product for Purchasing
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;

  // Telegram Popup Modal
  showTelegramPopup: boolean;
  setShowTelegramPopup: (val: boolean) => void;

  // Auth Modal (Login / Register Popup)
  showAuthModal: boolean;
  setShowAuthModal: (val: boolean) => void;
  authModalInitialTab: 'login' | 'register';
  setAuthModalInitialTab: (tab: 'login' | 'register') => void;

  // Data
  user: UserProfile;
  products: Product[];
  gateways: PaymentGatewayConfig[];
  deposits: DepositRecord[];
  orders: OrderRecord[];
  codes: UserCodeRecord[];
  settings: SiteSettings;
  recentOrders: RecentOrderItem[];

  // Auth & Roles
  isAdmin: boolean;
  adminEmail: string;
  isLoggedIn: boolean;
  loginWithEmail: (email: string, name?: string) => void;
  loginWithCredentials: (email: string, password: string) => { success: boolean; message: string; remainingSeconds?: number };
  loginWithGoogle: (customAccount?: { email: string; name: string; avatarUrl?: string }) => { success: boolean; message: string };
  loginWithTelegram: (tgData: { username: string; firstName: string; id?: string }) => { success: boolean; message: string };
  registerAccount: (data: { name: string; email: string; phone: string; password: string }) => { success: boolean; message: string };
  resetPasswordWithPin: (email: string, pin: string, newPassword: string) => { success: boolean; message: string };
  logout: () => void;

  // User Actions
  submitDeposit: (gatewayId: string, amount: number, senderNumber: string, trxId: string) => boolean;
  purchasePackage: (product: Product, packageTierId: string, quantity: number) => { success: boolean; message: string; key?: string; keys?: string[] };
  updateUserProfile: (data: Partial<UserProfile>) => void;

  // Admin Actions
  updateSettings: (newSettings: Partial<SiteSettings>) => void;
  updateHeroSlides: (slides: HeroSlideItem[]) => void;
  updateGatewayNumber: (gatewayId: string, newNumberOrAddress: string, instructions?: string, isActive?: boolean) => void;
  updateGatewayDetails: (gatewayId: string, updatedGateway: Partial<PaymentGatewayConfig>) => void;
  addNewGateway: (newGateway: PaymentGatewayConfig) => void;
  deleteGateway: (gatewayId: string) => void;
  updateProductStatus: (productId: string, status: ProductStatus, customBadge?: string) => void;
  updateProductDetails: (productId: string, data: Partial<Product>) => void;
  editProductPackage: (productId: string, packageId: string, updatedPackage: Partial<PackageTier>) => void;
  addPackageToProduct: (productId: string, newPackage: PackageTier) => void;
  deletePackageFromProduct: (productId: string, packageId: string) => void;
  addKeysToPackageTier: (productId: string, packageId: string, keys: string[]) => void;
  removeKeyFromPackageTier: (productId: string, packageId: string, keyIndex: number) => void;
  clearPackageKeys: (productId: string, packageId: string) => void;
  addNewProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  approveDeposit: (depositId: string) => void;
  rejectDeposit: (depositId: string, note?: string) => void;
  manualAddBalance: (targetUserId: string, amount: number, note?: string) => void;
  addRecentOrder: (order: RecentOrderItem) => void;
  deleteRecentOrder: (orderId: string) => void;
  clearRecentOrders: () => void;
  triggerSimulatedOrder: () => void;
  updateOrderStatus: (orderId: string, status: OrderRecord['status']) => void;
  editingProductId: string | null;
  setEditingProductId: (id: string | null) => void;
  resetToDefaults: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<'home' | 'add_fund' | 'my_orders' | 'my_codes' | 'account' | 'admin'>('home');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('mrlapin_dark_mode');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [language, setLanguage] = useState<AppLanguage>(() => {
    const saved = localStorage.getItem('mrlapin_language');
    return saved === 'en' || saved === 'bn' ? saved : 'bn';
  });

  useEffect(() => {
    localStorage.setItem('mrlapin_language', language);
  }, [language]);

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === 'bn' ? 'en' : 'bn'));
  };

  const t = (key: TranslationKey) => getTranslation(key, language);

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showTelegramPopup, setShowTelegramPopup] = useState<boolean>(false);

  // Persistent States
  const ADMIN_EMAIL = 'higunff@gmail.com';

  // Version Wipe to remove all dummy records and start completely clean
  const CLEAN_STORE_VERSION = 'v5_clean_zero_data';
  if (typeof window !== 'undefined') {
    const currentVersion = localStorage.getItem('mrlapin_store_version');
    if (currentVersion !== CLEAN_STORE_VERSION) {
      localStorage.removeItem('mrlapin_user');
      localStorage.removeItem('mrlapin_deposits');
      localStorage.removeItem('mrlapin_orders');
      localStorage.removeItem('mrlapin_codes');
      localStorage.setItem('mrlapin_store_version', CLEAN_STORE_VERSION);
    }
  }

  // Auth Modal State: Auto-prompt when not logged in
  const [showAuthModal, setShowAuthModal] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const saved = localStorage.getItem('mrlapin_user');
    if (!saved) return true; // Show login prompt right when entering site!
    try {
      const parsed = JSON.parse(saved);
      return !parsed || !parsed.isLoggedIn || !parsed.email;
    } catch {
      return true;
    }
  });
  const [authModalInitialTab, setAuthModalInitialTab] = useState<'login' | 'register'>('login');

  // Persistent Registered Accounts
  const [registeredAccounts, setRegisteredAccounts] = useState<RegisteredAccount[]>(() => {
    const saved = localStorage.getItem('mrlapin_registered_accounts');
    if (!saved) {
      const initialAccounts: RegisteredAccount[] = [
        {
          id: 'acc_admin',
          name: 'Higun Admin',
          email: ADMIN_EMAIL,
          phone: '018813913894',
          passwordHash: hashPassword('Admin@1234'),
          supportPin: '5433',
          authProvider: 'email',
          createdAt: new Date().toISOString()
        }
      ];
      localStorage.setItem('mrlapin_registered_accounts', JSON.stringify(initialAccounts));
      return initialAccounts;
    }
    try {
      return JSON.parse(saved);
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('mrlapin_registered_accounts', JSON.stringify(registeredAccounts));
  }, [registeredAccounts]);

  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('mrlapin_user');
    if (!saved) return INITIAL_USER;
    try {
      const parsed = JSON.parse(saved);
      if (!parsed || !parsed.isLoggedIn || !parsed.email) {
        return INITIAL_USER;
      }
      return parsed;
    } catch {
      return INITIAL_USER;
    }
  });

  const isLoggedIn = Boolean(user?.isLoggedIn && user?.email);
  const isAdmin = Boolean(
    isLoggedIn &&
    (user?.email || '').toLowerCase().trim() === ADMIN_EMAIL
  );

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('mrlapin_products');
    if (!saved) return INITIAL_PRODUCTS;
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((p: Product) => ({
          ...p,
          image: p.image && typeof p.image === 'string' && p.image.trim() !== ''
            ? p.image
            : 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'
        }));
      }
      return INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [gateways, setGateways] = useState<PaymentGatewayConfig[]>(() => {
    const saved = localStorage.getItem('mrlapin_gateways');
    return saved ? JSON.parse(saved) : INITIAL_GATEWAYS;
  });

  const [deposits, setDeposits] = useState<DepositRecord[]>(() => {
    const saved = localStorage.getItem('mrlapin_deposits');
    return saved ? JSON.parse(saved) : INITIAL_DEPOSITS;
  });

  const [orders, setOrders] = useState<OrderRecord[]>(() => {
    const saved = localStorage.getItem('mrlapin_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [codes, setCodes] = useState<UserCodeRecord[]>(() => {
    const saved = localStorage.getItem('mrlapin_codes');
    return saved ? JSON.parse(saved) : INITIAL_CODES;
  });

  const [settings, setSettings] = useState<SiteSettings>(() => {
    const saved = localStorage.getItem('mrlapin_settings');
    if (!saved) return INITIAL_SITE_SETTINGS;
    try {
      const parsed = JSON.parse(saved);
      return {
        ...INITIAL_SITE_SETTINGS,
        ...parsed,
        heroSlides: Array.isArray(parsed.heroSlides) && parsed.heroSlides.length > 0
          ? parsed.heroSlides
          : INITIAL_SITE_SETTINGS.heroSlides
      };
    } catch {
      return INITIAL_SITE_SETTINGS;
    }
  });

  const [recentOrders, setRecentOrders] = useState<RecentOrderItem[]>(() => {
    const saved = localStorage.getItem('mrlapin_recent_orders');
    return saved ? JSON.parse(saved) : INITIAL_RECENT_ORDERS;
  });

  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('mrlapin_dark_mode', JSON.stringify(isDarkMode));
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem('mrlapin_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('mrlapin_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('mrlapin_gateways', JSON.stringify(gateways));
  }, [gateways]);

  useEffect(() => {
    localStorage.setItem('mrlapin_deposits', JSON.stringify(deposits));
  }, [deposits]);

  useEffect(() => {
    localStorage.setItem('mrlapin_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('mrlapin_codes', JSON.stringify(codes));
  }, [codes]);

  useEffect(() => {
    localStorage.setItem('mrlapin_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('mrlapin_recent_orders', JSON.stringify(recentOrders));
  }, [recentOrders]);

  // Authentic Gamer Names for Simulated Community Orders (every 1 minute & 1 min after order)
  const SIMULATED_GAMER_NAMES = [
    'Tanvir Gamer',
    'Shakib FF',
    'Rayan Sheikh',
    'Ayan Pro',
    'Arif Hunter',
    'Rakib Modz',
    'Deepak Bhai',
    'Sumon Khan',
    'Hamim Hasan',
    'Shohel Rana',
    'Sanzim King',
    'Runa Islam',
    'GamingWithTanvir',
    'Siam Ahmed',
    'Nayeem King',
    'Fahim FF',
    'Bijoy Modder',
    'Al-Amin Gaming',
    'Hasan Ali',
    'Imran FF',
    'Sadikur Rahman',
    'Tahmid FF',
    'Shanto VIP',
    'Mehedi Boss'
  ];

  const AVATAR_BG_COLORS = [
    'bg-blue-600',
    'bg-purple-600',
    'bg-emerald-600',
    'bg-rose-600',
    'bg-amber-600',
    'bg-indigo-600',
    'bg-cyan-600',
    'bg-teal-600'
  ];

  const createSimulatedOrder = (): RecentOrderItem => {
    const randomName = SIMULATED_GAMER_NAMES[Math.floor(Math.random() * SIMULATED_GAMER_NAMES.length)];
    const randomBg = AVATAR_BG_COLORS[Math.floor(Math.random() * AVATAR_BG_COLORS.length)];
    
    // Choose active online product & package
    const activeProds = products.filter((p) => p.status === 'online' || !p.status);
    const chosenProd = activeProds.length > 0
      ? activeProds[Math.floor(Math.random() * activeProds.length)]
      : products[0];

    const chosenPkg = chosenProd && chosenProd.packages && chosenProd.packages.length > 0
      ? chosenProd.packages[Math.floor(Math.random() * chosenProd.packages.length)]
      : { name: '1 Day (24 Hours)', price: 50 };

    const prodName = chosenProd ? chosenProd.name : 'MR LAPIN VIP';

    return {
      id: `ro_sim_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      user: randomName,
      product: `${prodName} - ${chosenPkg.name}`,
      price: `৳ ${chosenPkg.price}`,
      avatarBg: randomBg
    };
  };

  // Automatic 1-minute (60s) simulated order generator
  useEffect(() => {
    const simInterval = setInterval(() => {
      setRecentOrders((prev) => [createSimulatedOrder(), ...prev.slice(0, 29)]);
    }, 60000);

    return () => clearInterval(simInterval);
  }, [products]);

  // Helper date formatter
  const getNowString = () => {
    const now = new Date();
    return now.toLocaleString('en-US', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).replace(',', '');
  };

  // Helper key generator
  const generateRandomKey = (prefix = 'LAPIN') => {
    const part = () => Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${part()}-${part()}-${part()}`;
  };

  // User: Submit Deposit Request - Instant automated credit upon TrxID entry
  const submitDeposit = (gatewayId: string, amount: number, senderNumber: string, trxId: string): boolean => {
    const gateway = gateways.find((g) => g.id === gatewayId);
    if (!gateway) return false;

    const newDeposit: DepositRecord = {
      id: `dep_${Date.now()}`,
      serialNo: Math.floor(10000 + Math.random() * 90000),
      date: getNowString(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      gateway: gateway.name,
      paymentMethod: `${gateway.name} (${gateway.subType})`,
      senderNumber: senderNumber.trim(),
      trxId: trxId.trim().toUpperCase(),
      amount,
      status: 'completed',
      adminNote: 'Instant Auto-Credit via TrxID'
    };

    // Auto-credit user's wallet balance instantly
    setUser((prev) => ({
      ...prev,
      balance: prev.balance + amount
    }));

    setDeposits([newDeposit, ...deposits]);
    return true;
  };

  // User: Purchase Package
  const purchasePackage = (product: Product, packageTierId: string, quantity: number) => {
    const tier = product.packages.find((p) => p.id === packageTierId);
    if (!tier) return { success: false, message: 'Invalid package selected' };

    if (product.status !== 'online') {
      return { success: false, message: 'This product is currently not available for purchase.' };
    }

    const availableStock = tier.keysPool ? tier.keysPool.length : 999;
    if (tier.status === 'out_of_stock' || (tier.keysPool && availableStock === 0)) {
      return { success: false, message: 'Selected duration is out of stock (Stock Out).' };
    }

    if (tier.keysPool && tier.keysPool.length < quantity) {
      return { 
        success: false, 
        message: `পর্যাপ্ত স্টক নেই! এই প্যাকেজে মাত্র ${tier.keysPool.length} টি কী (Key) স্টকে আছে, আপনি ${quantity} টি সিলেক্ট করেছেন।` 
      };
    }

    const totalCost = tier.price * quantity;
    if (user.balance < totalCost) {
      return { 
        success: false, 
        message: `অপর্যাপ্ত ব্যালেন্স! আপনার দরকার ৳ ${totalCost}, কিন্তু আপনার ওয়ালেটে আছে ৳ ${user.balance}। দয়া করে Add Fund করুন।` 
      };
    }

    // Allocate exact quantity of keys from pool or generate
    let deliveredKeys: string[] = [];
    const hasKeysPool = Array.isArray(tier.keysPool) && tier.keysPool.length > 0;

    if (hasKeysPool) {
      deliveredKeys = tier.keysPool!.slice(0, quantity);
      const remainingPool = tier.keysPool!.slice(quantity);
      const isNowEmpty = remainingPool.length === 0;

      // Update package pool & auto-toggle status if out of stock
      setProducts((prev) =>
        prev.map((p) => {
          if (p.id === product.id) {
            return {
              ...p,
              packages: p.packages.map((pkg) =>
                pkg.id === tier.id
                  ? {
                      ...pkg,
                      keysPool: remainingPool,
                      status: isNowEmpty ? 'out_of_stock' : pkg.status
                    }
                  : pkg
              )
            };
          }
          return p;
        })
      );
    } else {
      deliveredKeys = Array.from({ length: quantity }, () =>
        generateRandomKey(product.name.substring(0, 4).replace(/[^A-Z]/gi, '').toUpperCase())
      );
    }

    // Deduct exact total cost from user balance
    const newBalance = user.balance - totalCost;
    setUser((prev) => ({
      ...prev,
      balance: newBalance,
      totalOrders: prev.totalOrders + 1,
      totalSpent: prev.totalSpent + totalCost
    }));

    // Create serial
    const baseSerial = Math.floor(10000 + Math.random() * 90000);
    const dateStr = getNowString();

    const newOrder: OrderRecord = {
      id: `ord_${Date.now()}`,
      serialNo: baseSerial,
      date: dateStr,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      productId: product.id,
      productName: product.name,
      packageTitle: tier.name,
      price: tier.price,
      quantity,
      totalPrice: totalCost,
      status: 'completed',
      licenseKey: deliveredKeys.join(', ')
    };

    // Add ALL purchased keys to user's wallet codes (My Codes)
    const newCodes: UserCodeRecord[] = deliveredKeys.map((k, idx) => ({
      id: `code_${Date.now()}_${idx}`,
      serialNo: baseSerial + idx,
      date: dateStr,
      packageTitle: quantity > 1 ? `${tier.name} [Key ${idx + 1}/${quantity}]` : tier.name,
      price: tier.price,
      status: 'completed',
      code: k
    }));

    setOrders((prev) => [newOrder, ...prev]);
    setCodes((prev) => [...newCodes, ...prev]);

    // Live Recent Orders Feed: Immediately add this real order
    const buyerDisplayName = (user.name && user.name.trim() !== '')
      ? user.name
      : (user.email ? user.email.split('@')[0] : 'Gamer Buyer');

    const liveRecentOrder: RecentOrderItem = {
      id: `ro_live_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      user: buyerDisplayName,
      product: `${product.name} - ${tier.name}`,
      price: `৳ ${totalCost}`,
      avatarBg: AVATAR_BG_COLORS[Math.floor(Math.random() * AVATAR_BG_COLORS.length)]
    };
    setRecentOrders((prev) => [liveRecentOrder, ...prev.slice(0, 29)]);

    // 1 minute (60 seconds) after order is placed: automatically add a realistic simulated order
    setTimeout(() => {
      setRecentOrders((prev) => [createSimulatedOrder(), ...prev.slice(0, 29)]);
    }, 60000);

    return {
      success: true,
      message: `ক্রয় সম্পন্ন হয়েছে! আপনার ওয়ালেট থেকে ৳ ${totalCost} কেটে নেওয়া হয়েছে এবং ${quantity} টি লাইসেন্স কী ওয়ালেটে যুক্ত করা হয়েছে।`,
      key: deliveredKeys[0],
      keys: deliveredKeys
    };
  };

  // Auth & Roles
  const loginWithEmail = (email: string, name?: string) => {
    const cleanEmail = sanitizeInput(email).trim().toLowerCase();
    const cleanName = name || cleanEmail.split('@')[0];
    const sessionToken = generateSessionToken(cleanEmail, 'user');

    const updatedUser: UserProfile = {
      ...user,
      email: cleanEmail,
      name: cleanName,
      isLoggedIn: true,
      authProvider: 'email',
      sessionToken
    };
    setUser(updatedUser);
    localStorage.setItem('mrlapin_user', JSON.stringify(updatedUser));
  };

  const loginWithCredentials = (rawEmail: string, rawPassword: string) => {
    const cleanEmail = sanitizeInput(rawEmail).toLowerCase().trim();
    const cleanPassword = rawPassword.trim();

    if (!isValidEmail(cleanEmail)) {
      return { success: false, message: 'সঠিক ইমেইল ঠিকানা দিন (Valid Email Address required)' };
    }

    // Rate Limiting & Anti-Brute Force check
    const rateCheck = checkRateLimit(cleanEmail);
    if (!rateCheck.allowed) {
      return { 
        success: false, 
        message: `সিকিউরিটি অ্যালার্ট: অতিরিক্ত ভুল চেষ্টার কারণে অ্যাকাউন্ট সাময়িক লক রয়েছে।`,
        remainingSeconds: rateCheck.remainingSeconds 
      };
    }

    // Check against registered accounts or admin
    const account = registeredAccounts.find(a => a.email.toLowerCase() === cleanEmail);
    const passHash = hashPassword(cleanPassword);

    const isDirectAdminMatch = cleanEmail === ADMIN_EMAIL && (cleanPassword === 'Admin@1234' || cleanPassword === 'admin' || (account && account.passwordHash === passHash));
    const isRegularAccountMatch = account && account.passwordHash === passHash;

    if (isDirectAdminMatch || isRegularAccountMatch) {
      clearRateLimit(cleanEmail);
      const isTargetAdmin = cleanEmail === ADMIN_EMAIL;
      const sessionToken = generateSessionToken(cleanEmail, isTargetAdmin ? 'admin' : 'user');
      const userName = isDirectAdminMatch ? 'Higun Admin' : (account?.name || cleanEmail.split('@')[0]);
      const userPhone = account?.phone || (isTargetAdmin ? '018813913894' : '');
      const userPin = account?.supportPin || (isTargetAdmin ? '5433' : '1234');

      const updatedUser: UserProfile = {
        ...user,
        email: cleanEmail,
        name: userName,
        phone: userPhone,
        supportPin: userPin,
        authProvider: 'email',
        isLoggedIn: true,
        sessionToken
      };

      setUser(updatedUser);
      localStorage.setItem('mrlapin_user', JSON.stringify(updatedUser));

      return {
        success: true,
        message: isTargetAdmin 
          ? 'সফল! Higun Admin একাউন্টে লগইন সম্পন্ন হয়েছে (Admin Access Granted)' 
          : 'লগইন সফল হয়েছে! স্বাগতম।'
      };
    } else {
      const failedResult = recordFailedLogin(cleanEmail);
      if (failedResult.locked) {
        return {
          success: false,
          message: '৫ বার ভুল পাসওয়ার্ড দেওয়ার কারণে অ্যাকাউন্টটি ৬০ সেকেন্ডের জন্য লক করা হয়েছে।',
          remainingSeconds: failedResult.remainingSeconds
        };
      } else {
        const remaining = 5 - failedResult.attempts;
        return {
          success: false,
          message: `ভুল ইমেইল বা পাসওয়ার্ড! আর ${remaining} বার চেষ্টা করার সুযোগ আছে।`
        };
      }
    }
  };

  const loginWithGoogle = (customAccount?: { email: string; name: string; avatarUrl?: string }) => {
    const cleanEmail = sanitizeInput(customAccount?.email || '').toLowerCase().trim();
    if (!cleanEmail) {
      return { success: false, message: 'দয়া করে একটি সঠিক Gmail এড্রেস দিন।' };
    }
    const isTargetAdmin = cleanEmail === ADMIN_EMAIL;
    const cleanName = sanitizeInput(customAccount?.name || (isTargetAdmin ? 'Higun Admin' : cleanEmail.split('@')[0]));
    const sessionToken = generateSessionToken(cleanEmail, isTargetAdmin ? 'admin' : 'user');

    const updatedUser: UserProfile = {
      id: isTargetAdmin ? 'usr_admin_1' : `usr_${Date.now()}`,
      email: cleanEmail,
      name: cleanName,
      phone: isTargetAdmin ? '018813913894' : '',
      balance: isTargetAdmin && user.email === ADMIN_EMAIL ? user.balance : 0,
      totalOrders: isTargetAdmin && user.email === ADMIN_EMAIL ? user.totalOrders : 0,
      totalSpent: isTargetAdmin && user.email === ADMIN_EMAIL ? user.totalSpent : 0,
      supportPin: isTargetAdmin ? '5433' : Math.floor(1000 + Math.random() * 9000).toString(),
      authProvider: 'google',
      isLoggedIn: true,
      sessionToken,
      avatarUrl: customAccount?.avatarUrl
    };

    setUser(updatedUser);
    localStorage.setItem('mrlapin_user', JSON.stringify(updatedUser));
    clearRateLimit(cleanEmail);

    return {
      success: true,
      message: isTargetAdmin 
        ? 'Google দিয়ে Higun Admin অ্যাকাউন্টে সফল লগইন সম্পন্ন! অ্যাডমিন প্যানেল সক্রিয়।' 
        : `Google দিয়ে লগইন সফল: ${cleanEmail}`
    };
  };

  const loginWithTelegram = (tgData: { username: string; firstName: string; id?: string }) => {
    const cleanUsername = sanitizeInput(tgData.username).replace(/^@+/, '').trim();
    const cleanName = sanitizeInput(tgData.firstName).trim() || cleanUsername;
    const cleanEmail = `${cleanUsername.toLowerCase()}@telegram.org`;
    const sessionToken = generateSessionToken(cleanEmail, 'user');

    const updatedUser: UserProfile = {
      ...user,
      email: cleanEmail,
      name: cleanName,
      authProvider: 'telegram',
      telegramUsername: `@${cleanUsername}`,
      isLoggedIn: true,
      sessionToken
    };

    setUser(updatedUser);
    localStorage.setItem('mrlapin_user', JSON.stringify(updatedUser));

    return {
      success: true,
      message: `Telegram (@${cleanUsername}) দিয়ে সফলভাবে লগইন করা হয়েছে!`
    };
  };

  const registerAccount = (data: { name: string; email: string; phone: string; password: string }) => {
    const cleanEmail = sanitizeInput(data.email).toLowerCase().trim();
    const cleanName = sanitizeInput(data.name).trim();
    const cleanPhone = sanitizeInput(data.phone).trim();
    const cleanPassword = data.password.trim();

    if (!isValidEmail(cleanEmail)) {
      return { success: false, message: 'একটি সঠিক ইমেইল ঠিকানা দিন।' };
    }

    if (registeredAccounts.some(a => a.email.toLowerCase() === cleanEmail)) {
      return { success: false, message: 'এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট খোলা হয়েছে। দয়া করে লগইন করুন।' };
    }

    if (cleanPassword.length < 6) {
      return { success: false, message: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' };
    }

    const autoPin = Math.floor(1000 + Math.random() * 9000).toString();
    const newAcc: RegisteredAccount = {
      id: `acc_${Date.now()}`,
      name: cleanName,
      email: cleanEmail,
      phone: cleanPhone,
      passwordHash: hashPassword(cleanPassword),
      supportPin: autoPin,
      authProvider: 'email',
      createdAt: new Date().toISOString()
    };

    setRegisteredAccounts((prev) => [...prev, newAcc]);

    const isTargetAdmin = cleanEmail === ADMIN_EMAIL;
    const sessionToken = generateSessionToken(cleanEmail, isTargetAdmin ? 'admin' : 'user');

    const newUserProfile: UserProfile = {
      id: `usr_${Date.now()}`,
      name: cleanName,
      email: cleanEmail,
      phone: cleanPhone,
      balance: 0,
      totalOrders: 0,
      totalSpent: 0,
      supportPin: autoPin,
      authProvider: 'email',
      isLoggedIn: true,
      sessionToken
    };

    setUser(newUserProfile);
    localStorage.setItem('mrlapin_user', JSON.stringify(newUserProfile));

    return {
      success: true,
      message: `রেজিস্ট্রেশন সফল হয়েছে! আপনার সিকিউরিটি পিন: ${autoPin}`
    };
  };

  const resetPasswordWithPin = (rawEmail: string, pin: string, newPass: string) => {
    const cleanEmail = sanitizeInput(rawEmail).toLowerCase().trim();
    const cleanPin = sanitizeInput(pin).trim();
    const cleanPass = newPass.trim();

    const accountIndex = registeredAccounts.findIndex(a => a.email.toLowerCase() === cleanEmail);
    const isAdminAccount = cleanEmail === ADMIN_EMAIL;

    if (!isAdminAccount && accountIndex === -1) {
      return { success: false, message: 'এই ইমেইলের কোনো অ্যাকাউন্ট খুঁজে পাওয়া যায়নি।' };
    }

    const targetAccount = isAdminAccount 
      ? { supportPin: '5433' } 
      : registeredAccounts[accountIndex];

    if (targetAccount.supportPin !== cleanPin) {
      return { success: false, message: 'ভুল সাপোর্ট পিন! অ্যাকাউন্টের ৪-সংখ্যার পিনটি সঠিক দিন।' };
    }

    const newHash = hashPassword(cleanPass);
    if (accountIndex !== -1) {
      setRegisteredAccounts((prev) =>
        prev.map((acc, idx) => (idx === accountIndex ? { ...acc, passwordHash: newHash } : acc))
      );
    }

    return { success: true, message: 'পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে! এখন নতুন পাসওয়ার্ড দিয়ে লগইন করুন।' };
  };

  const logout = () => {
    const guestUser: UserProfile = {
      id: `usr_guest_${Date.now()}`,
      name: 'Guest User',
      email: '',
      phone: '',
      balance: 0,
      totalOrders: 0,
      totalSpent: 0,
      supportPin: '0000',
      isLoggedIn: false,
      sessionToken: ''
    };
    setUser(guestUser);
    localStorage.setItem('mrlapin_user', JSON.stringify(guestUser));
    setActiveTab('home');
    setShowAuthModal(true);
  };

  // Update Profile
  const updateUserProfile = (data: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...data }));
  };

  // Admin Actions
  const updateSettings = (newSettings: Partial<SiteSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const updateHeroSlides = (slides: HeroSlideItem[]) => {
    setSettings((prev) => ({ ...prev, heroSlides: slides }));
  };

  const updateGatewayNumber = (gatewayId: string, newNumberOrAddress: string, instructions?: string, isActive?: boolean) => {
    setGateways((prev) =>
      prev.map((g) => {
        if (g.id === gatewayId) {
          return {
            ...g,
            numberOrAddress: newNumberOrAddress,
            ...(instructions !== undefined ? { instructions } : {}),
            ...(isActive !== undefined ? { isActive } : {})
          };
        }
        return g;
      })
    );
  };

  const updateGatewayDetails = (gatewayId: string, updatedGateway: Partial<PaymentGatewayConfig>) => {
    setGateways((prev) =>
      prev.map((g) => (g.id === gatewayId ? { ...g, ...updatedGateway } : g))
    );
  };

  const addNewGateway = (newGateway: PaymentGatewayConfig) => {
    setGateways((prev) => [...prev, newGateway]);
  };

  const deleteGateway = (gatewayId: string) => {
    setGateways((prev) => prev.filter((g) => g.id !== gatewayId));
  };

  const updateProductStatus = (productId: string, status: ProductStatus, customBadge?: string) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return {
            ...p,
            status,
            customBadge: customBadge || (status === 'maintenance' ? 'UNDER MAINTENANCE' : status === 'out_of_stock' ? 'OUT OF STOCK' : status === 'not_available' ? 'THIS PRODUCT NOT AVAILABLE' : undefined)
          };
        }
        return p;
      })
    );
  };

  const updateProductDetails = (productId: string, data: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, ...data } : p))
    );
  };

  const editProductPackage = (productId: string, packageId: string, updatedPackage: Partial<PackageTier>) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          const updatedPackages = p.packages.map((pkg) =>
            pkg.id === packageId ? { ...pkg, ...updatedPackage } : pkg
          );
          return { ...p, packages: updatedPackages };
        }
        return p;
      })
    );
  };

  const addPackageToProduct = (productId: string, newPackage: PackageTier) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return { ...p, packages: [...p.packages, newPackage] };
        }
        return p;
      })
    );
  };

  const deletePackageFromProduct = (productId: string, packageId: string) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return { ...p, packages: p.packages.filter((pkg) => pkg.id !== packageId) };
        }
        return p;
      })
    );
  };

  const addKeysToPackageTier = (productId: string, packageId: string, newKeys: string[]) => {
    const validKeys = newKeys.map((k) => k.trim()).filter((k) => k.length > 0);
    if (validKeys.length === 0) return;

    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return {
            ...p,
            packages: p.packages.map((pkg) => {
              if (pkg.id === packageId) {
                const currentPool = pkg.keysPool || [];
                return {
                  ...pkg,
                  keysPool: [...currentPool, ...validKeys],
                  status: 'online' // auto restore to online when keys are added
                };
              }
              return pkg;
            })
          };
        }
        return p;
      })
    );
  };

  const removeKeyFromPackageTier = (productId: string, packageId: string, keyIndex: number) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return {
            ...p,
            packages: p.packages.map((pkg) => {
              if (pkg.id === packageId && pkg.keysPool) {
                const updated = pkg.keysPool.filter((_, idx) => idx !== keyIndex);
                return {
                  ...pkg,
                  keysPool: updated,
                  status: updated.length === 0 ? 'out_of_stock' : pkg.status
                };
              }
              return pkg;
            })
          };
        }
        return p;
      })
    );
  };

  const clearPackageKeys = (productId: string, packageId: string) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return {
            ...p,
            packages: p.packages.map((pkg) => {
              if (pkg.id === packageId) {
                return {
                  ...pkg,
                  keysPool: [],
                  status: 'out_of_stock'
                };
              }
              return pkg;
            })
          };
        }
        return p;
      })
    );
  };

  const addNewProduct = (product: Product) => {
    const safeProduct: Product = {
      ...product,
      image: product.image && product.image.trim() !== ''
        ? product.image
        : 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'
    };
    setProducts((prev) => [safeProduct, ...prev]);
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
  };

  const addRecentOrder = (order: RecentOrderItem) => {
    setRecentOrders((prev) => [order, ...prev.slice(0, 29)]);
  };

  const deleteRecentOrder = (orderId: string) => {
    setRecentOrders((prev) => prev.filter((o) => o.id !== orderId));
  };

  const clearRecentOrders = () => {
    setRecentOrders([]);
  };

  const triggerSimulatedOrder = () => {
    setRecentOrders((prev) => [createSimulatedOrder(), ...prev.slice(0, 29)]);
  };

  // Approve Deposit Request & Auto-credit Balance
  const approveDeposit = (depositId: string) => {
    const deposit = deposits.find((d) => d.id === depositId);
    if (!deposit || deposit.status === 'completed') return;

    // Credit balance to user if it's the current user
    if (deposit.userId === user.id) {
      setUser((prev) => ({
        ...prev,
        balance: prev.balance + deposit.amount
      }));
    }

    setDeposits((prev) =>
      prev.map((d) => (d.id === depositId ? { ...d, status: 'completed' } : d))
    );
  };

  const rejectDeposit = (depositId: string, note?: string) => {
    setDeposits((prev) =>
      prev.map((d) => (d.id === depositId ? { ...d, status: 'rejected', adminNote: note } : d))
    );
  };

  // Admin: Directly add / adjust balance to any user
  const manualAddBalance = (targetUserId: string, amount: number, note?: string) => {
    if (targetUserId === user.id || targetUserId === 'current') {
      setUser((prev) => ({
        ...prev,
        balance: Math.max(0, prev.balance + amount)
      }));

      // Also create a deposit log entry
      const logEntry: DepositRecord = {
        id: `dep_manual_${Date.now()}`,
        serialNo: Math.floor(10000 + Math.random() * 90000),
        date: getNowString(),
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        gateway: 'Admin Manual Credit',
        paymentMethod: 'Admin Panel Adjustment',
        senderNumber: 'SYSTEM_ADMIN',
        trxId: `ADMIN-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
        amount,
        status: 'completed',
        adminNote: note || 'Admin manual balance addition'
      };

      setDeposits([logEntry, ...deposits]);
    }
  };

  const updateOrderStatus = (orderId: string, status: OrderRecord['status']) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status } : ord))
    );
  };

  const resetToDefaults = () => {
    localStorage.clear();
    setUser(INITIAL_USER);
    setProducts(INITIAL_PRODUCTS);
    setGateways(INITIAL_GATEWAYS);
    setDeposits(INITIAL_DEPOSITS);
    setOrders(INITIAL_ORDERS);
    setCodes(INITIAL_CODES);
    setSettings(INITIAL_SITE_SETTINGS);
    setRecentOrders(INITIAL_RECENT_ORDERS);
  };

  return (
    <StoreContext.Provider
      value={{
        language,
        setLanguage,
        toggleLanguage,
        t,
        activeTab,
        setActiveTab,
        isDarkMode,
        setIsDarkMode,
        selectedProduct,
        setSelectedProduct,
        showTelegramPopup,
        setShowTelegramPopup,
        showAuthModal,
        setShowAuthModal,
        authModalInitialTab,
        setAuthModalInitialTab,
        user,
        isAdmin,
        isLoggedIn,
        adminEmail: ADMIN_EMAIL,
        loginWithEmail,
        loginWithCredentials,
        loginWithGoogle,
        loginWithTelegram,
        registerAccount,
        resetPasswordWithPin,
        logout,
        products,
        gateways,
        deposits,
        orders,
        codes,
        settings,
        recentOrders,
        submitDeposit,
        purchasePackage,
        updateUserProfile,
        updateSettings,
        updateHeroSlides,
        updateGatewayNumber,
        updateGatewayDetails,
        addNewGateway,
        deleteGateway,
        updateProductStatus,
        updateProductDetails,
        editProductPackage,
        addPackageToProduct,
        deletePackageFromProduct,
        addKeysToPackageTier,
        removeKeyFromPackageTier,
        clearPackageKeys,
        addNewProduct,
        deleteProduct,
        approveDeposit,
        rejectDeposit,
        manualAddBalance,
        addRecentOrder,
        deleteRecentOrder,
        clearRecentOrders,
        triggerSimulatedOrder,
        updateOrderStatus,
        editingProductId,
        setEditingProductId,
        resetToDefaults
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within StoreProvider');
  return context;
};
