import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

// Helper to recursively add files to zip
function addFolderToZip(zip, folderPath, baseFolder = '') {
  if (!fs.existsSync(folderPath)) return;
  const items = fs.readdirSync(folderPath);

  for (const item of items) {
    // Exclude heavy or sensitive directories
    if (item === 'node_modules' || item === '.git' || item === '.aistudio' || item === 'dist') continue;
    if (item.endsWith('.zip') || item.endsWith('.tar.gz') || item.endsWith('.mp4')) continue;

    const fullPath = path.join(folderPath, item);
    const stat = fs.statSync(fullPath);
    const zipPath = baseFolder ? `${baseFolder}/${item}` : item;

    if (stat.isDirectory()) {
      addFolderToZip(zip, fullPath, zipPath);
    } else {
      const content = fs.readFileSync(fullPath);
      zip.file(zipPath, content);
    }
  }
}

// 1. Create Netlify Production Ready Zip (dist contents + _redirects)
async function createNetlifyZip() {
  const distDir = path.join(rootDir, 'dist');
  if (!fs.existsSync(distDir)) {
    console.error('dist directory not found! Run npm run build first.');
    return;
  }

  const zip = new JSZip();

  function addDistFiles(dir, zipFolder) {
    const files = fs.readdirSync(dir);
    for (const f of files) {
      if (f.endsWith('.zip') || f.endsWith('.mp4')) continue;
      const fullPath = path.join(dir, f);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        const sub = zipFolder.folder(f);
        addDistFiles(fullPath, sub);
      } else {
        zipFolder.file(f, fs.readFileSync(fullPath));
      }
    }
  }

  addDistFiles(distDir, zip);

  // Ensure _redirects is present in the root of the zip
  if (!zip.file('_redirects')) {
    zip.file('_redirects', '/*    /index.html   200\n');
  }

  const outPath = path.join(rootDir, 'public', 'mrlapin-netlify-ready.zip');
  const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  fs.writeFileSync(outPath, buffer);
  console.log('Created Netlify Ready ZIP at:', outPath);
}

// 2. Create GitHub Source Code Zip
async function createGitHubSourceZip() {
  const zip = new JSZip();
  addFolderToZip(zip, rootDir, '');

  const outPath = path.join(rootDir, 'public', 'mrlapin-source-code.zip');
  const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  fs.writeFileSync(outPath, buffer);
  console.log('Created GitHub Source Code ZIP at:', outPath);
}

async function run() {
  const publicDir = path.join(rootDir, 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  await createNetlifyZip();
  await createGitHubSourceZip();
  console.log('All Zip files successfully generated in /public!');
}

run().catch(console.error);
